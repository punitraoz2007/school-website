/**
 * School Enquiry & Lead Storage Service
 * Stores inquiries in browser localStorage and provides CSV export & status management.
 */

export interface AdmissionEnquiryRecord {
  id: string;
  parentName: string;
  studentName: string;
  dob: string;
  applyingClass: string;
  phone: string;
  email: string;
  address: string;
  previousSchool: string;
  message: string;
  submittedAt: string;
  status: 'New' | 'Contacted' | 'Visit Scheduled' | 'Admitted' | 'Archived';
}

export interface CampusVisitRecord {
  id: string;
  parentName: string;
  phone: string;
  email: string;
  childClass: string;
  visitDate: string;
  timeSlot: string;
  notes: string;
  submittedAt: string;
  status: 'Pending' | 'Confirmed' | 'Completed' | 'Cancelled';
}

export interface ContactMessageRecord {
  id: string;
  name: string;
  phone: string;
  email: string;
  subject: string;
  message: string;
  submittedAt: string;
  status: 'Unread' | 'Replied';
}

const STORAGE_KEYS = {
  ADMISSIONS: 'aarambh_admissions_list',
  VISITS: 'aarambh_visits_list',
  MESSAGES: 'aarambh_messages_list'
};

const defaultSeedAdmissions: AdmissionEnquiryRecord[] = [
  {
    id: 'APS-849201',
    parentName: 'Vikram & Shweta Malhotra',
    studentName: 'Kabir Malhotra',
    dob: '2023-04-12',
    applyingClass: 'Play School',
    phone: '+91 98112 34567',
    email: 'vikram.m@example.com',
    address: 'DLF Phase 4, Sector 28',
    previousSchool: 'None (First School)',
    message: 'Looking for a gentle play-school environment with caring teachers and outdoor activities.',
    submittedAt: 'Today at 09:15 AM',
    status: 'New'
  },
  {
    id: 'APS-731920',
    parentName: 'Deepak Saxena',
    studentName: 'Aanya Saxena',
    dob: '2019-11-05',
    applyingClass: 'Class 1',
    phone: '+91 98710 88231',
    email: 'deepak.saxena@example.com',
    address: 'South City 1, Block B',
    previousSchool: 'Little Millennium Pre-School',
    message: 'Inquiring regarding school bus route connectivity from South City and admission assessment dates.',
    submittedAt: 'Yesterday at 04:30 PM',
    status: 'Contacted'
  },
  {
    id: 'APS-620184',
    parentName: 'Rajesh & Pooja Aggarwal',
    studentName: 'Rohan Aggarwal',
    dob: '2014-08-20',
    applyingClass: 'Class 6',
    phone: '+91 99100 45678',
    email: 'pooja.aggarwal@example.com',
    address: 'Sector 15 Part 2',
    previousSchool: 'St. Xavier Primary School',
    message: 'Transfer admission query. Need details on science laboratory sessions and foreign language options.',
    submittedAt: '2 days ago',
    status: 'Visit Scheduled'
  }
];

const defaultSeedVisits: CampusVisitRecord[] = [
  {
    id: 'VST-10492',
    parentName: 'Neha & Amit Gupta',
    phone: '+91 98188 12345',
    email: 'neha.gupta@example.com',
    childClass: 'Nursery / KG',
    visitDate: 'Tomorrow',
    timeSlot: '10:00 AM - 11:00 AM',
    notes: 'Would love to inspect the Kindergarten activity rooms and meet the head coordinator.',
    submittedAt: 'Today at 10:20 AM',
    status: 'Confirmed'
  }
];

const defaultSeedMessages: ContactMessageRecord[] = [
  {
    id: 'MSG-39201',
    name: 'Sandeep Varma',
    phone: '+91 98101 22334',
    email: 'sandeep.v@example.com',
    subject: 'School Bus & Transport Route',
    message: 'Hello, please confirm if the school bus covers Sector 23 and Palam Vihar for Class 3 students.',
    submittedAt: 'Today at 11:45 AM',
    status: 'Unread'
  }
];

export const getAdmissionEnquiries = (): AdmissionEnquiryRecord[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.ADMISSIONS);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.ADMISSIONS, JSON.stringify(defaultSeedAdmissions));
      return defaultSeedAdmissions;
    }
    return JSON.parse(data);
  } catch {
    return defaultSeedAdmissions;
  }
};

export const saveAdmissionEnquiry = (enquiry: Omit<AdmissionEnquiryRecord, 'id' | 'submittedAt' | 'status'>): AdmissionEnquiryRecord => {
  const current = getAdmissionEnquiries();
  const newRecord: AdmissionEnquiryRecord = {
    ...enquiry,
    id: `APS-${Math.floor(100000 + Math.random() * 900000)}`,
    submittedAt: new Date().toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }),
    status: 'New'
  };

  const updated = [newRecord, ...current];
  try {
    localStorage.setItem(STORAGE_KEYS.ADMISSIONS, JSON.stringify(updated));
    window.dispatchEvent(new Event('aarambh_enquiry_updated'));
  } catch (e) {
    console.error('Failed to save to localStorage', e);
  }
  return newRecord;
};

export const updateAdmissionStatus = (id: string, status: AdmissionEnquiryRecord['status']) => {
  const current = getAdmissionEnquiries();
  const updated = current.map(item => item.id === id ? { ...item, status } : item);
  try {
    localStorage.setItem(STORAGE_KEYS.ADMISSIONS, JSON.stringify(updated));
    window.dispatchEvent(new Event('aarambh_enquiry_updated'));
  } catch (e) {
    console.error(e);
  }
};

export const deleteAdmissionEnquiry = (id: string) => {
  const current = getAdmissionEnquiries();
  const updated = current.filter(item => item.id !== id);
  try {
    localStorage.setItem(STORAGE_KEYS.ADMISSIONS, JSON.stringify(updated));
    window.dispatchEvent(new Event('aarambh_enquiry_updated'));
  } catch (e) {
    console.error(e);
  }
};

export const getCampusVisits = (): CampusVisitRecord[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.VISITS);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.VISITS, JSON.stringify(defaultSeedVisits));
      return defaultSeedVisits;
    }
    return JSON.parse(data);
  } catch {
    return defaultSeedVisits;
  }
};

export const saveCampusVisit = (visit: Omit<CampusVisitRecord, 'id' | 'submittedAt' | 'status'>): CampusVisitRecord => {
  const current = getCampusVisits();
  const newRecord: CampusVisitRecord = {
    ...visit,
    id: `VST-${Math.floor(10000 + Math.random() * 90000)}`,
    submittedAt: new Date().toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }),
    status: 'Pending'
  };

  const updated = [newRecord, ...current];
  try {
    localStorage.setItem(STORAGE_KEYS.VISITS, JSON.stringify(updated));
    window.dispatchEvent(new Event('aarambh_enquiry_updated'));
  } catch (e) {
    console.error(e);
  }
  return newRecord;
};

export const updateVisitStatus = (id: string, status: CampusVisitRecord['status']) => {
  const current = getCampusVisits();
  const updated = current.map(item => item.id === id ? { ...item, status } : item);
  try {
    localStorage.setItem(STORAGE_KEYS.VISITS, JSON.stringify(updated));
    window.dispatchEvent(new Event('aarambh_enquiry_updated'));
  } catch (e) {
    console.error(e);
  }
};

export const getContactMessages = (): ContactMessageRecord[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.MESSAGES);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(defaultSeedMessages));
      return defaultSeedMessages;
    }
    return JSON.parse(data);
  } catch {
    return defaultSeedMessages;
  }
};

export const saveContactMessage = (msg: Omit<ContactMessageRecord, 'id' | 'submittedAt' | 'status'>): ContactMessageRecord => {
  const current = getContactMessages();
  const newRecord: ContactMessageRecord = {
    ...msg,
    id: `MSG-${Math.floor(10000 + Math.random() * 90000)}`,
    submittedAt: new Date().toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }),
    status: 'Unread'
  };

  const updated = [newRecord, ...current];
  try {
    localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(updated));
    window.dispatchEvent(new Event('aarambh_enquiry_updated'));
  } catch (e) {
    console.error(e);
  }
  return newRecord;
};

export const updateMessageStatus = (id: string, status: ContactMessageRecord['status']) => {
  const current = getContactMessages();
  const updated = current.map(item => item.id === id ? { ...item, status } : item);
  try {
    localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(updated));
    window.dispatchEvent(new Event('aarambh_enquiry_updated'));
  } catch (e) {
    console.error(e);
  }
};

export const exportEnquiriesToCSV = () => {
  const enquiries = getAdmissionEnquiries();
  if (!enquiries.length) {
    alert('No enquiries found to export.');
    return;
  }

  const headers = ['Enquiry ID', 'Status', 'Parent Name', 'Student Name', 'Date of Birth', 'Class Applying', 'Phone', 'Email', 'Address', 'Previous School', 'Message', 'Submitted At'];
  
  const rows = enquiries.map(e => [
    e.id,
    e.status,
    `"${e.parentName.replace(/"/g, '""')}"`,
    `"${e.studentName.replace(/"/g, '""')}"`,
    e.dob,
    `"${e.applyingClass}"`,
    `"${e.phone}"`,
    `"${e.email || ''}"`,
    `"${(e.address || '').replace(/"/g, '""')}"`,
    `"${(e.previousSchool || '').replace(/"/g, '""')}"`,
    `"${(e.message || '').replace(/"/g, '""')}"`,
    `"${e.submittedAt}"`
  ]);

  const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `School_Admissions_Enquiries_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
