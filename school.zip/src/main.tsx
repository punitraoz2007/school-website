import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import './styles/welcome3d.css';

createRoot(document.getElementById('root')!).render(<App />);
