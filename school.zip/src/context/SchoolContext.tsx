import React, { createContext, useContext, useState, useEffect } from 'react';
import { SchoolConfig, defaultSchoolConfig } from '../data/schoolData';

interface SchoolContextType {
  school: SchoolConfig;
  updateSchool: (newConfig: Partial<SchoolConfig>) => void;
  resetToDefault: () => void;
  isCustomizerOpen: boolean;
  setIsCustomizerOpen: (open: boolean) => void;
}

const SchoolContext = createContext<SchoolContextType | undefined>(undefined);

export const SchoolProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [school, setSchool] = useState<SchoolConfig>(() => {
    try {
      const saved = localStorage.getItem('aarambh_school_config');
      if (saved) {
        return { ...defaultSchoolConfig, ...JSON.parse(saved) };
      }
    } catch {
      // fallback
    }
    return defaultSchoolConfig;
  });

  const [isCustomizerOpen, setIsCustomizerOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem('aarambh_school_config', JSON.stringify(school));
    } catch {
      // localStorage failed
    }
  }, [school]);

  const updateSchool = (newConfig: Partial<SchoolConfig>) => {
    setSchool(prev => ({ ...prev, ...newConfig }));
  };

  const resetToDefault = () => {
    setSchool(defaultSchoolConfig);
    try {
      localStorage.removeItem('aarambh_school_config');
    } catch {
      // ignore
    }
  };

  return (
    <SchoolContext.Provider
      value={{
        school,
        updateSchool,
        resetToDefault,
        isCustomizerOpen,
        setIsCustomizerOpen
      }}
    >
      {children}
    </SchoolContext.Provider>
  );
};

export const useSchool = () => {
  const context = useContext(SchoolContext);
  if (!context) {
    throw new Error('useSchool must be used within a SchoolProvider');
  }
  return context;
};
