/**
 * Aarambh Public School - Master Configuration & Content Data
 * Easily customizable for any Indian Play School + Classes 1 to 8 school.
 */

import heroImg from '../assets/images/hero_school_children_1791101324038.jpg';
import classroomImg from '../assets/images/smart_classroom_1791101337304.jpg';
import playschoolImg from '../assets/images/playschool_activity_1791101350172.jpg';
import libraryImg from '../assets/images/school_library_1791101364985.jpg';
import sportsImg from '../assets/images/school_sports_play_1791101377753.jpg';
import computerLabImg from '../assets/images/computer_lab_school_1791102341540.jpg';
import scienceLabImg from '../assets/images/science_lab_experiment_1791102355137.jpg';

export interface SchoolConfig {
  name: string;
  tagline: string;
  location: string;
  classes: string;
  board: string;
  affiliationNumber: string;
  establishedYear: string;
  phone: string;
  alternatePhone: string;
  email: string;
  admissionsEmail: string;
  address: string;
  cityState: string;
  pincode: string;
  timingPlaySchool: string;
  timingClasses1To8: string;
  officeTiming: string;
  visitingHours: string;
}

export const defaultSchoolConfig: SchoolConfig = {
  name: 'Aarambh Public School',
  tagline: 'Learn • Grow • Explore • Succeed',
  location: 'Sector 14, Gurugram, Haryana',
  classes: 'Play School, Nursery, LKG, UKG and Classes 1 to 8',
  board: 'CBSE Pattern Curriculum',
  affiliationNumber: 'REG-2016/HR/8842',
  establishedYear: '2014',
  phone: '+91 98765 43210',
  alternatePhone: '+91 124 4567890',
  email: 'info@aarambhschool.edu.in',
  admissionsEmail: 'admissions@aarambhschool.edu.in',
  address: 'Plot No. 42, Institutional Area, Sector 14, Near City Park',
  cityState: 'Gurugram, Haryana',
  pincode: '122001',
  timingPlaySchool: '8:30 AM to 12:30 PM (Mon - Fri)',
  timingClasses1To8: '7:45 AM to 2:15 PM (Mon - Sat, 2nd Sat Off)',
  officeTiming: '8:00 AM to 3:30 PM (Mon - Sat)',
  visitingHours: '9:00 AM to 1:00 PM (Prior Appointment Recommended)'
};

export const schoolStats = [
  { value: '10+', label: 'Years of Educational Excellence', detail: 'Serving families since 2014' },
  { value: '500+', label: 'Happy Students', detail: 'From Play School to Class 8' },
  { value: '30+', label: 'Trained & Caring Teachers', detail: 'Low student-teacher ratio of 15:1' },
  { value: '20+', label: 'Modern Ventilated Classrooms', detail: 'Equipped with smart learning aids' }
];

export const keyFeatures = [
  {
    title: 'Play School to Class 8',
    description: 'A continuous, nurturing educational journey from foundational early years to confident middle schoolers.',
    icon: 'GraduationCap'
  },
  {
    title: 'Safe & Secure Campus',
    description: 'Continuous CCTV monitoring in common areas, perimeter boundary, and strict visitor verification protocols.',
    icon: 'ShieldCheck'
  },
  {
    title: 'Experienced Teachers',
    description: 'Passionate, qualified educators who provide individualized attention with empathy, patience, and warmth.',
    icon: 'Users'
  },
  {
    title: 'Smart Classrooms',
    description: 'Interactive digital boards, multimedia audio-visual lessons, and well-lit, ergonomically seated spaces.',
    icon: 'Monitor'
  },
  {
    title: 'Activity-Based Learning',
    description: 'Hands-on experiential modules, science projects, storytelling, role-play, music, art, and sports.',
    icon: 'Sparkles'
  }
];

export const whyChooseReasons = [
  {
    title: 'Safe & Secure Environment',
    desc: 'Controlled access entry, verified support staff, comprehensive safety guidelines, and emergency preparedness.'
  },
  {
    title: 'Experienced & Caring Teachers',
    desc: 'Regular pedagogical training, background verified faculty, and high teacher-to-child care attention.'
  },
  {
    title: 'Well-Maintained Classrooms',
    desc: 'Spacious desks, ample natural ventilation, glare-free lighting, and child-safe non-toxic furniture.'
  },
  {
    title: 'CCTV Surveillance',
    desc: 'Responsible coverage across school gates, corridors, playgrounds, and staircases for vigilant monitoring.'
  },
  {
    title: 'Activity-Based Learning',
    desc: 'Encouraging inquiry, exploration, questioning, group projects, and practical discovery over rote learning.'
  },
  {
    title: 'Individual Attention',
    desc: 'Small batch sizes allowing teachers to understand every child’s unique pace, strengths, and talents.'
  },
  {
    title: 'Modern Learning Methods',
    desc: 'Blending foundational NEP 2020 concepts, phonics, STEM curiosity, and creative self-expression.'
  },
  {
    title: 'Clean & Hygienic Campus',
    desc: 'Multi-stage RO purified drinking water, sanitized washrooms, clean dining corners, and green surroundings.'
  }
];

export const academicStages = [
  {
    id: 'early-years',
    title: 'Early Years Foundation',
    grades: 'Play School, Nursery, LKG, UKG',
    ageGroup: 'Age 2.5 to 5.5 Years',
    overview: 'A gentle, joyful transition from home to school. We create a sensory-rich atmosphere where curiosity and confidence flourish naturally through play, discovery, and loving care.',
    keyFocus: [
      'Play-based & sensory learning centers',
      'Storytelling, puppet theatre & circle time',
      'Art, craft, finger painting & clay modelling',
      'Rhythm, music, action songs & nursery rhymes',
      'Phonics, early vocabulary & conversational English/Hindi',
      'Gross and fine motor skill development',
      'Social sharing, empathy, and table manners'
    ],
    curriculumHighlights: 'Montessori-inspired activity stations, themed weekly projects, colorful flashcards, and joyful outdoor nature walks.'
  },
  {
    id: 'primary',
    title: 'Primary Wing',
    grades: 'Class 1 to Class 5',
    ageGroup: 'Age 6 to 10 Years',
    overview: 'Nurturing essential literacy, mathematical reasoning, creative thinking, and moral grounding. Students transition from informal play to structured concept-building with enthusiasm.',
    keyFocus: [
      'English (Reading fluency, phonics, grammar, creative writing)',
      'Hindi (Varnamala, matras, comprehension, poetry & prose)',
      'Mathematics (Mental math, numbers, geometry basics, word problems)',
      'Environmental Studies (EVS - nature, community, hygiene & science)',
      'Computer Education (Keyboarding, Paint, Scratch coding basics)',
      'General Knowledge & Current Awareness',
      'Visual Arts, Craft & Performing Music/Drama',
      'Physical Education, Yoga & Team Sports'
    ],
    curriculumHighlights: 'Activity-based math kits, environmental field observations, library reading hours, and public speaking assemblies.'
  },
  {
    id: 'middle-school',
    title: 'Middle School',
    grades: 'Class 6 to Class 8',
    ageGroup: 'Age 11 to 14 Years',
    overview: 'Fostering deep analytical inquiry, scientific mindset, disciplined study habits, and leadership skills to prepare students smoothly for secondary school curricula.',
    keyFocus: [
      'English Literature & Advanced Functional Grammar',
      'Hindi / Sanskrit / Regional Language options',
      'Mathematics (Algebra, Geometry, Data Handling, Practical Arithmetic)',
      'Science (Physics, Chemistry, Biology with lab demonstrations)',
      'Social Science (History, Geography, Civics, Environmental Stewardship)',
      'Computer Science (Office tools, introductory Python, Web literacy)',
      'Art, Craft, Music & SUPW (Socially Useful Productive Work)',
      'Competitive sports, athletic fitness, and values education'
    ],
    curriculumHighlights: 'Science demonstration experiments, inter-house debates, quizzes, model exhibitions, and peer project collaborations.'
  }
];

export const facilitiesList = [
  {
    id: 'smart-classrooms',
    title: 'Smart Classrooms',
    category: 'Academics',
    image: classroomImg,
    description: 'Well-maintained, bright and spacious classrooms with interactive digital teaching aids, projector boards, and child-safe ergonomic furniture.'
  },
  {
    id: 'cctv-surveillance',
    title: 'CCTV Surveillance',
    category: 'Safety',
    image: null,
    description: 'CCTV cameras installed at campus gates, main corridors, open playgrounds, and common movement zones for enhanced security and responsible supervision.'
  },
  {
    id: 'well-maintained-classrooms',
    title: 'Clean & Ventilated Rooms',
    category: 'Campus',
    image: null,
    description: 'High ceilings, expansive windows for fresh air and natural sunlight, glare-free LED lighting, and comfortable age-appropriate seating.'
  },
  {
    id: 'safe-school-campus',
    title: 'Safe School Campus',
    category: 'Safety',
    image: null,
    description: 'Gated perimeter with controlled entry and exit, mandatory visitor registration registers, identity badges, and full campus boundary safety.'
  },
  {
    id: 'computer-lab',
    title: 'Modern Computer Lab',
    category: 'Academics',
    image: computerLabImg,
    description: 'Dedicated workstations equipped with educational software, coding tools, high-speed safe filtered internet, and qualified computer instructors.'
  },
  {
    id: 'science-learning',
    title: 'Science & Discovery Corner',
    category: 'Academics',
    image: scienceLabImg,
    description: 'Hands-on practical apparatus, microscope stations, models, and measurement kits that transform theoretical textbook concepts into lived reality.'
  },
  {
    id: 'library',
    title: 'Child-Friendly Library',
    category: 'Academics',
    image: libraryImg,
    description: 'Vibrant collection of illustrated story books, encyclopedia volumes, children’s magazines, fiction, and curated reference volumes in English and Hindi.'
  },
  {
    id: 'activity-room',
    title: 'Creative Activity Room',
    category: 'Arts & Culture',
    image: playschoolImg,
    description: 'Dedicated space for art, craft, clay modeling, music, movement, dramatic play, and celebrations that nurture artistic expression.'
  },
  {
    id: 'playground',
    title: 'Safe Outdoor Playground',
    category: 'Sports',
    image: sportsImg,
    description: 'Spacious outdoor area with soft turf, play equipment, football nets, badminton courts, and safe swings for daily games and physical fitness.'
  },
  {
    id: 'drinking-water',
    title: 'RO Purified Drinking Water',
    category: 'Health',
    image: null,
    description: 'Multi-stage RO filtration plants with UV purification and scheduled maintenance water quality testing, serving chilled and ambient safe water.'
  },
  {
    id: 'clean-washrooms',
    title: 'Clean, Separate Washrooms',
    category: 'Health',
    image: null,
    description: 'Dedicated boys’ and girls’ washrooms on each floor with continuous water supply, child-friendly height fixtures, and vigilant sanitization.'
  },
  {
    id: 'first-aid',
    title: 'Campus First Aid Facility',
    category: 'Health',
    image: null,
    description: 'Equipped medical room with first-aid essentials, resting bed, thermal scanner, and designated tie-up with nearby medical clinics for prompt emergency care.'
  },
  {
    id: 'transportation',
    title: 'School Transport Service',
    category: 'Logistics',
    image: null,
    description: 'Well-maintained school buses and vans covering designated local routes with speed governors, verified drivers, and attendant supervision.'
  },
  {
    id: 'reception-area',
    title: 'Warm Reception & Lounge',
    category: 'Campus',
    image: null,
    description: 'A welcoming, clean front desk and waiting lounge where parents can meet counselors, clarify academic queries, and complete admissions.'
  }
];

export const facultyMembers = [
  {
    name: 'Mrs. Sunita Verma',
    designation: 'Principal & Head of School',
    qualification: 'M.Sc., B.Ed., 18+ Years Experience',
    subject: 'Educational Leadership & Mathematics',
    imagePlaceholder: 'SV',
    quote: 'Education is not merely filling a vessel; it is igniting an inner flame of curiosity, compassion, and lifelong self-belief.'
  },
  {
    name: 'Mrs. Anjali Sharma',
    designation: 'Early Childhood Coordinator',
    qualification: 'M.A. (Child Psychology), NTT, 9 Years Experience',
    subject: 'Play School & Kindergarten Lead',
    imagePlaceholder: 'AS',
    quote: 'Every young child blooms differently. When we surround them with patience and love, learning becomes as natural as breathing.'
  },
  {
    name: 'Mr. Rajesh Rawat',
    designation: 'Senior Teacher - Science & Mathematics',
    qualification: 'B.Sc. (Hons), B.Ed., 12 Years Experience',
    subject: 'Middle School Science & Math',
    imagePlaceholder: 'RR',
    quote: 'Science comes alive when students observe and touch real concepts. We train young minds to observe, hypothesize, and reason logically.'
  },
  {
    name: 'Mrs. Meenakshi Joshi',
    designation: 'Primary Wing Coordinator',
    qualification: 'M.A. (English), B.Ed., 10 Years Experience',
    subject: 'English & Social Studies',
    imagePlaceholder: 'MJ',
    quote: 'Building rich language comprehension and reading habits early empowers children to express their thoughts with clarity and confidence.'
  },
  {
    name: 'Mr. Vikram Singh',
    designation: 'Computer Science Instructor',
    qualification: 'MCA, 7 Years Experience',
    subject: 'Information Technology & Coding',
    imagePlaceholder: 'VS',
    quote: 'We guide children to become responsible, creative builders in the digital world rather than passive screen consumers.'
  },
  {
    name: 'Mrs. Kavita Saxena',
    designation: 'Hindi & Sanskrit Faculty',
    qualification: 'M.A. (Hindi Lit), B.Ed., 11 Years Experience',
    subject: 'Indian Languages & Cultural Values',
    imagePlaceholder: 'KS',
    quote: 'Our rich language and cultural heritage provide children with rooted ethics, respect for elders, and heartfelt communication.'
  },
  {
    name: 'Mr. Amit Chauhan',
    designation: 'Physical Education & Sports Instructor',
    qualification: 'B.P.Ed., Certified NIS Coach',
    subject: 'Sports, Athletics & Yoga',
    imagePlaceholder: 'AC',
    quote: 'Games teach resilience, teamwork, discipline, and the grace to win and lose with equal dignity.'
  },
  {
    name: 'Ms. Pooja Nair',
    designation: 'Art & Performing Arts Teacher',
    qualification: 'B.F.A., 6 Years Experience',
    subject: 'Visual Art, Craft & Drama',
    imagePlaceholder: 'PN',
    quote: 'Art gives children a voice when words fall short. We encourage every brushstroke and creative instinct.'
  }
];

export const noticeBoardItems = [
  {
    id: 1,
    category: 'Admissions',
    title: 'Admissions Open for Academic Session 2026-2027',
    date: 'March 25, 2026',
    isNew: true,
    summary: 'Registrations are open for Play School, Nursery, LKG, UKG and Classes 1 to 8. Limited seats per section to maintain individual attention. Prospectus available at front office.',
    attachment: 'Admission_Guidelines_2026-27.pdf'
  },
  {
    id: 2,
    category: 'Events',
    title: 'Annual Sports & Athletic Meet Scheduled for October 18',
    date: 'March 20, 2026',
    isNew: true,
    summary: 'Parents are cordially invited to cheer our young champions during the Annual Track & Field events and fun family relay races.',
    attachment: 'Sports_Day_Schedule.pdf'
  },
  {
    id: 3,
    category: 'Meetings',
    title: 'Parent-Teacher Meeting (PTM) for Term Assessment',
    date: 'March 15, 2026',
    isNew: false,
    summary: 'PTM for Play School to Class 8 will be held on Saturday between 8:30 AM and 12:30 PM. Slot schedules have been communicated via school diary.',
    attachment: 'PTM_Guidelines.pdf'
  },
  {
    id: 4,
    category: 'Holidays',
    title: 'Upcoming Festival & National Holiday Schedule',
    date: 'March 10, 2026',
    isNew: false,
    summary: 'Please review the official gazetted holiday calendar for the current quarter. Regular classes resume promptly on the designated dates.',
    attachment: 'Holiday_Calendar_2026.pdf'
  },
  {
    id: 5,
    category: 'Academic',
    title: 'Science & Creative Art Exhibition - "Little Explorers"',
    date: 'March 02, 2026',
    isNew: false,
    summary: 'Class 3 to 8 students will showcase their working science models and craft projects in the school auditorium.',
    attachment: 'Exhibition_Brochure.pdf'
  }
];

export const galleryCategories = ['All', 'Campus', 'Classrooms', 'Activities', 'Sports', 'Events', 'Celebrations'];

export const galleryItems = [
  {
    id: 'g1',
    title: 'Happy Learners in Modern Classroom',
    category: 'Classrooms',
    image: heroImg,
    caption: 'Interactive peer learning in our well-lit, ventilated classrooms.'
  },
  {
    id: 'g2',
    title: 'Smart Digital Board Session',
    category: 'Classrooms',
    image: classroomImg,
    caption: 'Visualizing mathematics and science concepts on our interactive display.'
  },
  {
    id: 'g3',
    title: 'Play School Sensory & Block Play',
    category: 'Activities',
    image: playschoolImg,
    caption: 'Fostering fine motor skills and creativity through hands-on Montessori activities.'
  },
  {
    id: 'g4',
    title: 'Reading Hour at the School Library',
    category: 'Campus',
    image: libraryImg,
    caption: 'Fostering an early love for books and quiet contemplative learning.'
  },
  {
    id: 'g5',
    title: 'Outdoor Sports & Athletic Field',
    category: 'Sports',
    image: sportsImg,
    caption: 'Team games, athletics, and active recess on our safe green playfield.'
  },
  {
    id: 'g6',
    title: 'Computer Lab Practical Coding',
    category: 'Activities',
    image: computerLabImg,
    caption: 'Students learning digital skills and visual coding under teacher guidance.'
  },
  {
    id: 'g7',
    title: 'Hands-on Science Discovery',
    category: 'Activities',
    image: scienceLabImg,
    caption: 'Exploring natural phenomena and experiments in the science activity corner.'
  },
  {
    id: 'g8',
    title: 'Morning Assembly & Value Thought',
    category: 'Events',
    image: heroImg,
    caption: 'Starting the school day with morning prayers, national anthem, and student speeches.'
  },
  {
    id: 'g9',
    title: 'Independence Day Celebrations',
    category: 'Celebrations',
    image: classroomImg,
    caption: 'Patriotic song recitals, flag hoisting, and cultural performances.'
  },
  {
    id: 'g10',
    title: 'Festival of Lights Creative Workshop',
    category: 'Celebrations',
    image: playschoolImg,
    caption: 'Creative diya making, eco-friendly rangoli, and festive art activities.'
  }
];

export const schoolLifeEvents = [
  {
    title: 'Morning Assembly',
    desc: 'Beginning every day with unity, universal prayer, pledge, news analysis by students, and inspirational moral reflections.',
    icon: 'Sun'
  },
  {
    title: 'Classroom Learning',
    desc: 'Interactive lessons where every child is encouraged to ask questions, work with peers, and solve problems creatively.',
    icon: 'BookOpen'
  },
  {
    title: 'Art, Craft & Design',
    desc: 'Hands-on creative expression through painting, origami, clay modelling, recycling projects, and festive craftwork.',
    icon: 'Palette'
  },
  {
    title: 'Sports & Physical Fitness',
    desc: 'Daily physical training, yoga sessions, football, badminton, races, and inter-house friendly tournaments.',
    icon: 'Trophy'
  },
  {
    title: 'Music & Dance',
    desc: 'Vocal music, classical rhythm basics, action nursery songs, and folk dance workshops that build stage confidence.',
    icon: 'Music'
  },
  {
    title: 'Celebrations & Festivals',
    desc: 'Honoring Indian cultural festivals—Diwali, Eid, Christmas, Holi, Gurpurab, Janmashtami—with warmth and mutual respect.',
    icon: 'Sparkles'
  },
  {
    title: 'Annual Function & Sports Day',
    desc: 'Grand yearly events where 100% of students participate on stage or on the track in front of proud parents.',
    icon: 'Calendar'
  },
  {
    title: 'Field Trips & Nature Walks',
    desc: 'Guided visits to botanical gardens, post offices, science centers, and local fire stations for experiential real-world context.',
    icon: 'Compass'
  }
];

export const safetyMeasures = [
  {
    title: 'CCTV Surveillance',
    description: 'Strategically positioned cameras monitoring school entry gates, perimeter corridors, stairwells, and sports areas for student protection.'
  },
  {
    title: 'Secure School Entrance',
    description: 'Single main entry point with trained security guard personnel on duty during all operational school hours.'
  },
  {
    title: 'Controlled Visitor Entry',
    description: 'Mandatory visitor ID verification, purpose recording in visitor register, and visitor badge issuance before entering administrative wing.'
  },
  {
    title: 'Student Pickup & Drop Verification',
    description: 'Parents or authorized guardians must produce the school-issued Escort Card / Parent ID card when collecting students at dispersal.'
  },
  {
    title: 'Background-Verified Staff',
    description: 'All teachers, administrative personnel, transport drivers, and support housekeeping staff undergo police verification and reference checks.'
  },
  {
    title: 'Campus First-Aid & Emergency Tie-Up',
    description: 'Fully stocked first-aid medical dispensary, trained first-responder teachers, and formal partnership with an accredited nearby hospital.'
  },
  {
    title: 'Fire Safety Equipment',
    description: 'Regularly inspected ABC fire extinguishers, sand buckets, clearly marked fire exit pathways, and periodic safety drill practices.'
  },
  {
    title: 'RO Purified Drinking Water',
    description: 'Multi-stage RO + UV water purifiers with scheduled filter replacement and lab water testing to ensure 100% clean drinking water.'
  },
  {
    title: 'Hygienic, Child-Friendly Washrooms',
    description: 'Dedicated washrooms for boys, girls, and early years with non-slip flooring, low-height fixtures, and continuous sanitization protocols.'
  },
  {
    title: 'Continuous Staff Supervision',
    description: 'Floor teachers and female attendants supervise children during recess breaks, transit to labs, and washroom visits for early years.'
  },
  {
    title: 'Child-Safe Infrastructure',
    description: 'Smooth rounded edges on primary desks, safety window grills on upper floors, shock-proof concealed electrical switches, and non-toxic paint.'
  },
  {
    title: 'Emergency Contact Directory',
    description: 'Instant SMS communication system and dedicated emergency helpline phone numbers prominently displayed at all key locations.'
  }
];
