import React from 'react';
import { useSchool } from '../context/SchoolContext';

interface SchoolLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl' | number;
  className?: string;
  showText?: boolean;
  overrideName?: string;
  overrideEstd?: string;
}

export const SchoolLogo: React.FC<SchoolLogoProps> = ({
  size = 'md',
  className = '',
  showText = false,
  overrideName,
  overrideEstd
}) => {
  let schoolName = 'AARAMBH PUBLIC SCHOOL';
  let estdYear = '2012';

  try {
    const schoolContext = useSchool();
    if (schoolContext?.school?.name) {
      schoolName = schoolContext.school.name.toUpperCase();
    }
    if (schoolContext?.school?.establishedYear) {
      estdYear = schoolContext.school.establishedYear;
    }
  } catch {
    // Context fallback
  }

  if (overrideName) schoolName = overrideName.toUpperCase();
  if (overrideEstd) estdYear = overrideEstd;

  // Determine width based on size
  let width = 58;
  if (typeof size === 'number') {
    width = size;
  } else {
    switch (size) {
      case 'sm': width = 46; break;
      case 'md': width = 64; break;
      case 'lg': width = 96; break;
      case 'xl': width = 148; break;
    }
  }
  // Aspect ratio is 400:440 (1:1.1)
  const height = Math.round(width * 1.1);

  // Clean ribbon text: Truncate if extreme, but keep professional
  const ribbonText = schoolName.length > 24 ? schoolName.slice(0, 22) + '...' : schoolName;

  return (
    <div
      className={`school-crest-container ${className}`}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 12,
        position: 'relative',
        verticalAlign: 'middle',
        flexShrink: 0
      }}
      title={`${schoolName} (Estd. ${estdYear})`}
    >
      <svg
        width={width}
        height={height}
        viewBox="0 0 400 440"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        style={{ display: 'block' }}
      >
        <defs>
          {/* Exact color palette matching reference image */}
          {/* Arched text path for the bottom ribbon banner */}
          <path
            id="bannerTextCurve"
            d="M 90 388 Q 200 422 310 388"
            fill="none"
          />
        </defs>

        {/* =========================================================
            1. LAUREL WREATH (ACADEMIC EXCELLENCE)
            ========================================================= */}
        <g fill="#005088" stroke="#005088">
          {/* Left Wreath Branch Stem */}
          <path
            d="M 96 348 C 50 305 40 236 68 178"
            strokeWidth="5"
            strokeLinecap="round"
            fill="none"
          />
          {/* Left Leaf Clusters */}
          {/* Pair 1 - Bottom */}
          <path d="M 90 340 C 76 341 68 329 72 317 C 80 319 88 331 90 340 Z" />
          <path d="M 96 330 C 86 324 84 310 94 302 C 98 308 100 320 96 330 Z" />
          {/* Pair 2 */}
          <path d="M 75 308 C 61 305 55 291 61 279 C 69 283 75 295 75 308 Z" />
          <path d="M 83 298 C 75 288 77 274 89 270 C 89 280 89 292 83 298 Z" />
          {/* Pair 3 */}
          <path d="M 63 274 C 49 270 45 256 53 244 C 61 248 65 261 63 274 Z" />
          <path d="M 73 264 C 67 252 71 238 85 236 C 83 246 81 258 73 264 Z" />
          {/* Pair 4 */}
          <path d="M 57 238 C 45 232 45 218 55 208 C 63 214 63 227 57 238 Z" />
          <path d="M 69 228 C 65 216 73 202 85 204 C 83 214 77 222 69 228 Z" />
          {/* Pair 5 - Top */}
          <path d="M 59 202 C 51 192 55 178 67 172 C 71 180 69 194 59 202 Z" />
          <path d="M 71 194 C 69 182 81 170 91 174 C 87 184 79 190 71 194 Z" />
          <path d="M 73 172 C 73 160 83 150 91 156 C 89 164 81 170 73 172 Z" />

          {/* Right Wreath Branch Stem */}
          <path
            d="M 304 348 C 350 305 360 236 332 178"
            strokeWidth="5"
            strokeLinecap="round"
            fill="none"
          />
          {/* Right Leaf Clusters */}
          {/* Pair 1 - Bottom */}
          <path d="M 310 340 C 324 341 332 329 328 317 C 320 319 312 331 310 340 Z" />
          <path d="M 304 330 C 314 324 316 310 306 302 C 302 308 300 320 304 330 Z" />
          {/* Pair 2 */}
          <path d="M 325 308 C 339 305 345 291 339 279 C 331 283 325 295 325 308 Z" />
          <path d="M 317 298 C 325 288 323 274 311 270 C 311 280 311 292 317 298 Z" />
          {/* Pair 3 */}
          <path d="M 337 274 C 351 270 355 256 347 244 C 339 248 335 261 337 274 Z" />
          <path d="M 327 264 C 333 252 329 238 315 236 C 317 246 319 258 327 264 Z" />
          {/* Pair 4 */}
          <path d="M 343 238 C 355 232 355 218 345 208 C 337 214 337 227 343 238 Z" />
          <path d="M 331 228 C 335 216 327 202 315 204 C 317 214 323 222 331 228 Z" />
          {/* Pair 5 - Top */}
          <path d="M 341 202 C 349 192 345 178 333 172 C 329 180 331 194 341 202 Z" />
          <path d="M 329 194 C 331 182 319 170 309 174 C 313 184 321 190 329 194 Z" />
          <path d="M 327 172 C 327 160 317 150 309 156 C 311 164 319 170 327 172 Z" />
        </g>

        {/* =========================================================
            2. MAIN SHIELD OUTLINE (TRIPLE POINT APEX)
            ========================================================= */}
        {/* Shield Outer White Border & Navy Contour */}
        <path
          d="M 200 24 C 235 40 286 46 338 38 C 332 120 334 230 324 270 C 310 320 252 356 200 372 C 148 356 90 320 76 270 C 66 230 68 120 62 38 C 114 46 165 40 200 24 Z"
          fill="#FFFFFF"
          stroke="#005088"
          strokeWidth="6"
          strokeLinejoin="round"
        />

        {/* =========================================================
            3. TOP QUADRANT: VIBRANT INSTITUTIONAL ORANGE (#F26522)
               SUNBURST & FLAME OF KNOWLEDGE
            ========================================================= */}
        <g>
          {/* Top Orange Shield Polygon */}
          <path
            d="M 200 28 C 233 44 282 50 334 42 C 330 96 330 126 325 154 L 200 188 L 75 154 C 70 126 70 96 66 42 C 118 50 167 44 200 28 Z"
            fill="#F26522"
          />

          {/* Golden Sunburst Rays */}
          <g stroke="#FED000" strokeWidth="3.5" strokeLinecap="round" opacity="0.95">
            {/* Center Vertical Ray */}
            <line x1="200" y1="78" x2="200" y2="40" strokeWidth="4.5" />
            {/* Left Symmetrical Rays */}
            <line x1="186" y1="82" x2="170" y2="48" />
            <line x1="174" y1="92" x2="146" y2="62" />
            <line x1="164" y1="106" x2="128" y2="82" />
            <line x1="158" y1="122" x2="116" y2="108" />
            <line x1="156" y1="138" x2="112" y2="132" />
            {/* Right Symmetrical Rays */}
            <line x1="214" y1="82" x2="230" y2="48" />
            <line x1="226" y1="92" x2="254" y2="62" />
            <line x1="236" y1="106" x2="272" y2="82" />
            <line x1="242" y1="122" x2="284" y2="108" />
            <line x1="244" y1="138" x2="288" y2="132" />
          </g>

          {/* Central Sacred Flame (Torch of Wisdom) */}
          {/* Pure White Flame Silhouette */}
          <path
            d="M 200 80 C 188 98 174 116 186 138 C 192 148 208 148 214 138 C 226 116 212 98 200 80 Z"
            fill="#FFFFFF"
          />
          {/* Inner Orange Flame Core */}
          <path
            d="M 200 88 C 192 102 184 114 190 128 C 194 136 206 136 210 128 C 214 120 210 110 204 106 C 206 112 202 116 198 118 C 196 118 192 114 194 108 C 196 100 202 96 200 88 Z"
            fill="#F26522"
          />
        </g>

        {/* Crisp White Dividing Chevron Line */}
        <path
          d="M 73 154 L 200 188 L 327 154"
          stroke="#FFFFFF"
          strokeWidth="6"
          fill="none"
          strokeLinejoin="round"
        />

        {/* =========================================================
            4. LOWER BLUE SHIELD (#005088)
               SPLIT INTO LEFT & RIGHT PANELS
            ========================================================= */}
        <g>
          {/* Solid Blue Fill */}
          <path
            d="M 72 158 L 200 192 L 328 158 C 322 208 314 266 302 290 C 284 326 240 352 200 366 C 160 352 116 326 98 290 C 86 266 78 208 72 158 Z"
            fill="#005088"
          />

          {/* Center Vertical Divider (Spine of Open Book / Shield Quarters) */}
          <line
            x1="200"
            y1="190"
            x2="200"
            y2="364"
            stroke="#FFFFFF"
            strokeWidth="6"
          />

          {/* -------------------------------------------------------
              LEFT PANEL: INKPOT & QUILL FEATHER (WRITING & LITERATURE)
              ------------------------------------------------------- */}
          <g fill="#FFFFFF">
            {/* Inkpot Jar Base */}
            <path
              d="M 126 244 C 114 244 108 250 106 262 C 104 276 110 284 126 284 L 142 284 C 158 284 164 276 162 262 C 160 250 154 244 142 244 Z"
            />
            {/* Inkpot Neck */}
            <rect x="122" y="236" width="24" height="8" rx="3" fill="#FFFFFF" />
            {/* Quill Feather (45-degree angle pointing up-right) */}
            <path
              d="M 132 238 C 132 228 138 208 150 198 C 162 188 172 186 172 186 C 172 186 168 198 160 208 C 150 220 140 232 136 238 Z"
            />
            {/* Feather Vane Cutout Lines */}
            <line x1="142" y1="214" x2="154" y2="204" stroke="#005088" strokeWidth="2.5" strokeLinecap="round" />
            <line x1="148" y1="224" x2="160" y2="214" stroke="#005088" strokeWidth="2.5" strokeLinecap="round" />
          </g>

          {/* -------------------------------------------------------
              RIGHT PANEL: OPEN BOOK (KNOWLEDGE & STUDY)
              ------------------------------------------------------- */}
          <g fill="#FFFFFF">
            {/* Top Page Spread */}
            <path
              d="M 254 208 C 244 202 232 204 224 210 L 224 252 C 234 246 244 246 254 250 C 264 246 274 246 284 252 L 284 210 C 276 204 264 202 254 208 Z"
            />
            {/* Page Depth Leaves (Bottom edges) */}
            <path
              d="M 224 254 L 224 262 C 234 256 244 256 254 260 C 264 256 274 256 284 262 L 284 254 C 274 248 264 248 254 252 C 244 248 234 248 224 254 Z"
              opacity="0.95"
            />
            {/* Book Spine Line */}
            <line
              x1="254"
              y1="210"
              x2="254"
              y2="260"
              stroke="#005088"
              strokeWidth="3"
            />
            {/* Left Page Horizontal Lines */}
            <line x1="230" y1="222" x2="248" y2="218" stroke="#005088" strokeWidth="2" strokeLinecap="round" />
            <line x1="230" y1="232" x2="248" y2="228" stroke="#005088" strokeWidth="2" strokeLinecap="round" />
            <line x1="230" y1="242" x2="248" y2="238" stroke="#005088" strokeWidth="2" strokeLinecap="round" />
            {/* Right Page Horizontal Lines */}
            <line x1="260" y1="218" x2="278" y2="222" stroke="#005088" strokeWidth="2" strokeLinecap="round" />
            <line x1="260" y1="228" x2="278" y2="232" stroke="#005088" strokeWidth="2" strokeLinecap="round" />
            <line x1="260" y1="238" x2="278" y2="242" stroke="#005088" strokeWidth="2" strokeLinecap="round" />
          </g>
        </g>

        {/* =========================================================
            5. ESTD BADGE (CLEAN INSTITUTIONAL TYPOGRAPHY)
            ========================================================= */}
        <text
          x="200"
          y="354"
          textAnchor="middle"
          fill="#005088"
          fontFamily="system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif"
          fontWeight="800"
          fontSize="14"
          letterSpacing="1px"
        >
          ESTD: {estdYear}
        </text>

        {/* =========================================================
            6. CLASSIC RIBBON BANNER WITH GOLD TRIM & STARS
            ========================================================= */}
        <g id="academicRibbonBanner">
          {/* Left Ribbon Swallowtail Fold */}
          <path
            d="M 80 352 L 54 358 L 70 376 L 52 396 L 88 390 L 84 358 Z"
            fill="#005088"
            stroke="#F5A623"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />
          {/* Left Star */}
          <path
            d="M 66 370 L 68.5 375 L 74 376 L 70 380 L 71 385.5 L 66 383 L 61 385.5 L 62 380 L 58 376 L 63.5 375 Z"
            fill="#FED000"
          />

          {/* Right Ribbon Swallowtail Fold */}
          <path
            d="M 320 352 L 346 358 L 330 376 L 348 396 L 312 390 L 316 358 Z"
            fill="#005088"
            stroke="#F5A623"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />
          {/* Right Star */}
          <path
            d="M 334 370 L 336.5 375 L 342 376 L 338 380 L 339 385.5 L 334 383 L 329 385.5 L 330 380 L 326 376 L 331.5 375 Z"
            fill="#FED000"
          />

          {/* Main Ribbon Arch Body */}
          <path
            d="M 74 354 C 132 370 268 370 326 354 L 322 398 C 268 418 132 418 78 398 Z"
            fill="#005088"
            stroke="#F5A623"
            strokeWidth="3"
            strokeLinejoin="round"
          />

          {/* Inner Golden Border Accents */}
          <path
            d="M 80 360 C 134 376 266 376 320 360 M 82 392 C 134 410 266 410 318 392"
            stroke="#FED000"
            strokeWidth="1.5"
            fill="none"
            opacity="0.9"
          />

          {/* Institution Name Along Banner Path */}
          <text
            fill="#FFFFFF"
            fontSize={ribbonText.length > 20 ? "15" : "17"}
            fontWeight="900"
            fontFamily="system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif"
            letterSpacing="0.8px"
          >
            <textPath
              href="#bannerTextCurve"
              startOffset="50%"
              textAnchor="middle"
            >
              {ribbonText}
            </textPath>
          </text>
        </g>
      </svg>

      {showText && (
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <span
            style={{
              fontFamily: 'var(--font-heading)',
              fontWeight: 800,
              fontSize: '1.1875rem',
              letterSpacing: '-0.02em',
              color: '#FFFFFF',
              lineHeight: 1.2
            }}
          >
            {schoolName}
          </span>
          <span
            style={{
              fontSize: '0.75rem',
              fontWeight: 700,
              letterSpacing: '0.06em',
              color: '#FCD34D',
              textTransform: 'uppercase',
              marginTop: 2
            }}
          >
            Play School • Classes 1 to 8 • Estd. {estdYear}
          </span>
        </div>
      )}
    </div>
  );
};
