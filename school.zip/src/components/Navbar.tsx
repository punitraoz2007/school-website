import React, { useState, useRef, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Phone,
  Mail,
  Clock,
  Menu,
  X,
  ArrowRight,
  ShieldCheck,
  GraduationCap,
  ChevronDown,
  Camera,
  Users,
  BookOpen,
  Calendar,
  MessageSquare,
  Sparkles
} from 'lucide-react';
import { useSchool } from '../context/SchoolContext';
import { SchoolLogo } from './SchoolLogo';

interface NavbarProps {
  onOpenAdmissionModal: () => void;
  onOpenWelcomeEntrance?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenAdmissionModal, onOpenWelcomeEntrance }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMoreDropdownOpen, setIsMoreDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const location = useLocation();
  const { school } = useSchool();

  const primaryNavLinks = [
    { label: 'Home', path: '/' },
    { label: 'About Us', path: '/about' },
    { label: 'Academics', path: '/academics' },
    { label: 'Facilities', path: '/facilities' },
    { label: 'Safety', path: '/safety' },
    { label: 'Admissions', path: '/admissions' }
  ];

  const moreNavLinks = [
    { label: 'School Life & Houses', path: '/school-life', icon: Calendar },
    { label: 'Photo Gallery', path: '/gallery', icon: Camera },
    { label: 'Faculty & Teachers', path: '/faculty', icon: Users },
    { label: 'Parents Corner & Rules', path: '/parents', icon: BookOpen },
    { label: 'Contact Us', path: '/contact', icon: MessageSquare }
  ];

  const allMobileNavLinks = [
    ...primaryNavLinks,
    ...moreNavLinks
  ];

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsMoreDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Close dropdown on route change
  useEffect(() => {
    setIsMoreDropdownOpen(false);
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const isActive = (path: string) => {
    if (path === '/' && location.pathname === '/') return true;
    if (path !== '/' && location.pathname.startsWith(path)) return true;
    return false;
  };

  const isMoreActive = moreNavLinks.some(link => isActive(link.path));

  const closeMenu = () => setIsMobileMenuOpen(false);

  return (
    <>
      {/* Top Notice Strip */}
      <div className="top-notice-strip">
        <div className="container">
          <div className="top-notice-inner">
            <div className="top-notice-left">
              <span className="top-notice-badge">Admissions Open 2026-27</span>
              <div className="top-notice-item">
                <GraduationCap size={14} />
                <span>Play School to Class 8 • {school.board}</span>
              </div>
            </div>
            <div className="top-notice-right">
              <Link
                to="/admin"
                className="top-notice-item"
                style={{ color: '#FCD34D', fontWeight: 600, textDecoration: 'none' }}
                title="View all submitted parent enquiries and visit bookings"
              >
                <span>✦ Parent Enquiries (Admin)</span>
              </Link>
              <div className="top-notice-item">
                <Clock size={14} />
                <span>Office: {school.officeTiming}</span>
              </div>
              <div className="top-notice-item">
                <Phone size={14} />
                <a href={`tel:${school.phone}`}>{school.phone}</a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Sticky Header */}
      <header className="site-header">
        <div className="container">
          <div className="navbar-container">
            {/* Zone 1: Single Brand Zone */}
            <Link to="/" className="brand-zone" onClick={closeMenu}>
              <SchoolLogo size="sm" />
              <div className="brand-text">
                <span className="brand-name">{school.name}</span>
                <span className="brand-subtitle">Play School • Nursery • Classes 1 to 8</span>
              </div>
            </Link>

            {/* Zone 2: Navigation Links (Primary + More Dropdown) */}
            <nav className="nav-links">
              {primaryNavLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`nav-link ${isActive(link.path) ? 'active' : ''}`}
                >
                  {link.label}
                </Link>
              ))}

              {/* More Dropdown */}
              <div className="nav-dropdown-wrapper" ref={dropdownRef}>
                <button
                  type="button"
                  className={`nav-dropdown-btn ${isMoreActive ? 'active' : ''}`}
                  onClick={() => setIsMoreDropdownOpen(!isMoreDropdownOpen)}
                  aria-expanded={isMoreDropdownOpen}
                >
                  <span>More</span>
                  <ChevronDown size={14} style={{ transform: isMoreDropdownOpen ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }} />
                </button>

                {isMoreDropdownOpen && (
                  <div className="nav-dropdown-menu">
                    {moreNavLinks.map((item) => {
                      const Icon = item.icon;
                      return (
                        <Link
                          key={item.path}
                          to={item.path}
                          className={`nav-dropdown-item ${isActive(item.path) ? 'active' : ''}`}
                          onClick={() => setIsMoreDropdownOpen(false)}
                        >
                          <Icon size={16} color="var(--color-primary)" />
                          <span>{item.label}</span>
                        </Link>
                      );
                    })}
                  </div>
                )}
              </div>
            </nav>

            {/* Zone 3: Primary Action & Mobile Menu Toggle */}
            <div className="header-actions">
              <button
                type="button"
                className="btn btn-accent btn-sm header-cta-btn"
                onClick={onOpenAdmissionModal}
              >
                <span className="header-cta-full">Admission Enquiry</span>
                <span className="header-cta-mobile">Enquire</span>
              </button>

              <button
                type="button"
                className="mobile-menu-toggle"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                aria-label="Toggle menu"
              >
                {isMobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Slide-in Drawer */}
      {isMobileMenuOpen && (
        <>
          <div className="mobile-drawer-overlay" onClick={closeMenu} />
          <aside className="mobile-drawer">
            <div className="mobile-drawer-header">
              <div className="brand-zone" style={{ gap: 10 }}>
                <SchoolLogo size="md" />
                <div className="brand-text">
                  <span className="brand-name" style={{ fontSize: '1rem', lineHeight: 1.15 }}>{school.name}</span>
                  <span className="brand-subtitle" style={{ fontSize: '0.75rem' }}>Estd. {school.establishedYear} • Classes 1-8</span>
                </div>
              </div>
              <button
                type="button"
                className="modal-close-btn"
                onClick={closeMenu}
                aria-label="Close menu"
              >
                <X size={20} />
              </button>
            </div>

            <div className="mobile-drawer-links">
              {allMobileNavLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`mobile-nav-link ${isActive(link.path) ? 'active' : ''}`}
                  onClick={closeMenu}
                >
                  <span>{link.label}</span>
                  <ArrowRight size={14} color="#94A3B8" />
                </Link>
              ))}
            </div>

            <div className="mobile-drawer-footer">
              <Link
                to="/admin"
                className="btn btn-secondary btn-sm"
                style={{ textAlign: 'center', marginBottom: 6 }}
                onClick={closeMenu}
              >
                ✦ Admin Enquiries Inbox
              </Link>
              <button
                type="button"
                className="btn btn-accent"
                style={{ width: '100%' }}
                onClick={() => {
                  closeMenu();
                  onOpenAdmissionModal();
                }}
              >
                Apply for Admission
              </button>
              <div style={{ fontSize: '0.8125rem', color: '#64748B', textAlign: 'center', marginTop: 8 }}>
                <a href={`tel:${school.phone}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                  <Phone size={13} /> {school.phone}
                </a>
              </div>
            </div>
          </aside>
        </>
      )}
    </>
  );
};
