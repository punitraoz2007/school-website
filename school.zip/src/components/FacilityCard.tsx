import React, { useState } from 'react';
import {
  Monitor,
  Video,
  Wind,
  Shield,
  Laptop,
  FlaskConical,
  BookOpen,
  Palette,
  Trophy,
  Droplet,
  Sparkles,
  HeartPulse,
  Bus,
  Users
} from 'lucide-react';

interface FacilityCardProps {
  id: string;
  title: string;
  category: string;
  image?: string | null;
  description: string;
}

export const FacilityCard: React.FC<FacilityCardProps> = ({
  id,
  title,
  category,
  image,
  description
}) => {
  const [imageError, setImageError] = useState(false);

  const getCategoryIcon = () => {
    switch (id) {
      case 'smart-classrooms': return <Monitor size={36} />;
      case 'cctv-surveillance': return <Video size={36} />;
      case 'well-maintained-classrooms': return <Wind size={36} />;
      case 'safe-school-campus': return <Shield size={36} />;
      case 'computer-lab': return <Laptop size={36} />;
      case 'science-learning': return <FlaskConical size={36} />;
      case 'library': return <BookOpen size={36} />;
      case 'activity-room': return <Palette size={36} />;
      case 'playground': return <Trophy size={36} />;
      case 'drinking-water': return <Droplet size={36} />;
      case 'clean-washrooms': return <Sparkles size={36} />;
      case 'first-aid': return <HeartPulse size={36} />;
      case 'transportation': return <Bus size={36} />;
      case 'reception-area': return <Users size={36} />;
      default: return <BookOpen size={36} />;
    }
  };

  return (
    <div className="facility-card">
      <div className="facility-image-wrapper">
        {image && !imageError ? (
          <img
            src={image}
            alt={title}
            referrerPolicy="no-referrer"
            onError={() => setImageError(true)}
            loading="lazy"
          />
        ) : (
          <div
            style={{
              width: '100%',
              height: '100%',
              background: 'linear-gradient(135deg, #1E3A8A 0%, #2563EB 100%)',
              color: '#FFFFFF',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              padding: 20,
              textAlign: 'center'
            }}
          >
            <div style={{ color: '#FCD34D', marginBottom: 8 }}>
              {getCategoryIcon()}
            </div>
            <span style={{ fontSize: '0.9375rem', fontWeight: 700, letterSpacing: '-0.01em' }}>
              {title}
            </span>
          </div>
        )}
        <span className="facility-badge">{category}</span>
      </div>

      <div className="facility-content">
        <h3 className="facility-title">{title}</h3>
        <p className="facility-desc">{description}</p>
      </div>
    </div>
  );
};
