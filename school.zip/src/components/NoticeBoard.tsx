import React, { useState } from 'react';
import { Bell, Download, Calendar, Tag, ChevronRight, Check } from 'lucide-react';
import { noticeBoardItems } from '../data/schoolData';
import { useSchool } from '../context/SchoolContext';

export const NoticeBoard: React.FC = () => {
  const { school } = useSchool();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  const categories = ['All', 'Admissions', 'Events', 'Holidays', 'Meetings', 'Academic'];

  const filteredNotices = selectedCategory === 'All'
    ? noticeBoardItems
    : noticeBoardItems.filter(item => item.category.toLowerCase() === selectedCategory.toLowerCase());

  const handleDownload = (filename: string) => {
    setDownloadSuccess(filename);

    const fileContent = `=====================================================
${school.name.toUpperCase()}
Play School, Nursery, LKG, UKG & Classes 1 to 8
Affiliation: ${school.board} (${school.affiliationNumber})
Address: ${school.address}, ${school.cityState} - ${school.pincode}
Contact: ${school.phone} | ${school.email}
=====================================================

DOCUMENT: ${filename.replace(/_/g, ' ').replace('.pdf', '')}
Date: March 2026

Dear Parents & Guardians,

Please find the official circular and directives from the Head of School.
1. Admissions are open for Play School to Class 8 for Session 2026-27.
2. Timings: Early Years 8:30 AM - 12:30 PM | Primary & Middle 7:45 AM - 2:15 PM.
3. For any clarifications, please reach the Administrative Office during working hours (8:00 AM to 3:30 PM).

By Order,
Principal & Management Desk
${school.name}
=====================================================`;

    const blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    setTimeout(() => {
      setDownloadSuccess(null);
    }, 4000);
  };

  return (
    <div className="notice-board-card">
      <div className="notice-board-header">
        <div className="notice-board-title">
          <Bell size={22} color="#FCD34D" />
          <span>Official Notice Board & Circulars</span>
        </div>

        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              style={{
                fontSize: '0.75rem',
                fontWeight: 600,
                padding: '4px 10px',
                borderRadius: 'var(--radius-sm)',
                color: selectedCategory === cat ? '#0F172A' : '#FFFFFF',
                backgroundColor: selectedCategory === cat ? '#FCD34D' : 'rgba(255, 255, 255, 0.12)',
                border: 'none',
                cursor: 'pointer',
                transition: 'all 0.15s ease'
              }}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {downloadSuccess && (
        <div
          style={{
            backgroundColor: 'var(--color-success-soft)',
            padding: '10px 24px',
            fontSize: '0.8125rem',
            color: '#065F46',
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            borderBottom: '1px solid #A7F3D0'
          }}
        >
          <Check size={16} />
          <span>Downloading <strong>{downloadSuccess}</strong> (Simulated school circular document).</span>
        </div>
      )}

      <div className="notice-list">
        {filteredNotices.map((notice) => {
          const [month, day, year] = notice.date.split(' ');
          return (
            <div key={notice.id} className="notice-item">
              <div className="notice-date-badge">
                <div className="notice-date-day">{day ? day.replace(',', '') : '15'}</div>
                <div className="notice-date-sub">{month} {year}</div>
              </div>

              <div className="notice-content">
                <div className="notice-meta">
                  <span className="notice-tag">{notice.category}</span>
                  {notice.isNew && <span className="notice-new-badge">New</span>}
                </div>

                <h4 className="notice-title">{notice.title}</h4>
                <p className="notice-summary">{notice.summary}</p>

                {notice.attachment && (
                  <button
                    type="button"
                    className="notice-attachment-btn"
                    onClick={() => handleDownload(notice.attachment)}
                  >
                    <Download size={13} />
                    <span>Download {notice.attachment}</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
