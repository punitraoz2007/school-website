import React, { useState, useEffect } from 'react';
import { X, CheckCircle, GraduationCap, Calendar, Phone, Mail, User, MapPin } from 'lucide-react';
import { useSchool } from '../context/SchoolContext';
import { saveAdmissionEnquiry } from '../services/enquiryStorage';

interface AdmissionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdmissionModal: React.FC<AdmissionModalProps> = ({ isOpen, onClose }) => {
  const { school } = useSchool();
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [generatedId, setGeneratedId] = useState('');
  const [formData, setFormData] = useState({
    parentName: '',
    studentName: '',
    dob: '',
    applyingClass: 'Play School',
    phone: '',
    email: '',
    address: '',
    previousSchool: '',
    message: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.parentName.trim()) errs.parentName = 'Parent name is required';
    if (!formData.studentName.trim()) errs.studentName = 'Student name is required';
    if (!formData.dob) errs.dob = 'Date of birth is required';
    if (!formData.phone.trim()) {
      errs.phone = 'Contact phone number is required';
    } else if (!/^[0-9+\s-]{8,15}$/.test(formData.phone.trim())) {
      errs.phone = 'Please enter a valid phone number';
    }
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      errs.email = 'Please enter a valid email address';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      const record = saveAdmissionEnquiry(formData);
      setGeneratedId(record.id);
      setIsSubmitted(true);
    }
  };

  const handleResetAndClose = () => {
    setIsSubmitted(false);
    setFormData({
      parentName: '',
      studentName: '',
      dob: '',
      applyingClass: 'Play School',
      phone: '',
      email: '',
      address: '',
      previousSchool: '',
      message: ''
    });
    setErrors({});
    onClose();
  };

  return (
    <div className="modal-backdrop" onClick={handleResetAndClose}>
      <div className="modal-card" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <GraduationCap size={22} color="var(--color-primary)" />
            <div>
              <h3 className="modal-title">Online Admission Enquiry (2026-27)</h3>
              <p style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)', margin: 0 }}>
                {school.name} • {school.classes}
              </p>
            </div>
          </div>
          <button type="button" className="modal-close-btn" onClick={handleResetAndClose} aria-label="Close modal">
            <X size={20} />
          </button>
        </div>

        <div className="modal-body">
          {isSubmitted ? (
            <div style={{ textAlign: 'center', padding: '24px 12px' }}>
              <CheckCircle size={56} color="#059669" style={{ margin: '0 auto 16px auto' }} />
              <h3 style={{ fontSize: '1.375rem', color: 'var(--color-primary-dark)', marginBottom: 8 }}>
                Enquiry Submitted Successfully!
              </h3>
              <p style={{ fontSize: '0.9375rem', color: 'var(--color-text-muted)', marginBottom: 18, lineHeight: 1.6 }}>
                Thank you, <strong>{formData.parentName}</strong>. We have received your admission enquiry for{' '}
                <strong>{formData.studentName}</strong> for <strong>{formData.applyingClass}</strong>.
              </p>
              <div
                style={{
                  backgroundColor: 'var(--color-primary-soft)',
                  padding: '16px',
                  borderRadius: 8,
                  fontSize: '0.875rem',
                  color: 'var(--color-primary-dark)',
                  marginBottom: 24,
                  textAlign: 'left'
                }}
              >
                <div style={{ fontWeight: 700, marginBottom: 4 }}>Next Steps:</div>
                <ul style={{ paddingLeft: 18, margin: 0, lineHeight: 1.6 }}>
                  <li>Our admissions counsellor will call you on <strong>{formData.phone}</strong> within 24 working hours.</li>
                  <li>You may also schedule an in-person school campus visit at your convenience.</li>
                  <li>Reference Enquiry ID: <strong>{generatedId || `APS-${Math.floor(100000 + Math.random() * 900000)}`}</strong></li>
                </ul>
              </div>

              <button type="button" className="btn btn-primary" onClick={handleResetAndClose}>
                Done & Return to Website
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', marginBottom: 20 }}>
                Please fill in the details below. Our admissions desk will promptly contact you with prospectus details and assessment schedules.
              </p>

              <div className="form-grid-2">
                <div className="form-group">
                  <label className="form-label">Parent / Guardian Name *</label>
                  <input
                    type="text"
                    name="parentName"
                    value={formData.parentName}
                    onChange={handleChange}
                    className="form-input"
                    placeholder="e.g. Ramesh Sharma"
                  />
                  {errors.parentName && <span className="form-error">{errors.parentName}</span>}
                </div>

                <div className="form-group">
                  <label className="form-label">Student Name *</label>
                  <input
                    type="text"
                    name="studentName"
                    value={formData.studentName}
                    onChange={handleChange}
                    className="form-input"
                    placeholder="e.g. Aarav Sharma"
                  />
                  {errors.studentName && <span className="form-error">{errors.studentName}</span>}
                </div>
              </div>

              <div className="form-grid-2">
                <div className="form-group">
                  <label className="form-label">Student Date of Birth *</label>
                  <input
                    type="date"
                    name="dob"
                    value={formData.dob}
                    onChange={handleChange}
                    className="form-input"
                  />
                  {errors.dob && <span className="form-error">{errors.dob}</span>}
                </div>

                <div className="form-group">
                  <label className="form-label">Class Applying For *</label>
                  <select
                    name="applyingClass"
                    value={formData.applyingClass}
                    onChange={handleChange}
                    className="form-select"
                  >
                    <optgroup label="Early Years">
                      <option value="Play School">Play School (Age 2+)</option>
                      <option value="Nursery">Nursery (Age 3+)</option>
                      <option value="LKG">LKG (Lower Kindergarten)</option>
                      <option value="UKG">UKG (Upper Kindergarten)</option>
                    </optgroup>
                    <optgroup label="Primary Wing">
                      <option value="Class 1">Class 1</option>
                      <option value="Class 2">Class 2</option>
                      <option value="Class 3">Class 3</option>
                      <option value="Class 4">Class 4</option>
                      <option value="Class 5">Class 5</option>
                    </optgroup>
                    <optgroup label="Middle School">
                      <option value="Class 6">Class 6</option>
                      <option value="Class 7">Class 7</option>
                      <option value="Class 8">Class 8</option>
                    </optgroup>
                  </select>
                </div>
              </div>

              <div className="form-grid-2">
                <div className="form-group">
                  <label className="form-label">Parent Phone Number *</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="form-input"
                    placeholder="+91 98765 43210"
                  />
                  {errors.phone && <span className="form-error">{errors.phone}</span>}
                </div>

                <div className="form-group">
                  <label className="form-label">Email Address (Optional)</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="form-input"
                    placeholder="parent@example.com"
                  />
                  {errors.email && <span className="form-error">{errors.email}</span>}
                </div>
              </div>

              <div className="form-grid-2">
                <div className="form-group">
                  <label className="form-label">Previous School Attended (If any)</label>
                  <input
                    type="text"
                    name="previousSchool"
                    value={formData.previousSchool}
                    onChange={handleChange}
                    className="form-input"
                    placeholder="e.g. Kidzee / Little Angels"
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Residential Area / Locality</label>
                  <input
                    type="text"
                    name="address"
                    value={formData.address}
                    onChange={handleChange}
                    className="form-input"
                    placeholder="e.g. Sector 14, Gurugram"
                  />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Message / Queries</label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  className="form-textarea"
                  rows={3}
                  placeholder="Tell us about your child's interests or questions regarding curriculum, bus transport, or school hours..."
                />
              </div>

              <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end', marginTop: 16 }}>
                <button type="button" className="btn btn-secondary" onClick={handleResetAndClose}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Submit Enquiry
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
