import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Phone, Mail, Clock, ShieldCheck, Heart, Settings } from 'lucide-react';
import { useSchool } from '../context/SchoolContext';
import { SchoolLogo } from './SchoolLogo';

interface FooterProps {
  onOpenCustomizer?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenCustomizer }) => {
  const { school, setIsCustomizerOpen } = useSchool();

  return (
    <footer className="site-footer">
      <div className="container">
        <div className="footer-grid">
          {/* Col 1: School Identity */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 16 }}>
              <SchoolLogo size="md" />
              <div>
                <h3 style={{ fontSize: '1.25rem', color: '#FFFFFF', margin: 0, fontWeight: 800 }}>
                  {school.name}
                </h3>
                <span style={{ fontSize: '0.75rem', color: '#FCD34D', fontWeight: 600 }}>
                  Play School & Classes 1 to 8
                </span>
              </div>
            </div>

            <p style={{ color: '#94A3B8', fontSize: '0.875rem', marginBottom: 18, lineHeight: 1.6 }}>
              {school.tagline}. A caring, disciplined and modern educational institution shaping young minds through joyful early learning and strong primary-middle school fundamentals.
            </p>

            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: '0.8125rem', color: '#CBD5E1', backgroundColor: '#1E293B', padding: '6px 12px', borderRadius: 6 }}>
              <ShieldCheck size={15} color="#10B981" />
              <span>Affiliation / Reg: {school.affiliationNumber}</span>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div>
            <h4 className="footer-col-title">Quick Links</h4>
            <ul className="footer-links">
              <li><Link to="/about">About Our School</Link></li>
              <li><Link to="/academics">Academic Curriculum</Link></li>
              <li><Link to="/facilities">School Facilities</Link></li>
              <li><Link to="/safety">Safety & Child Security</Link></li>
              <li><Link to="/admissions">Admissions 2026-27</Link></li>
              <li><Link to="/gallery">Photo Gallery</Link></li>
              <li><Link to="/faculty">Teachers & Faculty</Link></li>
              <li><Link to="/contact">Contact & Location</Link></li>
              <li><Link to="/admin" style={{ color: '#FCD34D', fontWeight: 600 }}>✦ Admin Enquiries Inbox</Link></li>
            </ul>
          </div>

          {/* Col 3: For Parents & Timings */}
          <div>
            <h4 className="footer-col-title">Parent Information</h4>
            <ul className="footer-links" style={{ marginBottom: 18 }}>
              <li><Link to="/parents">Notice Board & Circulars</Link></li>
              <li><Link to="/parents">School Timings & Calendar</Link></li>
              <li><Link to="/parents">Uniform & Discipline</Link></li>
              <li><Link to="/admissions">Fee Structure & Enquiries</Link></li>
              <li><Link to="/school-life">School Life & Events</Link></li>
            </ul>

            <div style={{ borderTop: '1px solid #1E293B', paddingTop: 14 }}>
              <div style={{ fontSize: '0.75rem', textTransform: 'uppercase', color: '#64748B', fontWeight: 700, marginBottom: 4 }}>
                Visiting Hours
              </div>
              <p style={{ fontSize: '0.8125rem', color: '#94A3B8', margin: 0 }}>
                {school.visitingHours}
              </p>
            </div>
          </div>

          {/* Col 4: Contact & Location */}
          <div>
            <h4 className="footer-col-title">Get in Touch</h4>
            
            <div className="footer-contact-item">
              <MapPin size={18} color="#FCD34D" style={{ flexShrink: 0, marginTop: 2 }} />
              <span>{school.address}, {school.cityState} - {school.pincode}</span>
            </div>

            <div className="footer-contact-item">
              <Phone size={16} color="#FCD34D" style={{ flexShrink: 0, marginTop: 2 }} />
              <div>
                <a href={`tel:${school.phone}`} style={{ color: '#FFFFFF', fontWeight: 600 }}>{school.phone}</a>
                <div style={{ fontSize: '0.75rem', color: '#64748B' }}>Alternate: {school.alternatePhone}</div>
              </div>
            </div>

            <div className="footer-contact-item">
              <Mail size={16} color="#FCD34D" style={{ flexShrink: 0, marginTop: 2 }} />
              <div>
                <a href={`mailto:${school.email}`} style={{ color: '#FFFFFF' }}>{school.email}</a>
              </div>
            </div>

            <div className="footer-social-strip">
              <a
                href="#social"
                className="social-icon-btn"
                title="Facebook"
                aria-label="Facebook"
                onClick={(e) => { e.preventDefault(); alert('Redirecting to School Official Facebook page'); }}
              >
                F
              </a>
              <a
                href="#social"
                className="social-icon-btn"
                title="Instagram"
                aria-label="Instagram"
                onClick={(e) => { e.preventDefault(); alert('Redirecting to School Official Instagram handle'); }}
              >
                I
              </a>
              <a
                href="#social"
                className="social-icon-btn"
                title="YouTube"
                aria-label="YouTube"
                onClick={(e) => { e.preventDefault(); alert('Redirecting to School Official YouTube channel'); }}
              >
                Y
              </a>
            </div>
          </div>
        </div>

        {/* Footer Bottom */}
        <div className="footer-bottom">
          <div>
            © {new Date().getFullYear()} {school.name}. All Rights Reserved. Recognized by Directorate of Education.
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <button
              type="button"
              onClick={() => setIsCustomizerOpen(true)}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: 6,
                fontSize: '0.8125rem',
                color: '#FCD34D',
                background: 'rgba(255, 255, 255, 0.08)',
                border: '1px solid rgba(255, 255, 255, 0.15)',
                padding: '4px 10px',
                borderRadius: 4
              }}
            >
              <Settings size={13} /> Edit School Details
            </button>
            <span style={{ fontSize: '0.8125rem', color: '#94A3B8' }}>
              Play School + Classes 1 to 8
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
