import React, { useState, useEffect } from 'react';
import { X, CheckCircle, Calendar, Clock, MapPin, Phone } from 'lucide-react';
import { useSchool } from '../context/SchoolContext';
import { saveCampusVisit } from '../services/enquiryStorage';

interface BookVisitModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BookVisitModal: React.FC<BookVisitModalProps> = ({ isOpen, onClose }) => {
  const { school } = useSchool();
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [generatedId, setGeneratedId] = useState('');
  const [visitData, setVisitData] = useState({
    parentName: '',
    phone: '',
    email: '',
    childClass: 'Play School',
    visitDate: '',
    timeSlot: '10:00 AM - 11:00 AM',
    notes: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setVisitData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!visitData.parentName.trim()) errs.parentName = 'Parent name is required';
    if (!visitData.phone.trim()) {
      errs.phone = 'Phone number is required';
    } else if (!/^[0-9+\s-]{8,15}$/.test(visitData.phone.trim())) {
      errs.phone = 'Please enter a valid phone number';
    }
    if (!visitData.visitDate) errs.visitDate = 'Please select a preferred visit date';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      const record = saveCampusVisit(visitData);
      setGeneratedId(record.id);
      setIsSubmitted(true);
    }
  };

  const handleResetAndClose = () => {
    setIsSubmitted(false);
    setVisitData({
      parentName: '',
      phone: '',
      email: '',
      childClass: 'Play School',
      visitDate: '',
      timeSlot: '10:00 AM - 11:00 AM',
      notes: ''
    });
    setErrors({});
    onClose();
  };

  return (
    <div className="modal-backdrop" onClick={handleResetAndClose}>
      <div className="modal-card" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Calendar size={22} color="var(--color-primary)" />
            <div>
              <h3 className="modal-title">Book a School Campus Visit</h3>
              <p style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)', margin: 0 }}>
                Experience our classrooms, play area & facilities in person
              </p>
            </div>
          </div>
          <button type="button" className="modal-close-btn" onClick={handleResetAndClose} aria-label="Close modal">
            <X size={20} />
          </button>
        </div>

        <div className="modal-body">
          {isSubmitted ? (
            <div style={{ textAlign: 'center', padding: '24px 12px' }}>
              <CheckCircle size={56} color="#059669" style={{ margin: '0 auto 16px auto' }} />
              <h3 style={{ fontSize: '1.375rem', color: 'var(--color-primary-dark)', marginBottom: 8 }}>
                Campus Visit Scheduled!
              </h3>
              <p style={{ fontSize: '0.9375rem', color: 'var(--color-text-muted)', marginBottom: 18, lineHeight: 1.6 }}>
                Dear <strong>{visitData.parentName}</strong>, your campus tour has been tentatively scheduled for{' '}
                <strong>{visitData.visitDate}</strong> during slot <strong>{visitData.timeSlot}</strong>.
              </p>
              <div
                style={{
                  backgroundColor: 'var(--color-primary-soft)',
                  padding: '16px',
                  borderRadius: 8,
                  fontSize: '0.875rem',
                  color: 'var(--color-primary-dark)',
                  marginBottom: 24,
                  textAlign: 'left'
                }}
              >
                <div style={{ fontWeight: 700, marginBottom: 6 }}>Campus Address & Details:</div>
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginBottom: 6 }}>
                  <MapPin size={16} style={{ flexShrink: 0, marginTop: 2 }} />
                  <span>{school.address}, {school.cityState}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <Phone size={16} />
                  <span>Reception Helpline: {school.phone}</span>
                </div>
              </div>

              <button type="button" className="btn btn-primary" onClick={handleResetAndClose}>
                Return to Website
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <div className="form-grid-2">
                <div className="form-group">
                  <label className="form-label">Parent / Guardian Name *</label>
                  <input
                    type="text"
                    name="parentName"
                    value={visitData.parentName}
                    onChange={handleChange}
                    className="form-input"
                    placeholder="e.g. Priya Nair"
                  />
                  {errors.parentName && <span className="form-error">{errors.parentName}</span>}
                </div>

                <div className="form-group">
                  <label className="form-label">Phone Number *</label>
                  <input
                    type="tel"
                    name="phone"
                    value={visitData.phone}
                    onChange={handleChange}
                    className="form-input"
                    placeholder="+91 98765 43210"
                  />
                  {errors.phone && <span className="form-error">{errors.phone}</span>}
                </div>
              </div>

              <div className="form-grid-2">
                <div className="form-group">
                  <label className="form-label">Interested Class Grade *</label>
                  <select
                    name="childClass"
                    value={visitData.childClass}
                    onChange={handleChange}
                    className="form-select"
                  >
                    <option value="Play School">Play School (2 to 3 yrs)</option>
                    <option value="Nursery / KG">Nursery / KG</option>
                    <option value="Primary (Class 1 to 5)">Primary (Class 1 to 5)</option>
                    <option value="Middle School (Class 6 to 8)">Middle School (Class 6 to 8)</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Preferred Date *</label>
                  <input
                    type="date"
                    name="visitDate"
                    value={visitData.visitDate}
                    onChange={handleChange}
                    className="form-input"
                  />
                  {errors.visitDate && <span className="form-error">{errors.visitDate}</span>}
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Preferred Time Slot *</label>
                <select
                  name="timeSlot"
                  value={visitData.timeSlot}
                  onChange={handleChange}
                  className="form-select"
                >
                  <option value="9:00 AM - 10:00 AM">9:00 AM - 10:00 AM (Morning Tour)</option>
                  <option value="10:00 AM - 11:00 AM">10:00 AM - 11:00 AM</option>
                  <option value="11:30 AM - 12:30 PM">11:30 AM - 12:30 PM</option>
                  <option value="1:30 PM - 2:30 PM">1:30 PM - 2:30 PM (Afternoon Tour)</option>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Specific questions or areas you wish to see?</label>
                <textarea
                  name="notes"
                  value={visitData.notes}
                  onChange={handleChange}
                  className="form-textarea"
                  rows={2}
                  placeholder="e.g. Would love to inspect the play area, meet the primary teachers, or discuss school bus routes..."
                />
              </div>

              <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end', marginTop: 16 }}>
                <button type="button" className="btn btn-secondary" onClick={handleResetAndClose}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Confirm Campus Visit
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
