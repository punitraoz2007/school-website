import React, { useState, useEffect } from 'react';
import { X, Check, RotateCcw, Building2, Phone, Mail, MapPin } from 'lucide-react';
import { useSchool } from '../context/SchoolContext';
import { SchoolLogo } from './SchoolLogo';

export const SchoolCustomizerModal: React.FC = () => {
  const { school, updateSchool, resetToDefault, isCustomizerOpen, setIsCustomizerOpen } = useSchool();

  const [formData, setFormData] = useState(school);

  useEffect(() => {
    if (isCustomizerOpen) {
      document.body.style.overflow = 'hidden';
      setFormData(school);
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isCustomizerOpen, school]);

  if (!isCustomizerOpen) return null;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSchool(formData);
    setIsCustomizerOpen(false);
  };

  const handleReset = () => {
    resetToDefault();
    setFormData(school);
    setIsCustomizerOpen(false);
  };

  return (
    <div className="modal-backdrop" onClick={() => setIsCustomizerOpen(false)}>
      <div className="modal-card" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <SchoolLogo size="sm" />
            <div>
              <h3 className="modal-title">Customize School Details</h3>
              <p style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)', margin: 0 }}>
                Update school name, contact numbers, address & board anytime
              </p>
            </div>
          </div>
          <button
            type="button"
            className="modal-close-btn"
            onClick={() => setIsCustomizerOpen(false)}
            aria-label="Close"
          >
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSave} className="modal-body">
          <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', marginBottom: 20 }}>
            You can modify the school’s information below. Changes will immediately update across all pages, forms, and headers.
          </p>

          <div className="form-grid-2">
            <div className="form-group">
              <label className="form-label">School Name</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="form-input"
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">School Tagline</label>
              <input
                type="text"
                name="tagline"
                value={formData.tagline}
                onChange={handleChange}
                className="form-input"
              />
            </div>
          </div>

          <div className="form-grid-2">
            <div className="form-group">
              <label className="form-label">Board / Curriculum</label>
              <input
                type="text"
                name="board"
                value={formData.board}
                onChange={handleChange}
                className="form-input"
                placeholder="CBSE / State Board / ICSE"
              />
            </div>

            <div className="form-group">
              <label className="form-label">Classes Offered</label>
              <input
                type="text"
                name="classes"
                value={formData.classes}
                onChange={handleChange}
                className="form-input"
              />
            </div>
          </div>

          <div className="form-grid-2">
            <div className="form-group">
              <label className="form-label">Primary Phone Number</label>
              <input
                type="text"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="form-input"
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Official Email</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="form-input"
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Street Address</label>
            <input
              type="text"
              name="address"
              value={formData.address}
              onChange={handleChange}
              className="form-input"
            />
          </div>

          <div className="form-grid-2">
            <div className="form-group">
              <label className="form-label">City, State</label>
              <input
                type="text"
                name="cityState"
                value={formData.cityState}
                onChange={handleChange}
                className="form-input"
              />
            </div>

            <div className="form-group">
              <label className="form-label">Pincode</label>
              <input
                type="text"
                name="pincode"
                value={formData.pincode}
                onChange={handleChange}
                className="form-input"
              />
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 24, paddingTop: 16, borderTop: '1px solid var(--color-border)' }}>
            <button
              type="button"
              className="btn btn-secondary btn-sm"
              onClick={handleReset}
              style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}
            >
              <RotateCcw size={14} /> Reset Defaults
            </button>

            <div style={{ display: 'flex', gap: 10 }}>
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                onClick={() => setIsCustomizerOpen(false)}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary btn-sm"
                style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}
              >
                <Check size={15} /> Save Changes
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
