import React from 'react';
import { Award, BookOpen, ShieldCheck, Sparkles } from 'lucide-react';

interface TeacherCardProps {
  name: string;
  designation: string;
  qualification: string;
  subject: string;
  imagePlaceholder: string;
  quote: string;
}

export const TeacherCard: React.FC<TeacherCardProps> = ({
  name,
  designation,
  qualification,
  subject,
  imagePlaceholder,
  quote
}) => {
  return (
    <div className="teacher-card" style={{ position: 'relative' }}>
      <div style={{ position: 'absolute', top: 16, right: 16 }}>
        <span
          title="Verified Faculty Member"
          style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: '0.6875rem', color: '#059669', backgroundColor: '#ECFDF5', padding: '2px 8px', borderRadius: 'var(--radius-full)', fontWeight: 700 }}
        >
          <ShieldCheck size={13} color="#059669" /> Verified
        </span>
      </div>

      <div className="teacher-avatar">
        <span>{imagePlaceholder}</span>
      </div>

      <h3 className="teacher-name">{name}</h3>
      <div className="teacher-designation">{designation}</div>
      <div className="teacher-subject">{subject}</div>

      <div
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: 6,
          fontSize: '0.75rem',
          color: 'var(--color-primary-dark)',
          backgroundColor: 'var(--color-primary-soft)',
          padding: '4px 10px',
          borderRadius: 'var(--radius-full)',
          marginBottom: 14,
          fontWeight: 600
        }}
      >
        <Award size={13} color="var(--color-primary)" />
        <span>{qualification}</span>
      </div>

      <div className="teacher-quote">
        "{quote}"
      </div>
    </div>
  );
};
