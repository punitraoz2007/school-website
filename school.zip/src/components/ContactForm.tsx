import React, { useState } from 'react';
import { Send, CheckCircle, Phone, Mail, MapPin } from 'lucide-react';
import { useSchool } from '../context/SchoolContext';
import { saveContactMessage } from '../services/enquiryStorage';

export const ContactForm: React.FC = () => {
  const { school } = useSchool();
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    subject: '',
    message: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSent, setIsSent] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.name.trim()) errs.name = 'Please provide your full name';
    if (!formData.phone.trim()) {
      errs.phone = 'Please provide a valid contact number';
    } else if (!/^[0-9+\s-]{8,15}$/.test(formData.phone.trim())) {
      errs.phone = 'Please enter a valid phone number';
    }
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      errs.email = 'Please provide a valid email address';
    }
    if (!formData.subject.trim()) errs.subject = 'Please choose or enter a subject';
    if (!formData.message.trim()) errs.message = 'Please write your message';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      saveContactMessage(formData);
      setIsSent(true);
    }
  };

  return (
    <div className="form-card">
      <h3 style={{ fontSize: '1.5rem', color: 'var(--color-primary-dark)', marginBottom: 8 }}>
        Send Us a Message
      </h3>
      <p style={{ fontSize: '0.9375rem', color: 'var(--color-text-muted)', marginBottom: 24 }}>
        Have questions regarding admissions, transport routes, or student care? Our administrative team will respond within 24 hours.
      </p>

      {isSent ? (
        <div className="form-success-banner">
          <CheckCircle size={44} style={{ margin: '0 auto 12px auto' }} />
          <h4 className="form-success-title">Message Received!</h4>
          <p style={{ margin: '0 0 16px 0', fontSize: '0.9375rem' }}>
            Thank you, <strong>{formData.name}</strong>. Your inquiry regarding "{formData.subject}" has been sent to the school office.
          </p>
          <button
            type="button"
            className="btn btn-secondary btn-sm"
            onClick={() => {
              setIsSent(false);
              setFormData({ name: '', phone: '', email: '', subject: '', message: '' });
            }}
          >
            Send Another Message
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit}>
          <div className="form-grid-2">
            <div className="form-group">
              <label className="form-label">Full Name *</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="form-input"
                placeholder="e.g. Rajesh Kumar"
              />
              {errors.name && <span className="form-error">{errors.name}</span>}
            </div>

            <div className="form-group">
              <label className="form-label">Phone Number *</label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="form-input"
                placeholder="+91 98765 43210"
              />
              {errors.phone && <span className="form-error">{errors.phone}</span>}
            </div>
          </div>

          <div className="form-grid-2">
            <div className="form-group">
              <label className="form-label">Email Address (Optional)</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="form-input"
                placeholder="rajesh@example.com"
              />
              {errors.email && <span className="form-error">{errors.email}</span>}
            </div>

            <div className="form-group">
              <label className="form-label">Subject *</label>
              <select
                name="subject"
                value={formData.subject}
                onChange={handleChange}
                className="form-select"
              >
                <option value="">-- Select Inquiring Topic --</option>
                <option value="Admission Enquiry">Admission Enquiry for 2026-27</option>
                <option value="School Bus & Transport Route">School Bus & Transport Route</option>
                <option value="Fee Structure & Instalments">Fee Structure & Instalments</option>
                <option value="Meeting Principal / Faculty">Meeting Principal / Faculty</option>
                <option value="General Campus Question">General Campus Question</option>
              </select>
              {errors.subject && <span className="form-error">{errors.subject}</span>}
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Message *</label>
            <textarea
              name="message"
              value={formData.message}
              onChange={handleChange}
              className="form-textarea"
              rows={4}
              placeholder="Please provide details of your question or the class your child is interested in..."
            />
            {errors.message && <span className="form-error">{errors.message}</span>}
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 12 }}>
            <button type="submit" className="btn btn-primary" style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
              <Send size={16} /> Send Message
            </button>
          </div>
        </form>
      )}

      {/* Direct Contact Triggers */}
      <div style={{ marginTop: 32, paddingTop: 24, borderTop: '1px solid var(--color-border)', display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        <a href={`tel:${school.phone}`} className="btn btn-secondary btn-sm" style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
          <Phone size={14} color="var(--color-primary)" /> Call Us: {school.phone}
        </a>
        <a href={`mailto:${school.email}`} className="btn btn-secondary btn-sm" style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
          <Mail size={14} color="var(--color-primary)" /> Email Us
        </a>
        <a
          href={`https://maps.google.com/?q=${encodeURIComponent(`${school.name} ${school.address} ${school.cityState}`)}`}
          target="_blank"
          rel="noopener noreferrer"
          className="btn btn-secondary btn-sm"
          style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}
        >
          <MapPin size={14} color="var(--color-primary)" /> Get Directions
        </a>
      </div>
    </div>
  );
};
