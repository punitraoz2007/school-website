import React, { useState, useEffect } from 'react';
import { ArrowRight, Sparkles, GraduationCap, X, BookOpen } from 'lucide-react';
import { useSchool } from '../context/SchoolContext';
import { SchoolLogo } from './SchoolLogo';

interface WelcomeEntrance3DProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WelcomeEntrance3D: React.FC<WelcomeEntrance3DProps> = ({ isOpen, onClose }) => {
  const { school } = useSchool();
  const [isClosing, setIsClosing] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  // Mouse parallax tracking
  const handleMouseMove = (e: React.MouseEvent) => {
    const { innerWidth, innerHeight } = window;
    const x = (e.clientX / innerWidth - 0.5) * 2; // -1 to 1
    const y = (e.clientY / innerHeight - 0.5) * 2; // -1 to 1
    setMousePos({ x, y });
  };

  // Lock body scroll when welcome screen is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  const handleEnter = () => {
    setIsClosing(true);
    setTimeout(() => {
      setIsClosing(false);
      onClose();
    }, 550);
  };

  if (!isOpen && !isClosing) return null;

  return (
    <div
      className={`welcome-3d-backdrop ${isClosing ? 'closing' : ''}`}
      onMouseMove={handleMouseMove}
    >
      {/* Sparkle star dust */}
      <div className="starfield-dust" />

      {/* 3D Floating Stage with Parallax */}
      <div
        className="floating-3d-stage"
        style={{
          transform: `rotateY(${mousePos.x * 12}deg) rotateX(${-mousePos.y * 12}deg)`
        }}
      >
        {/* ================================================================
            FLOATING STATIONERY & 3D ELEMENTS (Top-Left Quad)
            ================================================================ */}
        {/* 1. 3D Open Blue Book */}
        <div
          className="item-3d anim-bob-1"
          style={{
            top: '12%',
            left: '14%',
            transform: `translateZ(${60 + mousePos.y * 30}px)`
          }}
        >
          <div className="book-3d" />
        </div>

        {/* 2. 3D Wooden Pencil */}
        <div
          className="item-3d anim-bob-2"
          style={{
            top: '26%',
            left: '8%',
            transform: `translateZ(${90 - mousePos.x * 20}px)`
          }}
        >
          <div className="pencil-3d" />
        </div>

        {/* 3. Number '1' Block */}
        <div
          className="item-3d anim-bob-3"
          style={{
            top: '44%',
            left: '16%',
            transform: `translateZ(${110 + mousePos.x * 25}px)`
          }}
        >
          <div className="number-3d-block">1</div>
        </div>

        {/* 4. Alphabet 'A' Block */}
        <div
          className="item-3d anim-bob-4"
          style={{
            top: '64%',
            left: '10%',
            transform: `translateZ(${70 - mousePos.y * 20}px)`
          }}
        >
          <div className="letter-3d-block">A</div>
        </div>

        {/* 5. Math Plus Symbol */}
        <div
          className="item-3d anim-bob-1"
          style={{
            top: '78%',
            left: '20%',
            transform: `translateZ(85px)`
          }}
        >
          <div className="math-symbol-3d">+</div>
        </div>

        {/* ================================================================
            FLOATING STATIONERY & 3D ELEMENTS (Top-Right Quad)
            ================================================================ */}
        {/* 6. 3D Graduation Mortarboard Cap */}
        <div
          className="item-3d anim-bob-2"
          style={{
            top: '14%',
            right: '15%',
            transform: `translateZ(${120 + mousePos.x * 30}px)`
          }}
        >
          <div className="cap-3d">
            <div className="cap-diamond">
              <div className="cap-tassel" />
            </div>
          </div>
        </div>

        {/* 7. 3D Paper Airplane */}
        <div
          className="item-3d anim-drift"
          style={{
            top: '24%',
            right: '25%',
            transform: `translateZ(100px)`
          }}
        >
          <div className="airplane-3d">✈️</div>
        </div>

        {/* 8. 3D Crimson Red Book */}
        <div
          className="item-3d anim-bob-3"
          style={{
            top: '38%',
            right: '10%',
            transform: `translateZ(${80 - mousePos.y * 30}px)`
          }}
        >
          <div className="book-3d book-red" />
        </div>

        {/* 9. Number '2' Block */}
        <div
          className="item-3d anim-bob-4"
          style={{
            top: '56%',
            right: '18%',
            transform: `translateZ(${130 - mousePos.x * 30}px)`
          }}
        >
          <div className="number-3d-block">2</div>
        </div>

        {/* 10. Alphabet 'B' Block */}
        <div
          className="item-3d anim-bob-1"
          style={{
            top: '72%',
            right: '12%',
            transform: `translateZ(90px)`
          }}
        >
          <div className="letter-3d-block">B</div>
        </div>

        {/* ================================================================
            FLOATING STATIONERY & 3D ELEMENTS (Upper & Lower Center Floaters)
            ================================================================ */}
        {/* 11. 3D Ruler floating across top */}
        <div
          className="item-3d anim-bob-3"
          style={{
            top: '8%',
            left: '42%',
            transform: `translateZ(${50 + mousePos.y * 15}px)`
          }}
        >
          <div className="ruler-3d" />
        </div>

        {/* 12. 3D Paint Palette */}
        <div
          className="item-3d anim-bob-2"
          style={{
            bottom: '10%',
            left: '32%',
            transform: `translateZ(${95 - mousePos.x * 20}px)`
          }}
        >
          <div className="palette-3d">
            <span className="palette-paint-dot" style={{ top: 8, left: 14, backgroundColor: '#EF4444' }} />
            <span className="palette-paint-dot" style={{ top: 12, left: 34, backgroundColor: '#3B82F6' }} />
            <span className="palette-paint-dot" style={{ top: 22, left: 52, backgroundColor: '#10B981' }} />
            <span className="palette-paint-dot" style={{ top: 36, left: 24, backgroundColor: '#F59E0B' }} />
          </div>
        </div>

        {/* 13. Number '8' Block (Play School to Class 8!) */}
        <div
          className="item-3d anim-bob-1"
          style={{
            bottom: '12%',
            right: '32%',
            transform: `translateZ(${110 + mousePos.y * 20}px)`
          }}
        >
          <div
            className="number-3d-block"
            style={{
              background: 'linear-gradient(135deg, #EC4899 0%, #BE185D 100%)',
              color: '#FFFFFF'
            }}
          >
            8
          </div>
        </div>

        {/* 14. 3D Emerald Book */}
        <div
          className="item-3d anim-bob-4"
          style={{
            top: '4%',
            right: '34%',
            transform: `translateZ(65px)`
          }}
        >
          <div className="book-3d book-emerald" />
        </div>

        {/* 15. Math Multiply & Division Symbols */}
        <div
          className="item-3d anim-bob-2"
          style={{
            bottom: '22%',
            left: '8%',
            transform: `translateZ(75px)`
          }}
        >
          <div
            className="math-symbol-3d"
            style={{ background: 'linear-gradient(135deg, #8B5CF6 0%, #6D28D9 100%)' }}
          >
            ×
          </div>
        </div>

        <div
          className="item-3d anim-bob-3"
          style={{
            bottom: '24%',
            right: '8%',
            transform: `translateZ(75px)`
          }}
        >
          <div
            className="math-symbol-3d"
            style={{ background: 'linear-gradient(135deg, #06B6D4 0%, #0E7490 100%)' }}
          >
            ÷
          </div>
        </div>
      </div>

      {/* ====================================================================
          CENTER WELCOME PORTAL CARD
          ==================================================================== */}
      <div className="welcome-center-card">
        {/* School Crest Logo */}
        <div style={{ marginBottom: 20, display: 'flex', justifyContent: 'center' }}>
          <SchoolLogo size="lg" />
        </div>

        {/* Badge */}
        <div className="welcome-badge">
          <Sparkles size={14} color="#FCD34D" />
          <span>Welcome to Our Campus • 2026-27</span>
        </div>

        {/* School Title */}
        <h1 className="welcome-title">
          {school.name}
        </h1>

        {/* Tagline */}
        <div className="welcome-tagline">
          "{school.tagline}"
        </div>

        {/* Prose */}
        <p className="welcome-prose">
          A vibrant educational home for <strong>Play School, Nursery, LKG, UKG and Classes 1 to 8</strong>. Step inside to explore our joyful classrooms, safe campus, and rich academic curriculum.
        </p>

        {/* Primary Action Button */}
        <div>
          <button
            type="button"
            className="welcome-btn-enter"
            onClick={handleEnter}
          >
            <span>Step Inside Campus</span>
            <ArrowRight size={18} />
          </button>
        </div>

        {/* Quick Skip Link */}
        <button
          type="button"
          className="welcome-skip-btn"
          onClick={handleEnter}
        >
          Directly Enter Main Website →
        </button>
      </div>
    </div>
  );
};
