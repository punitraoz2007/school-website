import React, { useState, useEffect } from 'react';
import { X, ChevronLeft, ChevronRight, Image as ImageIcon } from 'lucide-react';
import { galleryCategories, galleryItems } from '../data/schoolData';

export const GallerySection: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [activeLightboxIndex, setActiveLightboxIndex] = useState<number | null>(null);

  const filteredItems = activeCategory === 'All'
    ? galleryItems
    : galleryItems.filter(item => item.category === activeCategory);

  const getCategoryCount = (cat: string) => {
    if (cat === 'All') return galleryItems.length;
    return galleryItems.filter(item => item.category === cat).length;
  };

  const currentItem = activeLightboxIndex !== null ? filteredItems[activeLightboxIndex] : null;

  const showNext = () => {
    if (activeLightboxIndex !== null) {
      setActiveLightboxIndex((activeLightboxIndex + 1) % filteredItems.length);
    }
  };

  const showPrev = () => {
    if (activeLightboxIndex !== null) {
      setActiveLightboxIndex((activeLightboxIndex - 1 + filteredItems.length) % filteredItems.length);
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (activeLightboxIndex === null) return;
      if (e.key === 'Escape') setActiveLightboxIndex(null);
      if (e.key === 'ArrowRight') showNext();
      if (e.key === 'ArrowLeft') showPrev();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeLightboxIndex, filteredItems.length]);

  return (
    <>
      {/* Category Filter Buttons with Counts */}
      <div className="gallery-filters">
        {galleryCategories.map((cat) => (
          <button
            key={cat}
            type="button"
            className={`filter-btn ${activeCategory === cat ? 'active' : ''}`}
            onClick={() => {
              setActiveCategory(cat);
              setActiveLightboxIndex(null);
            }}
          >
            {cat} <span style={{ opacity: 0.75, fontSize: '0.75rem' }}>({getCategoryCount(cat)})</span>
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="gallery-grid">
        {filteredItems.map((item, idx) => (
          <div
            key={item.id}
            className="gallery-item"
            onClick={() => setActiveLightboxIndex(idx)}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                setActiveLightboxIndex(idx);
              }
            }}
          >
            <img
              src={item.image}
              alt={item.title}
              referrerPolicy="no-referrer"
              loading="lazy"
            />
            <div className="gallery-overlay">
              <span className="gallery-item-title">{item.title}</span>
              <span className="gallery-item-cat">{item.category}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Lightbox Preview with Next/Prev */}
      {currentItem && activeLightboxIndex !== null && (
        <div className="lightbox-backdrop" onClick={() => setActiveLightboxIndex(null)}>
          <div className="lightbox-content" onClick={e => e.stopPropagation()}>
            <button
              type="button"
              className="lightbox-close-btn"
              onClick={() => setActiveLightboxIndex(null)}
              aria-label="Close image preview"
            >
              <X size={28} />
            </button>

            {/* Navigation arrows */}
            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); showPrev(); }}
              aria-label="Previous image"
              style={{
                position: 'absolute',
                left: -20,
                top: '50%',
                transform: 'translateY(-50%)',
                background: 'rgba(15, 23, 42, 0.85)',
                color: '#FFFFFF',
                width: 44,
                height: 44,
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                border: '1px solid rgba(255, 255, 255, 0.2)',
                zIndex: 10,
                cursor: 'pointer'
              }}
            >
              <ChevronLeft size={24} />
            </button>

            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); showNext(); }}
              aria-label="Next image"
              style={{
                position: 'absolute',
                right: -20,
                top: '50%',
                transform: 'translateY(-50%)',
                background: 'rgba(15, 23, 42, 0.85)',
                color: '#FFFFFF',
                width: 44,
                height: 44,
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                border: '1px solid rgba(255, 255, 255, 0.2)',
                zIndex: 10,
                cursor: 'pointer'
              }}
            >
              <ChevronRight size={24} />
            </button>

            <div className="lightbox-img-wrap">
              <img
                src={currentItem.image}
                alt={currentItem.title}
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="lightbox-caption">
              <div style={{ fontSize: '0.75rem', color: '#FCD34D', textTransform: 'uppercase', fontWeight: 700, marginBottom: 4 }}>
                {currentItem.category} • Photo {activeLightboxIndex + 1} of {filteredItems.length}
              </div>
              <h4 style={{ fontSize: '1.25rem', fontWeight: 700, margin: '0 0 4px 0', color: '#FFFFFF' }}>
                {currentItem.title}
              </h4>
              <p style={{ fontSize: '0.875rem', color: '#CBD5E1', margin: 0 }}>
                {currentItem.caption}
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
