/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { Settings } from 'lucide-react';
import { SchoolProvider, useSchool } from './context/SchoolContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { AdmissionModal } from './components/AdmissionModal';
import { BookVisitModal } from './components/BookVisitModal';
import { SchoolCustomizerModal } from './components/SchoolCustomizerModal';
import { WelcomeEntrance3D } from './components/WelcomeEntrance3D';

// Pages
import { Home } from './pages/Home';
import { About } from './pages/About';
import { Academics } from './pages/Academics';
import { Facilities } from './pages/Facilities';
import { Safety } from './pages/Safety';
import { Admissions } from './pages/Admissions';
import { SchoolLife } from './pages/SchoolLife';
import { Gallery } from './pages/Gallery';
import { Faculty } from './pages/Faculty';
import { Parents } from './pages/Parents';
import { Contact } from './pages/Contact';
import { AdminEnquiries } from './pages/AdminEnquiries';

// Scroll to top helper on route navigation
const ScrollToTop: React.FC = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' as ScrollBehavior });
  }, [pathname]);

  return null;
};

const AppContent: React.FC = () => {
  const [isAdmissionModalOpen, setIsAdmissionModalOpen] = useState(false);
  const [isVisitModalOpen, setIsVisitModalOpen] = useState(false);
  const [isWelcomeEntranceOpen, setIsWelcomeEntranceOpen] = useState(false);
  const { setIsCustomizerOpen } = useSchool();

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      <ScrollToTop />
      
      {/* 3D Entering Experience Portal */}
      <WelcomeEntrance3D
        isOpen={isWelcomeEntranceOpen}
        onClose={() => setIsWelcomeEntranceOpen(false)}
      />

      <Navbar
        onOpenAdmissionModal={() => setIsAdmissionModalOpen(true)}
        onOpenWelcomeEntrance={() => setIsWelcomeEntranceOpen(true)}
      />

      <main>
        <Routes>
          <Route
            path="/"
            element={
              <Home
                onOpenAdmissionModal={() => setIsAdmissionModalOpen(true)}
                onOpenVisitModal={() => setIsVisitModalOpen(true)}
              />
            }
          />
          <Route path="/about" element={<About />} />
          <Route path="/academics" element={<Academics />} />
          <Route path="/facilities" element={<Facilities />} />
          <Route
            path="/safety"
            element={<Safety onOpenVisitModal={() => setIsVisitModalOpen(true)} />}
          />
          <Route
            path="/admissions"
            element={<Admissions onOpenVisitModal={() => setIsVisitModalOpen(true)} />}
          />
          <Route path="/school-life" element={<SchoolLife />} />
          <Route path="/gallery" element={<Gallery />} />
          <Route path="/faculty" element={<Faculty />} />
          <Route path="/parents" element={<Parents />} />
          <Route
            path="/contact"
            element={<Contact onOpenVisitModal={() => setIsVisitModalOpen(true)} />}
          />
          <Route path="/admin" element={<AdminEnquiries />} />
          {/* Fallback to Home */}
          <Route
            path="*"
            element={
              <Home
                onOpenAdmissionModal={() => setIsAdmissionModalOpen(true)}
                onOpenVisitModal={() => setIsVisitModalOpen(true)}
              />
            }
          />
        </Routes>
      </main>

      <Footer onOpenCustomizer={() => setIsCustomizerOpen(true)} />

      {/* Modals */}
      <AdmissionModal
        isOpen={isAdmissionModalOpen}
        onClose={() => setIsAdmissionModalOpen(false)}
      />

      <BookVisitModal
        isOpen={isVisitModalOpen}
        onClose={() => setIsVisitModalOpen(false)}
      />

      <SchoolCustomizerModal />

      {/* Floating Quick Customizer Button */}
      <button
        type="button"
        className="floating-edit-btn"
        onClick={() => setIsCustomizerOpen(true)}
        title="Customize School Name, Address & Contact Details"
      >
        <Settings size={15} /> Edit School Info
      </button>
    </div>
  );
};

export default function App() {
  return (
    <Router>
      <SchoolProvider>
        <AppContent />
      </SchoolProvider>
    </Router>
  );
}
