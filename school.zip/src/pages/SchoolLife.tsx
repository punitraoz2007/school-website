import React from 'react';
import {
  Sun,
  BookOpen,
  Palette,
  Trophy,
  Music,
  Sparkles,
  Calendar,
  Compass,
  Smile,
  Award,
  Users
} from 'lucide-react';
import { schoolLifeEvents } from '../data/schoolData';
import { useSchool } from '../context/SchoolContext';
import heroImg from '../assets/images/hero_school_children_1791101324038.jpg';
import classroomImg from '../assets/images/smart_classroom_1791101337304.jpg';
import playschoolImg from '../assets/images/playschool_activity_1791101350172.jpg';
import sportsImg from '../assets/images/school_sports_play_1791101377753.jpg';

export const SchoolLife: React.FC = () => {
  const { school } = useSchool();

  const getEventIcon = (title: string) => {
    switch (title) {
      case 'Morning Assembly': return <Sun size={24} />;
      case 'Classroom Learning': return <BookOpen size={24} />;
      case 'Art, Craft & Design': return <Palette size={24} />;
      case 'Sports & Physical Fitness': return <Trophy size={24} />;
      case 'Music & Dance': return <Music size={24} />;
      case 'Celebrations & Festivals': return <Sparkles size={24} />;
      case 'Annual Function & Sports Day': return <Calendar size={24} />;
      case 'Field Trips & Nature Walks': return <Compass size={24} />;
      default: return <Smile size={24} />;
    }
  };

  const getEventImage = (idx: number) => {
    const images = [heroImg, classroomImg, playschoolImg, sportsImg];
    return images[idx % images.length];
  };

  return (
    <div>
      {/* Header */}
      <section style={{ backgroundColor: 'var(--color-primary-dark)', color: '#FFFFFF', padding: '60px 0 50px 0', borderBottom: '4px solid var(--color-accent)' }}>
        <div className="container">
          <span style={{ fontSize: '0.8125rem', color: '#FCD34D', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 700, display: 'block', marginBottom: 8 }}>
            Joyful Student Experiences
          </span>
          <h1 style={{ fontSize: 'clamp(2rem, 3.5vw, 2.75rem)', color: '#FFFFFF', marginBottom: 12 }}>
            Vibrant School Life at {school.name}
          </h1>
          <p style={{ fontSize: '1.0625rem', color: '#CBD5E1', maxWidth: 680, margin: 0, lineHeight: 1.6 }}>
            A day in the life of our students is packed with learning, laughing, creating, competing, and forming enduring friendships.
          </p>
        </div>
      </section>

      {/* Daily Routine & Assembly Spotlight */}
      <section className="section">
        <div className="container">
          <div className="section-header">
            <span className="section-kicker">Holistic Daily Rhythm</span>
            <h2 className="section-title">Beyond Textbooks: A Typical School Day</h2>
            <p className="section-subtitle">
              From our inspirational morning assembly to interactive club sessions, our timetable strikes the right balance between cognitive stimulation and playful physical movement.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 24 }}>
            {schoolLifeEvents.map((evt, idx) => (
              <div
                key={idx}
                style={{
                  backgroundColor: '#FFFFFF',
                  border: '1px solid var(--color-border)',
                  borderRadius: 'var(--radius-lg)',
                  overflow: 'hidden',
                  boxShadow: 'var(--shadow-sm)',
                  display: 'flex',
                  flexDirection: 'column',
                  transition: 'all 0.2s ease'
                }}
              >
                <div style={{ height: 160, overflow: 'hidden', position: 'relative' }}>
                  <img
                    src={getEventImage(idx)}
                    alt={evt.title}
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                    referrerPolicy="no-referrer"
                  />
                  <div
                    style={{
                      position: 'absolute',
                      top: 12,
                      right: 12,
                      backgroundColor: 'rgba(15, 23, 42, 0.8)',
                      backdropFilter: 'blur(4px)',
                      color: '#FCD34D',
                      width: 38,
                      height: 38,
                      borderRadius: '50%',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}
                  >
                    {getEventIcon(evt.title)}
                  </div>
                </div>

                <div style={{ padding: 22, display: 'flex', flexDirection: 'column', flex: 1 }}>
                  <h3 style={{ fontSize: '1.1875rem', color: 'var(--color-primary-dark)', marginBottom: 8 }}>
                    {evt.title}
                  </h3>
                  <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: 1.6, margin: 0 }}>
                    {evt.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* House System & Clubs */}
      <section className="section section-alt">
        <div className="container">
          <div className="section-header">
            <span className="section-kicker">Companionship & Healthy Competition</span>
            <h2 className="section-title">The Four School Houses & Co-Curricular Clubs</h2>
            <p className="section-subtitle">
              Students from Class 1 to 8 are divided into four active houses that instill teamwork, leadership, and healthy sportsmanship.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 20, marginBottom: 40 }}>
            <div style={{ backgroundColor: '#FEF2F2', border: '1px solid #FECACA', borderRadius: 'var(--radius-md)', padding: 20, textAlign: 'center' }}>
              <div style={{ fontWeight: 800, color: '#DC2626', fontSize: '1.25rem', marginBottom: 4 }}>Agni House (Red)</div>
              <div style={{ fontSize: '0.8125rem', color: '#7F1D1D' }}>Courage, Valour & Passion for Excellence</div>
            </div>
            <div style={{ backgroundColor: '#EFF6FF', border: '1px solid #BFDBFE', borderRadius: 'var(--radius-md)', padding: 20, textAlign: 'center' }}>
              <div style={{ fontWeight: 800, color: '#2563EB', fontSize: '1.25rem', marginBottom: 4 }}>Vayu House (Blue)</div>
              <div style={{ fontSize: '0.8125rem', color: '#1E3A8A' }}>Speed, Adaptability & Inquiring Intellect</div>
            </div>
            <div style={{ backgroundColor: '#ECFDF5', border: '1px solid #A7F3D0', borderRadius: 'var(--radius-md)', padding: 20, textAlign: 'center' }}>
              <div style={{ fontWeight: 800, color: '#059669', fontSize: '1.25rem', marginBottom: 4 }}>Prithvi House (Green)</div>
              <div style={{ fontSize: '0.8125rem', color: '#064E3B' }}>Steadfastness, Environmental Care & Integrity</div>
            </div>
            <div style={{ backgroundColor: '#FFFBEB', border: '1px solid #FDE68A', borderRadius: 'var(--radius-md)', padding: 20, textAlign: 'center' }}>
              <div style={{ fontWeight: 800, color: '#D97706', fontSize: '1.25rem', marginBottom: 4 }}>Surya House (Yellow)</div>
              <div style={{ fontSize: '0.8125rem', color: '#78350F' }}>Illumination, Joy, Optimism & Warmth</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
