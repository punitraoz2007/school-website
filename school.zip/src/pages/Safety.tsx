import React from 'react';
import {
  ShieldCheck,
  Video,
  KeyRound,
  UserCheck,
  PhoneCall,
  HeartPulse,
  Flame,
  Droplets,
  Sparkles,
  Eye,
  AlertTriangle,
  FileCheck
} from 'lucide-react';
import { safetyMeasures } from '../data/schoolData';
import { useSchool } from '../context/SchoolContext';

interface SafetyProps {
  onOpenVisitModal: () => void;
}

export const Safety: React.FC<SafetyProps> = ({ onOpenVisitModal }) => {
  const { school } = useSchool();

  const getSafetyIcon = (title: string) => {
    switch (title) {
      case 'CCTV Surveillance': return <Video size={20} />;
      case 'Secure School Entrance': return <KeyRound size={20} />;
      case 'Controlled Visitor Entry': return <FileCheck size={20} />;
      case 'Student Pickup & Drop Verification': return <UserCheck size={20} />;
      case 'Background-Verified Staff': return <ShieldCheck size={20} />;
      case 'Campus First-Aid & Emergency Tie-Up': return <HeartPulse size={20} />;
      case 'Fire Safety Equipment': return <Flame size={20} />;
      case 'RO Purified Drinking Water': return <Droplets size={20} />;
      case 'Hygienic, Child-Friendly Washrooms': return <Sparkles size={20} />;
      case 'Continuous Staff Supervision': return <Eye size={20} />;
      default: return <ShieldCheck size={20} />;
    }
  };

  return (
    <div>
      {/* Header */}
      <section style={{ backgroundColor: 'var(--color-primary-dark)', color: '#FFFFFF', padding: '60px 0 50px 0', borderBottom: '4px solid #10B981' }}>
        <div className="container">
          <span style={{ fontSize: '0.8125rem', color: '#6EE7B7', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 700, display: 'block', marginBottom: 8 }}>
            Zero-Compromise Security
          </span>
          <h1 style={{ fontSize: 'clamp(2rem, 3.5vw, 2.75rem)', color: '#FFFFFF', marginBottom: 12 }}>
            Safety & Child Protection
          </h1>
          <p style={{ fontSize: '1.0625rem', color: '#CBD5E1', maxWidth: 680, margin: 0, lineHeight: 1.6 }}>
            Every parent's first concern is their child's physical and emotional safety. We implement rigorous, verified protocols at every stage of the school day.
          </p>
        </div>
      </section>

      {/* Visual Feature: Your Child's Safety Matters */}
      <section className="section">
        <div className="container">
          <div className="safety-hero-box">
            <h2 style={{ fontSize: 'clamp(1.75rem, 3vw, 2.25rem)', marginBottom: 12 }}>
              "Your Child's Safety Matters Above Everything"
            </h2>
            <p style={{ fontSize: '1.0625rem', lineHeight: 1.7, marginBottom: 24, color: '#E2E8F0' }}>
              We believe a child can only truly explore, express themselves, and excel when they feel 100% secure. Our safety architecture combines vigilant human supervision, controlled physical infrastructure, and sensible digital monitoring.
            </p>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
              <button type="button" className="btn btn-accent" onClick={onOpenVisitModal}>
                Schedule Safety Tour with Principal
              </button>
              <a href={`tel:${school.phone}`} className="btn btn-outline-white">
                Emergency Helpline: {school.phone}
              </a>
            </div>
          </div>

          {/* Detailed Measures Grid */}
          <div className="safety-grid">
            {safetyMeasures.map((measure, idx) => (
              <div key={idx} className="safety-item-card">
                <div className="safety-icon-bubble">
                  {getSafetyIcon(measure.title)}
                </div>
                <div>
                  <h3 className="safety-item-title">{measure.title}</h3>
                  <p className="safety-item-desc">{measure.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Dispersal & Escort Card Protocol */}
      <section className="section section-alt">
        <div className="container">
          <div className="section-header">
            <span className="section-kicker">Accountability in Practice</span>
            <h2 className="section-title">Arrival & Dispersal Protocol</h2>
            <p className="section-subtitle">
              How we ensure no child is left unattended or handed over without authorized verification.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 24 }}>
            <div style={{ backgroundColor: '#FFFFFF', padding: 28, borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ fontFamily: 'var(--font-heading)', fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-primary-dark)', marginBottom: 8 }}>
                1. Morning Arrival (7:45 AM / 8:30 AM)
              </div>
              <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
                Duty teachers and female attendants greet children at the primary gate. Play School & Kindergarten toddlers are guided directly to their designated carpeted activity rooms.
              </p>
            </div>

            <div style={{ backgroundColor: '#FFFFFF', padding: 28, borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ fontFamily: 'var(--font-heading)', fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-primary-dark)', marginBottom: 8 }}>
                2. During School Hours
              </div>
              <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
                Outer gates remain locked. Visitors are screened at the security booth, required to present government photo ID, and escorted only to the administrative reception.
              </p>
            </div>

            <div style={{ backgroundColor: '#FFFFFF', padding: 28, borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ fontFamily: 'var(--font-heading)', fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-primary-dark)', marginBottom: 8 }}>
                3. Afternoon Dispersal & Escort Card
              </div>
              <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
                Every family is issued twin photographic Escort Cards. Children are handed over only to the card holder. For school transport, attendants conduct roll-call before departure.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Safety FAQ & Emergency Helpline Directory */}
      <section className="section">
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 36, alignItems: 'start' }}>
            {/* Left: Parent Safety FAQ */}
            <div>
              <span className="section-kicker">Parent Queries</span>
              <h3 style={{ fontSize: '1.5rem', color: 'var(--color-primary-dark)', marginBottom: 16 }}>
                Frequently Asked Safety Questions
              </h3>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <div style={{ backgroundColor: '#FFFFFF', padding: 18, borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}>
                  <h4 style={{ fontSize: '0.9375rem', fontWeight: 700, color: 'var(--color-primary-dark)', marginBottom: 6 }}>
                    What happens if a child feels unwell during classes?
                  </h4>
                  <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)', margin: 0, lineHeight: 1.55 }}>
                    The student is accompanied by an attendant to our campus first-aid dispensary. The staff conducts a thermal and pulse check, contacts the parents immediately, and provides supervised rest until the parent arrives.
                  </p>
                </div>

                <div style={{ backgroundColor: '#FFFFFF', padding: 18, borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}>
                  <h4 style={{ fontSize: '0.9375rem', fontWeight: 700, color: 'var(--color-primary-dark)', marginBottom: 6 }}>
                    How are female attendants deployed for early years?
                  </h4>
                  <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)', margin: 0, lineHeight: 1.55 }}>
                    Every Play School and Kindergarten section has an assigned female nanny/attendant who accompanies toddlers for hand-washing, washroom assistance, and water breaks.
                  </p>
                </div>

                <div style={{ backgroundColor: '#FFFFFF', padding: 18, borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}>
                  <h4 style={{ fontSize: '0.9375rem', fontWeight: 700, color: 'var(--color-primary-dark)', marginBottom: 6 }}>
                    What is the policy regarding CCTV footage review?
                  </h4>
                  <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)', margin: 0, lineHeight: 1.55 }}>
                    CCTV cameras cover school entrances, perimeter corridors, stairwells, and sports areas for student protection. Recordings are archived securely and reviewed under strict administrative oversight.
                  </p>
                </div>
              </div>
            </div>

            {/* Right: Emergency Directory */}
            <div>
              <div style={{ backgroundColor: '#0F172A', color: '#FFFFFF', padding: 32, borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-md)' }}>
                <h3 style={{ fontSize: '1.25rem', color: '#FFFFFF', marginBottom: 6 }}>
                  Emergency Contact Directory
                </h3>
                <p style={{ fontSize: '0.8125rem', color: '#94A3B8', marginBottom: 20 }}>
                  Immediate escalation helplines active during all school operations.
                </p>

                <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid #1E293B', paddingBottom: 10, fontSize: '0.875rem' }}>
                    <span style={{ color: '#CBD5E1' }}>School Medical Room:</span>
                    <strong style={{ color: '#FCD34D' }}>{school.phone}</strong>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid #1E293B', paddingBottom: 10, fontSize: '0.875rem' }}>
                    <span style={{ color: '#CBD5E1' }}>Transport Supervisor Helpline:</span>
                    <strong style={{ color: '#FCD34D' }}>{school.alternatePhone}</strong>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid #1E293B', paddingBottom: 10, fontSize: '0.875rem' }}>
                    <span style={{ color: '#CBD5E1' }}>Nearby Hospital Tie-Up:</span>
                    <strong style={{ color: '#FFFFFF' }}>City Care Hospital (5 mins away)</strong>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid #1E293B', paddingBottom: 10, fontSize: '0.875rem' }}>
                    <span style={{ color: '#CBD5E1' }}>National Child Helpline:</span>
                    <strong style={{ color: '#34D399' }}>1098 (Toll Free)</strong>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.875rem' }}>
                    <span style={{ color: '#CBD5E1' }}>National Emergency Services:</span>
                    <strong style={{ color: '#34D399' }}>112</strong>
                  </div>
                </div>

                <div style={{ marginTop: 24 }}>
                  <button
                    type="button"
                    className="btn btn-accent btn-sm"
                    style={{ width: '100%' }}
                    onClick={onOpenVisitModal}
                  >
                    Book Campus Tour to Inspect Safety in Person
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
