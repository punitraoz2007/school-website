import React from 'react';
import { facultyMembers } from '../data/schoolData';
import { TeacherCard } from '../components/TeacherCard';
import { useSchool } from '../context/SchoolContext';
import { Users, Award, BookOpen, Heart } from 'lucide-react';

export const Faculty: React.FC = () => {
  const { school } = useSchool();

  return (
    <div>
      {/* Header */}
      <section style={{ backgroundColor: 'var(--color-primary-dark)', color: '#FFFFFF', padding: '60px 0 50px 0', borderBottom: '4px solid var(--color-accent)' }}>
        <div className="container">
          <span style={{ fontSize: '0.8125rem', color: '#FCD34D', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 700, display: 'block', marginBottom: 8 }}>
            Our Educational Mentors
          </span>
          <h1 style={{ fontSize: 'clamp(2rem, 3.5vw, 2.75rem)', color: '#FFFFFF', marginBottom: 12 }}>
            Dedicated Faculty & Teaching Staff
          </h1>
          <p style={{ fontSize: '1.0625rem', color: '#CBD5E1', maxWidth: 680, margin: 0, lineHeight: 1.6 }}>
            Our teachers are more than instructors; they are empathetic guides, patient mentors, and passionate lifelong learners dedicated to your child's success.
          </p>
        </div>
      </section>

      {/* Teachers Grid */}
      <section className="section">
        <div className="container">
          <div className="section-header">
            <span className="section-kicker">Qualified & Caring Educators</span>
            <h2 className="section-title">Meet Our Teaching Leadership</h2>
            <p className="section-subtitle">
              All staff undergo thorough background verification, continuous pedagogical development, and child sensitivity workshops.
            </p>
          </div>

          <div className="faculty-grid">
            {facultyMembers.map((member, idx) => (
              <TeacherCard
                key={idx}
                name={member.name}
                designation={member.designation}
                qualification={member.qualification}
                subject={member.subject}
                imagePlaceholder={member.imagePlaceholder}
                quote={member.quote}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Teacher-Student Ratio & Philosophy */}
      <section className="section section-soft">
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 24 }}>
            <div style={{ backgroundColor: '#FFFFFF', padding: 28, borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                <Users size={22} color="var(--color-primary)" />
                <h3 style={{ fontSize: '1.1875rem', color: 'var(--color-primary-dark)', margin: 0 }}>
                  15:1 Student-Teacher Ratio
                </h3>
              </div>
              <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: 1.6, margin: 0 }}>
                We deliberately maintain compact class sizes so no child is overlooked. Teachers can observe subtle emotional or conceptual hurdles immediately.
              </p>
            </div>

            <div style={{ backgroundColor: '#FFFFFF', padding: 28, borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                <Award size={22} color="var(--color-accent)" />
                <h3 style={{ fontSize: '1.1875rem', color: 'var(--color-primary-dark)', margin: 0 }}>
                  Continuous Teacher Training
                </h3>
              </div>
              <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: 1.6, margin: 0 }}>
                Faculty members participate in regular teacher enrichment programs, NEP 2020 workshops, and modern digital tool training every academic quarter.
              </p>
            </div>

            <div style={{ backgroundColor: '#FFFFFF', padding: 28, borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                <Heart size={22} color="var(--color-success)" />
                <h3 style={{ fontSize: '1.1875rem', color: 'var(--color-primary-dark)', margin: 0 }}>
                  Empathy & Child Psychology
                </h3>
              </div>
              <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: 1.6, margin: 0 }}>
                Early childhood educators are certified in child development, ensuring toddlers feel secure, confident, and eager to come to school every single morning.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
