import React from 'react';
import { Target, Compass, Heart, Shield, Award, Sparkles, BookOpen, CheckCircle, Users } from 'lucide-react';
import { useSchool } from '../context/SchoolContext';
import { SchoolLogo } from '../components/SchoolLogo';
import heroImg from '../assets/images/hero_school_children_1791101324038.jpg';
import classroomImg from '../assets/images/smart_classroom_1791101337304.jpg';

export const About: React.FC = () => {
  const { school } = useSchool();

  const valuesList = [
    {
      title: 'Respect',
      desc: 'Treating elders, peers, different perspectives, and the environment with dignity and grace.'
    },
    {
      title: 'Discipline',
      desc: 'Cultivating punctuality, self-regulation, focused habits, and dedication to personal growth.'
    },
    {
      title: 'Kindness',
      desc: 'Fostering compassion, empathy, teamwork, and an eagerness to help others in need.'
    },
    {
      title: 'Creativity',
      desc: 'Encouraging original thinking, artistic expression, questions, and innovative problem solving.'
    },
    {
      title: 'Responsibility',
      desc: 'Instilling ownership of one’s choices, academic duties, school property, and social duties.'
    },
    {
      title: 'Excellence',
      desc: 'Striving always to do one’s personal best in academics, sports, cultural arts, and character.'
    }
  ];

  return (
    <div>
      {/* Page Header */}
      <section style={{ backgroundColor: 'var(--color-primary-dark)', color: '#FFFFFF', padding: '60px 0 50px 0', borderBottom: '4px solid var(--color-accent)' }}>
        <div className="container">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 24, flexWrap: 'wrap' }}>
            <div style={{ maxWidth: 680 }}>
              <span style={{ fontSize: '0.8125rem', color: '#FCD34D', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 700, display: 'block', marginBottom: 8 }}>
                Know Our Foundation • Estd. {school.establishedYear}
              </span>
              <h1 style={{ fontSize: 'clamp(2rem, 3.5vw, 2.75rem)', color: '#FFFFFF', marginBottom: 12 }}>
                About {school.name}
              </h1>
              <p style={{ fontSize: '1.0625rem', color: '#CBD5E1', margin: 0, lineHeight: 1.6 }}>
                Nurturing young minds with care, discipline, and modern pedagogical rigor from Play School through Class 8.
              </p>
            </div>
            <div style={{ backgroundColor: 'rgba(255, 255, 255, 0.08)', padding: '16px 20px', borderRadius: 'var(--radius-lg)', border: '1px solid rgba(255, 255, 255, 0.15)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto' }}>
              <SchoolLogo size="lg" />
            </div>
          </div>
        </div>
      </section>

      {/* Main Story & Overview */}
      <section className="section">
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 48, alignItems: 'center' }}>
            <div>
              <span className="section-kicker">Our Heritage & Commitment</span>
              <h2 className="section-title" style={{ textAlign: 'left' }}>
                A Nurturing Educational Sanctuary for Your Child
              </h2>
              <p style={{ fontSize: '1.0625rem', color: 'var(--color-text-muted)', lineHeight: 1.7, marginBottom: 16 }}>
                Founded with a resolute commitment to value-based education, <strong>{school.name}</strong> provides comprehensive schooling from <strong>Play School, Nursery, LKG, UKG up to Class 8</strong>. We believe the early years and primary grades lay the unshakable bedrock of a child's character, academic capability, and self-confidence.
              </p>
              <p style={{ fontSize: '0.9375rem', color: 'var(--color-text-muted)', lineHeight: 1.7, marginBottom: 20 }}>
                Our curriculum harmoniously blends disciplined academic inquiry with creative exploration, public speaking, activity-based discovery, and physical fitness. By maintaining optimal student-teacher ratios (15:1), every child receives the patient guidance, personalized mentorship, and safety they deserve.
              </p>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                <div style={{ padding: 14, backgroundColor: 'var(--color-bg-subtle)', borderRadius: 'var(--radius-sm)', borderLeft: '3px solid var(--color-primary)' }}>
                  <div style={{ fontFamily: 'var(--font-heading)', fontWeight: 700, color: 'var(--color-primary-dark)', fontSize: '1.0625rem' }}>10+ Years</div>
                  <div style={{ fontSize: '0.8125rem', color: 'var(--color-text-light)' }}>Academic Legacy in {school.cityState}</div>
                </div>
                <div style={{ padding: 14, backgroundColor: 'var(--color-bg-subtle)', borderRadius: 'var(--radius-sm)', borderLeft: '3px solid var(--color-accent)' }}>
                  <div style={{ fontFamily: 'var(--font-heading)', fontWeight: 700, color: 'var(--color-accent-dark)', fontSize: '1.0625rem' }}>100% Focus</div>
                  <div style={{ fontSize: '0.8125rem', color: 'var(--color-text-light)' }}>On Child Safety & Overall Growth</div>
                </div>
              </div>
            </div>

            <div style={{ position: 'relative' }}>
              <div style={{ borderRadius: 'var(--radius-lg)', overflow: 'hidden', boxShadow: 'var(--shadow-lg)' }}>
                <img
                  src={classroomImg}
                  alt="Students engaged in classroom"
                  style={{ width: '100%', height: 'auto', display: 'block' }}
                  referrerPolicy="no-referrer"
                />
              </div>
              <div
                style={{
                  position: 'absolute',
                  bottom: -20,
                  right: 20,
                  backgroundColor: 'var(--color-primary-dark)',
                  color: '#FFFFFF',
                  padding: '16px 20px',
                  borderRadius: 'var(--radius-md)',
                  boxShadow: 'var(--shadow-md)',
                  maxWidth: 240
                }}
              >
                <div style={{ fontSize: '0.75rem', color: '#FCD34D', fontWeight: 700, textTransform: 'uppercase' }}>Affiliation</div>
                <div style={{ fontSize: '0.875rem', fontWeight: 600 }}>{school.board}</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Vision & Mission Cards */}
      <section className="section section-soft">
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 32 }}>
            {/* Vision */}
            <div style={{ backgroundColor: '#FFFFFF', padding: 36, borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ width: 48, height: 48, borderRadius: 'var(--radius-md)', backgroundColor: 'var(--color-primary-soft)', color: 'var(--color-primary)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 18 }}>
                <Target size={24} />
              </div>
              <h3 style={{ fontSize: '1.5rem', color: 'var(--color-primary-dark)', marginBottom: 12 }}>
                Our Vision
              </h3>
              <p style={{ fontSize: '1.1875rem', color: 'var(--color-primary)', fontStyle: 'italic', fontWeight: 600, marginBottom: 14 }}>
                "To create confident, responsible and lifelong learners."
              </p>
              <p style={{ fontSize: '0.9375rem', color: 'var(--color-text-muted)', lineHeight: 1.65 }}>
                We envision each child leaving our school with strong moral convictions, uninhibited curiosity, the ability to think critically, and the emotional resilience to thrive in secondary education and life.
              </p>
            </div>

            {/* Mission */}
            <div style={{ backgroundColor: '#FFFFFF', padding: 36, borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ width: 48, height: 48, borderRadius: 'var(--radius-md)', backgroundColor: 'var(--color-accent-soft)', color: 'var(--color-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 18 }}>
                <Compass size={24} />
              </div>
              <h3 style={{ fontSize: '1.5rem', color: 'var(--color-primary-dark)', marginBottom: 12 }}>
                Our Mission
              </h3>
              <p style={{ fontSize: '1.1875rem', color: 'var(--color-accent-dark)', fontStyle: 'italic', fontWeight: 600, marginBottom: 14 }}>
                "Provide quality education in a safe, supportive and engaging environment."
              </p>
              <p style={{ fontSize: '0.9375rem', color: 'var(--color-text-muted)', lineHeight: 1.65 }}>
                Our daily mission is to deliver active hands-on pedagogy, maintain exemplary safety and hygiene standards, nurture creativity through arts and sports, and cultivate strong partnerships with families.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Principal's Message */}
      <section className="section">
        <div className="container">
          <div className="section-header">
            <span className="section-kicker">Leadership & Guidance</span>
            <h2 className="section-title">Message from the Principal</h2>
            <p className="section-subtitle">
              A warm welcome to families seeking an educational home where children are loved, challenged, and guided with integrity.
            </p>
          </div>

          <div className="principal-card">
            <div className="principal-layout">
              <div className="principal-photo-col">
                <div className="principal-photo">
                  <span>SV</span>
                </div>
                <div className="principal-name-tag">Mrs. Sunita Verma</div>
                <div className="principal-title-tag">Principal & Head of School</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--color-text-light)', marginTop: 4 }}>
                  M.Sc., B.Ed. • 18+ Yrs in Education
                </div>
              </div>

              <div className="principal-quote-body">
                <p style={{ marginBottom: 14 }}>
                  "Dear Parents, Guardians and Friends of {school.name},
                </p>
                <p style={{ marginBottom: 14 }}>
                  A child’s formative years—from the first tentative steps in Play School to the evolving analytical queries of Class 8—are the most sacred period of human growth. At our school, we consider it a profound privilege to be custodians of this wonder.
                </p>
                <p style={{ marginBottom: 14 }}>
                  We do not believe in pressuring young minds with rigid rote learning. Rather, our teachers spark curiosity, encourage questions, teach students how to think rather than what to think, and instill time-tested Indian values of humility, respect, and perseverance.
                </p>
                <p style={{ marginBottom: 16 }}>
                  Whether in the smart classroom, the library corner, the science activity room, or out on the green sports field, we ensure that every student feels seen, valued, protected, and inspired. I invite you to visit our campus and witness our joyful family firsthand."
                </p>
                <div style={{ fontFamily: 'var(--font-heading)', fontWeight: 700, color: 'var(--color-primary-dark)', fontSize: '0.9375rem' }}>
                  — Mrs. Sunita Verma, Principal
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values (6 Core Pillars) */}
      <section className="section section-alt">
        <div className="container">
          <div className="section-header">
            <span className="section-kicker">Character & Principles</span>
            <h2 className="section-title">Our Core Values</h2>
            <p className="section-subtitle">
              These fundamental virtues are woven into daily morning assemblies, classroom lessons, sports games, and student interactions.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 24 }}>
            {valuesList.map((val, idx) => (
              <div
                key={idx}
                style={{
                  backgroundColor: '#FFFFFF',
                  border: '1px solid var(--color-border)',
                  borderRadius: 'var(--radius-md)',
                  padding: 24,
                  boxShadow: 'var(--shadow-sm)'
                }}
              >
                <div style={{ fontFamily: 'var(--font-heading)', fontSize: '0.8125rem', fontWeight: 800, color: 'var(--color-accent)', marginBottom: 8 }}>
                  0{idx + 1}.
                </div>
                <h3 style={{ fontSize: '1.25rem', color: 'var(--color-primary-dark)', marginBottom: 8 }}>
                  {val.title}
                </h3>
                <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: 1.6, margin: 0 }}>
                  {val.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
