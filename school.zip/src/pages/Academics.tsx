import React, { useState } from 'react';
import {
  BookOpen,
  Sparkles,
  Layers,
  GraduationCap,
  CheckCircle,
  Lightbulb,
  Cpu,
  Palette,
  FlaskConical,
  Award
} from 'lucide-react';
import { academicStages } from '../data/schoolData';
import { useSchool } from '../context/SchoolContext';
import classroomImg from '../assets/images/smart_classroom_1791101337304.jpg';
import playschoolImg from '../assets/images/playschool_activity_1791101350172.jpg';
import heroImg from '../assets/images/hero_school_children_1791101324038.jpg';

export const Academics: React.FC = () => {
  const { school } = useSchool();
  const [activeTab, setActiveTab] = useState<string>('early-years');

  const currentStage = academicStages.find(s => s.id === activeTab) || academicStages[0];

  const getStageImage = (id: string) => {
    switch (id) {
      case 'early-years': return playschoolImg;
      case 'primary': return classroomImg;
      case 'middle-school': return heroImg;
      default: return classroomImg;
    }
  };

  return (
    <div>
      {/* Header */}
      <section style={{ backgroundColor: 'var(--color-primary-dark)', color: '#FFFFFF', padding: '60px 0 50px 0', borderBottom: '4px solid var(--color-accent)' }}>
        <div className="container">
          <span style={{ fontSize: '0.8125rem', color: '#FCD34D', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 700, display: 'block', marginBottom: 8 }}>
            Curriculum & Pedagogy
          </span>
          <h1 style={{ fontSize: 'clamp(2rem, 3.5vw, 2.75rem)', color: '#FFFFFF', marginBottom: 12 }}>
            Academic Excellence (Play School to Class 8)
          </h1>
          <p style={{ fontSize: '1.0625rem', color: '#CBD5E1', maxWidth: 680, margin: 0, lineHeight: 1.6 }}>
            A continuous, cohesive pathway where conceptual clarity, hands-on activities, and joyful curiosity take center stage.
          </p>
        </div>
      </section>

      {/* Main Tabs Navigation */}
      <section className="section">
        <div className="container">
          <div className="academics-tabs">
            {academicStages.map((stage) => (
              <button
                key={stage.id}
                type="button"
                className={`tab-btn ${activeTab === stage.id ? 'active' : ''}`}
                onClick={() => setActiveTab(stage.id)}
              >
                {stage.title} ({stage.grades})
              </button>
            ))}
          </div>

          {/* Active Stage Card */}
          <div className="academic-stage-card">
            <div className="academic-stage-layout">
              <div>
                <span className="academic-header-badge">{currentStage.ageGroup}</span>
                <h2 className="academic-stage-title">{currentStage.title}</h2>
                <div className="academic-stage-meta">Grades Covered: {currentStage.grades}</div>
                <p className="academic-overview">{currentStage.overview}</p>

                <h3 style={{ fontSize: '1.125rem', color: 'var(--color-primary-dark)', marginBottom: 14 }}>
                  Core Learning Areas & Subjects:
                </h3>

                <ul className="checklist">
                  {currentStage.keyFocus.map((item, index) => (
                    <li key={index} className="checklist-item">
                      <CheckCircle size={18} className="checklist-icon" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>

                <div className="curriculum-callout">
                  <strong>Teaching Methodology:</strong> {currentStage.curriculumHighlights}
                </div>
              </div>

              <div>
                <div style={{ borderRadius: 'var(--radius-lg)', overflow: 'hidden', boxShadow: 'var(--shadow-md)', marginBottom: 20 }}>
                  <img
                    src={getStageImage(currentStage.id)}
                    alt={currentStage.title}
                    style={{ width: '100%', height: 'auto', display: 'block' }}
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div style={{ backgroundColor: 'var(--color-bg-subtle)', padding: 20, borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                    <Lightbulb size={18} color="var(--color-accent)" />
                    <span style={{ fontWeight: 700, fontSize: '0.9375rem', color: 'var(--color-primary-dark)' }}>
                      Assessment & Evaluation
                    </span>
                  </div>
                  <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)', margin: 0, lineHeight: 1.55 }}>
                    Periodic continuous and comprehensive formative assessments (CCE) without stress. Teachers focus on concept mastery, diagnostic feedback, and individual student encouragement rather than competitive ranking.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Activity-Based & Practical Learning Feature */}
      <section className="section section-alt">
        <div className="container">
          <div className="section-header">
            <span className="section-kicker">Experiential Discovery</span>
            <h2 className="section-title">Activity-Based & Practical Learning</h2>
            <p className="section-subtitle">
              We move far beyond dry textbook rote memorization. Children learn best by touching, creating, observing, experimenting, and discussing.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 24 }}>
            <div style={{ backgroundColor: '#FFFFFF', padding: 28, borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ width: 44, height: 44, borderRadius: 'var(--radius-sm)', backgroundColor: 'var(--color-primary-soft)', color: 'var(--color-primary)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
                <FlaskConical size={22} />
              </div>
              <h3 style={{ fontSize: '1.1875rem', color: 'var(--color-primary-dark)', marginBottom: 8 }}>
                Hands-on Science & Math Kits
              </h3>
              <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: 1.6, margin: 0 }}>
                Students perform safe chemistry reactions, dissect flower parts in biology, build geometric 3D shapes with tangrams, and discover mathematical principles practically.
              </p>
            </div>

            <div style={{ backgroundColor: '#FFFFFF', padding: 28, borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ width: 44, height: 44, borderRadius: 'var(--radius-sm)', backgroundColor: 'var(--color-accent-soft)', color: 'var(--color-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
                <Cpu size={22} />
              </div>
              <h3 style={{ fontSize: '1.1875rem', color: 'var(--color-primary-dark)', marginBottom: 8 }}>
                Coding & Digital Literacy
              </h3>
              <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: 1.6, margin: 0 }}>
                From primary grades, students learn computational logic with block-based visual coding (Scratch), touch-typing discipline, and responsible digital citizenship.
              </p>
            </div>

            <div style={{ backgroundColor: '#FFFFFF', padding: 28, borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ width: 44, height: 44, borderRadius: 'var(--radius-sm)', backgroundColor: 'var(--color-success-soft)', color: 'var(--color-success)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
                <Palette size={22} />
              </div>
              <h3 style={{ fontSize: '1.1875rem', color: 'var(--color-primary-dark)', marginBottom: 8 }}>
                Art-Integrated Learning
              </h3>
              <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: 1.6, margin: 0 }}>
                History and social sciences come alive through role-play drama, chart murals, puppet shows, and clay model representations of monuments and civilizations.
              </p>
            </div>

            <div style={{ backgroundColor: '#FFFFFF', padding: 28, borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ width: 44, height: 44, borderRadius: 'var(--radius-sm)', backgroundColor: 'var(--color-primary-soft)', color: 'var(--color-primary)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}>
                <BookOpen size={22} />
              </div>
              <h3 style={{ fontSize: '1.1875rem', color: 'var(--color-primary-dark)', marginBottom: 8 }}>
                Reading & Public Speaking
              </h3>
              <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: 1.6, margin: 0 }}>
                Weekly library reading hours, 'Show and Tell' in early classes, and morning assembly speech turns build stage composure and bilingual fluency early.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
