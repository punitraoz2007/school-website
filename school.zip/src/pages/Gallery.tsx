import React from 'react';
import { GallerySection } from '../components/GallerySection';
import { useSchool } from '../context/SchoolContext';
import { Camera, Image as ImageIcon } from 'lucide-react';

export const Gallery: React.FC = () => {
  const { school } = useSchool();

  return (
    <div>
      {/* Header */}
      <section style={{ backgroundColor: 'var(--color-primary-dark)', color: '#FFFFFF', padding: '60px 0 50px 0', borderBottom: '4px solid var(--color-accent)' }}>
        <div className="container">
          <span style={{ fontSize: '0.8125rem', color: '#FCD34D', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 700, display: 'block', marginBottom: 8 }}>
            Visual Campus Memories
          </span>
          <h1 style={{ fontSize: 'clamp(2rem, 3.5vw, 2.75rem)', color: '#FFFFFF', marginBottom: 12 }}>
            Campus Photo Gallery
          </h1>
          <p style={{ fontSize: '1.0625rem', color: '#CBD5E1', maxWidth: 680, margin: 0, lineHeight: 1.6 }}>
            Explore moments of laughter, focused study, sports triumphs, and colorful festive celebrations across our campus.
          </p>
        </div>
      </section>

      {/* Main Gallery Area */}
      <section className="section">
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: 32 }}>
            <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)' }}>
              Click on any photograph to open the high-resolution lightbox view.
            </p>
          </div>

          <GallerySection />
        </div>
      </section>
    </div>
  );
};
