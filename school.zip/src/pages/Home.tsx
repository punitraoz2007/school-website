import React from 'react';
import { Link } from 'react-router-dom';
import {
  GraduationCap,
  ShieldCheck,
  Users,
  Monitor,
  Sparkles,
  ArrowRight,
  Calendar,
  CheckCircle,
  PhoneCall,
  Clock,
  BookOpen,
  Heart
} from 'lucide-react';
import { useSchool } from '../context/SchoolContext';
import {
  schoolStats,
  keyFeatures,
  whyChooseReasons,
  facilitiesList
} from '../data/schoolData';
import { NoticeBoard } from '../components/NoticeBoard';
import { SchoolLogo } from '../components/SchoolLogo';
import heroImg from '../assets/images/hero_school_children_1791101324038.jpg';
import classroomImg from '../assets/images/smart_classroom_1791101337304.jpg';
import playschoolImg from '../assets/images/playschool_activity_1791101350172.jpg';

interface HomeProps {
  onOpenAdmissionModal: () => void;
  onOpenVisitModal: () => void;
}

export const Home: React.FC<HomeProps> = ({ onOpenAdmissionModal, onOpenVisitModal }) => {
  const { school } = useSchool();

  const getFeatureIcon = (iconName: string) => {
    switch (iconName) {
      case 'GraduationCap': return <GraduationCap size={22} />;
      case 'ShieldCheck': return <ShieldCheck size={22} />;
      case 'Users': return <Users size={22} />;
      case 'Monitor': return <Monitor size={22} />;
      case 'Sparkles': return <Sparkles size={22} />;
      default: return <GraduationCap size={22} />;
    }
  };

  return (
    <div>
      {/* ====================================================================
          1. HERO SECTION
          ==================================================================== */}
      <section className="hero-wrapper">
        <img
          src={heroImg}
          alt="Happy school students learning in classroom"
          className="hero-backdrop-img"
          referrerPolicy="no-referrer"
        />
        <div className="hero-overlay" />

        <div className="container">
          <div className="hero-content">
            {/* Left Content */}
            <div>
              <div className="hero-badge-wrap">
                <span style={{ display: 'inline-block', width: 8, height: 8, borderRadius: '50%', backgroundColor: '#FCD34D' }} />
                <span>Admissions Open for Session 2026-27 • Play School to Class 8</span>
              </div>

              <h1 className="hero-title">
                {school.name}
              </h1>

              <div className="hero-tagline">
                "{school.tagline}"
              </div>

              <p className="hero-desc">
                A safe, caring and modern learning environment where every child is encouraged to learn, explore and grow from Play School to Class 8.
              </p>

              <div className="hero-actions">
                <button
                  type="button"
                  className="btn btn-accent btn-lg"
                  onClick={onOpenAdmissionModal}
                >
                  Apply for Admission
                </button>

                <button
                  type="button"
                  className="btn btn-secondary btn-lg"
                  onClick={onOpenVisitModal}
                  style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}
                >
                  <Calendar size={18} /> Book a School Visit
                </button>

                <Link to="/contact" className="btn btn-outline-white btn-lg">
                  Contact Us
                </Link>
              </div>
            </div>

            {/* Right Media Card */}
            <div className="hero-media-box">
              <img
                src={heroImg}
                alt="Students in a lively, engaged classroom"
                referrerPolicy="no-referrer"
              />
              <div className="hero-float-card">
                <div>
                  <div className="hero-float-label">Curriculum Standard</div>
                  <div className="hero-float-value">{school.board}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div className="hero-float-label">Grade Levels</div>
                  <div className="hero-float-value">Play School to Class 8</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ====================================================================
          2. QUICK INFORMATION CARDS (5 Cards)
          ==================================================================== */}
      <section className="quick-info-strip">
        <div className="container">
          <div className="quick-info-grid">
            {keyFeatures.map((feat, idx) => (
              <div key={idx} className="quick-info-card">
                <div className="quick-info-icon">
                  {getFeatureIcon(feat.icon)}
                </div>
                <h3 className="quick-info-title">{feat.title}</h3>
                <p className="quick-info-desc">{feat.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ====================================================================
          3. WHY CHOOSE OUR SCHOOL (8 Cards)
          ==================================================================== */}
      <section className="section">
        <div className="container">
          <div className="section-header">
            <span className="section-kicker">Parent Trust & Excellence</span>
            <h2 className="section-title">Why Parents Choose Our School</h2>
            <p className="section-subtitle">
              We provide a balanced ecosystem where academic excellence, moral grounding, physical fitness, and emotional safety go hand-in-hand.
            </p>
          </div>

          <div className="why-choose-grid">
            {whyChooseReasons.map((reason, index) => (
              <div key={index} className="why-card">
                <div className="why-card-number">
                  0{index + 1}.
                </div>
                <h3 className="why-card-title">{reason.title}</h3>
                <p className="why-card-desc">{reason.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ====================================================================
          4. SCHOOL HIGHLIGHTS & STATISTICS
          ==================================================================== */}
      <section style={{ paddingBottom: 64 }}>
        <div className="container">
          <div className="stats-banner">
            <div className="stats-grid">
              {schoolStats.map((stat, idx) => (
                <div key={idx} className="stat-item">
                  <div className="stat-number">{stat.value}</div>
                  <div className="stat-label">{stat.label}</div>
                  <div className="stat-detail">{stat.detail}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ====================================================================
          5. ACADEMIC WINGS PREVIEW
          ==================================================================== */}
      <section className="section section-alt">
        <div className="container">
          <div className="section-header">
            <span className="section-kicker">Structured Stages</span>
            <h2 className="section-title">Curriculum From Early Years to Middle School</h2>
            <p className="section-subtitle">
              Every child follows a customized stage-appropriate learning framework aligned with the National Education Policy guidelines.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 24, marginBottom: 36 }}>
            {/* Early Years */}
            <div style={{ backgroundColor: '#FFFFFF', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-lg)', overflow: 'hidden', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ height: 200, overflow: 'hidden' }}>
                <img src={playschoolImg} alt="Early Years Learning" style={{ width: '100%', height: '100%', objectFit: 'cover' }} referrerPolicy="no-referrer" />
              </div>
              <div style={{ padding: 24 }}>
                <span style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--color-accent)', textTransform: 'uppercase' }}>Early Childhood</span>
                <h3 style={{ fontSize: '1.25rem', color: 'var(--color-primary-dark)', margin: '4px 0 8px 0' }}>Play School to UKG</h3>
                <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: 1.6, marginBottom: 16 }}>
                  Sensory exploration, nursery rhymes, motor development, phonics, storytelling and joyful socialization.
                </p>
                <Link to="/academics" className="btn btn-secondary btn-sm" style={{ width: '100%' }}>
                  Explore Early Years Curriculum
                </Link>
              </div>
            </div>

            {/* Primary Classes */}
            <div style={{ backgroundColor: '#FFFFFF', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-lg)', overflow: 'hidden', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ height: 200, overflow: 'hidden' }}>
                <img src={classroomImg} alt="Primary Classes 1 to 5" style={{ width: '100%', height: '100%', objectFit: 'cover' }} referrerPolicy="no-referrer" />
              </div>
              <div style={{ padding: 24 }}>
                <span style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--color-primary)', textTransform: 'uppercase' }}>Foundation</span>
                <h3 style={{ fontSize: '1.25rem', color: 'var(--color-primary-dark)', margin: '4px 0 8px 0' }}>Primary Wing (Classes 1 - 5)</h3>
                <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: 1.6, marginBottom: 16 }}>
                  English, Hindi, Mathematics, EVS, Computer literacy, General Knowledge, Arts and Sports.
                </p>
                <Link to="/academics" className="btn btn-secondary btn-sm" style={{ width: '100%' }}>
                  Explore Primary Curriculum
                </Link>
              </div>
            </div>

            {/* Middle School */}
            <div style={{ backgroundColor: '#FFFFFF', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-lg)', overflow: 'hidden', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ height: 200, overflow: 'hidden' }}>
                <img src={heroImg} alt="Middle School Classes 6 to 8" style={{ width: '100%', height: '100%', objectFit: 'cover' }} referrerPolicy="no-referrer" />
              </div>
              <div style={{ padding: 24 }}>
                <span style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--color-success)', textTransform: 'uppercase' }}>Preparatory & Middle</span>
                <h3 style={{ fontSize: '1.25rem', color: 'var(--color-primary-dark)', margin: '4px 0 8px 0' }}>Middle School (Classes 6 - 8)</h3>
                <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: 1.6, marginBottom: 16 }}>
                  Rigorous science, mathematics, literature, social sciences, computer science and analytical thinking.
                </p>
                <Link to="/academics" className="btn btn-secondary btn-sm" style={{ width: '100%' }}>
                  Explore Middle School
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ====================================================================
          6. SAFETY SPOTLIGHT & PARENT ASSURANCE
          ==================================================================== */}
      <section className="section">
        <div className="container">
          <div className="safety-hero-box" style={{ marginBottom: 0 }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 32, alignItems: 'center' }}>
              <div>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: '0.8125rem', color: '#FCD34D', fontWeight: 700, textTransform: 'uppercase', marginBottom: 8 }}>
                  <ShieldCheck size={16} /> Uncompromised Protection
                </span>
                <h2 style={{ fontSize: 'clamp(1.75rem, 3vw, 2.25rem)', color: '#FFFFFF', marginBottom: 14 }}>
                  Your Child’s Safety Matters Most to Us
                </h2>
                <p style={{ color: '#E2E8F0', fontSize: '1rem', lineHeight: 1.65, marginBottom: 24 }}>
                  From guarded gate perimeters, visitor ID verification, and CCTV monitoring in common areas to verified bus drivers and attentive floor supervisors, every detail is engineered for peace of mind.
                </p>
                <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
                  <Link to="/safety" className="btn btn-accent">
                    Read Safety Protocols
                  </Link>
                  <button type="button" className="btn btn-outline-white" onClick={onOpenVisitModal}>
                    Inspect Campus in Person
                  </button>
                </div>
              </div>

              <div style={{ backgroundColor: 'rgba(255, 255, 255, 0.08)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255, 255, 255, 0.2)', borderRadius: 'var(--radius-md)', padding: 24 }}>
                <h4 style={{ color: '#FFFFFF', fontSize: '1.0625rem', marginBottom: 16, borderBottom: '1px solid rgba(255, 255, 255, 0.15)', paddingBottom: 8 }}>
                  Key Campus Safeguards
                </h4>
                <ul className="checklist">
                  <li style={{ color: '#FFFFFF', display: 'flex', alignItems: 'center', gap: 10, fontSize: '0.875rem' }}>
                    <CheckCircle size={16} color="#34D399" />
                    <span>CCTV cameras across entrances, corridors & open fields</span>
                  </li>
                  <li style={{ color: '#FFFFFF', display: 'flex', alignItems: 'center', gap: 10, fontSize: '0.875rem' }}>
                    <CheckCircle size={16} color="#34D399" />
                    <span>Strict Escort Card verification during student dispersal</span>
                  </li>
                  <li style={{ color: '#FFFFFF', display: 'flex', alignItems: 'center', gap: 10, fontSize: '0.875rem' }}>
                    <CheckCircle size={16} color="#34D399" />
                    <span>100% police & background verified staff and transport team</span>
                  </li>
                  <li style={{ color: '#FFFFFF', display: 'flex', alignItems: 'center', gap: 10, fontSize: '0.875rem' }}>
                    <CheckCircle size={16} color="#34D399" />
                    <span>Multi-stage RO purified drinking water & hygienic washrooms</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ====================================================================
          7. NOTICE BOARD & ANNOUNCEMENTS
          ==================================================================== */}
      <section className="section section-alt">
        <div className="container">
          <div className="section-header">
            <span className="section-kicker">Important Updates</span>
            <h2 className="section-title">Latest Announcements & Notice Board</h2>
            <p className="section-subtitle">
              Stay updated with school circulars, exam schedules, upcoming celebrations, and parent-teacher meetings.
            </p>
          </div>

          <div style={{ maxWidth: 960, margin: '0 auto' }}>
            <NoticeBoard />
          </div>
        </div>
      </section>

      {/* ====================================================================
          8. CALL TO ACTION BANNER
          ==================================================================== */}
      <section style={{ backgroundColor: 'var(--color-primary-dark)', color: '#FFFFFF', padding: '64px 0', borderTop: '4px solid var(--color-accent)' }}>
        <div className="container">
          <div style={{ textAlign: 'center', maxWidth: 760, margin: '0 auto' }}>
            <h2 style={{ fontSize: 'clamp(1.75rem, 3.5vw, 2.5rem)', color: '#FFFFFF', marginBottom: 16 }}>
              Give Your Child the Right Start at {school.name}
            </h2>
            <p style={{ fontSize: '1.0625rem', color: '#CBD5E1', marginBottom: 28, lineHeight: 1.6 }}>
              Admissions are currently underway for Play School, Nursery, LKG, UKG and Classes 1 to 8 for the upcoming 2026-27 session. Limited seats ensure individual care.
            </p>
            <div style={{ display: 'flex', gap: 14, justifyContent: 'center', flexWrap: 'wrap' }}>
              <button
                type="button"
                className="btn btn-accent btn-lg"
                onClick={onOpenAdmissionModal}
              >
                Apply for Admission Now
              </button>
              <button
                type="button"
                className="btn btn-outline-white btn-lg"
                onClick={onOpenVisitModal}
              >
                Book a School Tour
              </button>
              <a href={`tel:${school.phone}`} className="btn btn-secondary btn-lg" style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                <PhoneCall size={18} color="var(--color-primary)" /> Speak to Admissions: {school.phone}
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
