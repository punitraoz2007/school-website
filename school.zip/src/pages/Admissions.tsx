import React, { useState } from 'react';
import {
  FileText,
  Calendar,
  CheckCircle,
  HelpCircle,
  FileCheck,
  CreditCard,
  UserCheck,
  Send,
  Phone,
  Clock
} from 'lucide-react';
import { useSchool } from '../context/SchoolContext';
import { saveAdmissionEnquiry } from '../services/enquiryStorage';

interface AdmissionsProps {
  onOpenVisitModal: () => void;
}

export const Admissions: React.FC<AdmissionsProps> = ({ onOpenVisitModal }) => {
  const { school } = useSchool();
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [generatedId, setGeneratedId] = useState('');
  const [formData, setFormData] = useState({
    parentName: '',
    studentName: '',
    dob: '',
    applyingClass: 'Play School',
    phone: '',
    email: '',
    address: '',
    previousSchool: '',
    message: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const admissionSteps = [
    {
      step: '1',
      title: 'Enquiry',
      desc: 'Submit the online enquiry form or visit the school reception desk.'
    },
    {
      step: '2',
      title: 'School Visit',
      desc: 'Tour our classrooms, meet teachers, and observe the environment in action.'
    },
    {
      step: '3',
      title: 'Application Form',
      desc: 'Collect and complete the official registration form with requisite child documents.'
    },
    {
      step: '4',
      title: 'Friendly Interaction',
      desc: 'An informal, friendly dialogue with the child and parents (no stressful entrance tests).'
    },
    {
      step: '5',
      title: 'Confirmation',
      desc: 'Offer letter issued, fee clearance, uniform issuance, and welcome orientation.'
    }
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.parentName.trim()) errs.parentName = 'Parent / Guardian name is required';
    if (!formData.studentName.trim()) errs.studentName = 'Student name is required';
    if (!formData.dob) errs.dob = 'Date of birth is required';
    if (!formData.phone.trim()) {
      errs.phone = 'Phone number is required';
    } else if (!/^[0-9+\s-]{8,15}$/.test(formData.phone.trim())) {
      errs.phone = 'Please enter a valid phone number';
    }
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      errs.email = 'Please enter a valid email address';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      const record = saveAdmissionEnquiry(formData);
      setGeneratedId(record.id);
      setIsSubmitted(true);
    }
  };

  return (
    <div>
      {/* Header */}
      <section style={{ backgroundColor: 'var(--color-primary-dark)', color: '#FFFFFF', padding: '60px 0 50px 0', borderBottom: '4px solid var(--color-accent)' }}>
        <div className="container">
          <span style={{ fontSize: '0.8125rem', color: '#FCD34D', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 700, display: 'block', marginBottom: 8 }}>
            Session 2026-2027
          </span>
          <h1 style={{ fontSize: 'clamp(2rem, 3.5vw, 2.75rem)', color: '#FFFFFF', marginBottom: 12 }}>
            Admissions Process & Online Enquiry
          </h1>
          <p style={{ fontSize: '1.0625rem', color: '#CBD5E1', maxWidth: 680, margin: 0, lineHeight: 1.6 }}>
            Welcome to our admissions hub. We strive to make the admission procedure transparent, welcoming, and straightforward for all parents.
          </p>
        </div>
      </section>

      {/* 5 Steps of Admission */}
      <section className="section">
        <div className="container">
          <div className="section-header">
            <span className="section-kicker">Simple 5-Step Journey</span>
            <h2 className="section-title">How the Admission Process Works</h2>
            <p className="section-subtitle">
              We ensure every prospective family receives transparent guidance and personal attention at every step.
            </p>
          </div>

          <div className="steps-container">
            {admissionSteps.map((stepItem) => (
              <div key={stepItem.step} className="step-card">
                <div className="step-number">{stepItem.step}</div>
                <h3 className="step-title">{stepItem.title}</h3>
                <p className="step-desc">{stepItem.desc}</p>
              </div>
            ))}
          </div>

          <div style={{ textAlign: 'center' }}>
            <button type="button" className="btn btn-secondary btn-lg" onClick={onOpenVisitModal}>
              <Calendar size={18} /> Schedule School Visit First
            </button>
          </div>
        </div>
      </section>

      {/* Admission Enquiry Form + Required Documents */}
      <section className="section section-alt">
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 40, alignItems: 'start' }}>
            {/* Left: Enquiry Form */}
            <div>
              <div className="form-card">
                <h3 style={{ fontSize: '1.5rem', color: 'var(--color-primary-dark)', marginBottom: 8 }}>
                  Admission Enquiry Form
                </h3>
                <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', marginBottom: 24 }}>
                  Submit the online enquiry to receive the school prospectus and fee breakdown.
                </p>

                {isSubmitted ? (
                  <div className="form-success-banner">
                    <CheckCircle size={44} style={{ margin: '0 auto 12px auto' }} />
                    <h4 className="form-success-title">Enquiry Successfully Submitted!</h4>
                    <p style={{ fontSize: '0.9375rem', marginBottom: 16 }}>
                      Thank you, <strong>{formData.parentName}</strong>. We have registered your application for{' '}
                      <strong>{formData.studentName}</strong> ({formData.applyingClass}).
                    </p>
                    <div style={{ fontSize: '0.8125rem', backgroundColor: '#FFFFFF', padding: 12, borderRadius: 6, marginBottom: 16, textAlign: 'left' }}>
                      <div>• Registration Ref: <strong>{generatedId || `APS-${Math.floor(100000 + Math.random() * 900000)}`}</strong></div>
                      <div>• Our coordinator will contact you on <strong>{formData.phone}</strong>.</div>
                    </div>
                    <button
                      type="button"
                      className="btn btn-primary btn-sm"
                      onClick={() => {
                        setIsSubmitted(false);
                        setFormData({
                          parentName: '',
                          studentName: '',
                          dob: '',
                          applyingClass: 'Play School',
                          phone: '',
                          email: '',
                          address: '',
                          previousSchool: '',
                          message: ''
                        });
                      }}
                    >
                      Submit Another Enquiry
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit}>
                    <div className="form-grid-2">
                      <div className="form-group">
                        <label className="form-label">Parent / Guardian Name *</label>
                        <input
                          type="text"
                          name="parentName"
                          value={formData.parentName}
                          onChange={handleChange}
                          className="form-input"
                          placeholder="e.g. Anil Mehra"
                        />
                        {errors.parentName && <span className="form-error">{errors.parentName}</span>}
                      </div>

                      <div className="form-group">
                        <label className="form-label">Student Name *</label>
                        <input
                          type="text"
                          name="studentName"
                          value={formData.studentName}
                          onChange={handleChange}
                          className="form-input"
                          placeholder="e.g. Diya Mehra"
                        />
                        {errors.studentName && <span className="form-error">{errors.studentName}</span>}
                      </div>
                    </div>

                    <div className="form-grid-2">
                      <div className="form-group">
                        <label className="form-label">Student Date of Birth *</label>
                        <input
                          type="date"
                          name="dob"
                          value={formData.dob}
                          onChange={handleChange}
                          className="form-input"
                        />
                        {errors.dob && <span className="form-error">{errors.dob}</span>}
                      </div>

                      <div className="form-group">
                        <label className="form-label">Class Applying For *</label>
                        <select
                          name="applyingClass"
                          value={formData.applyingClass}
                          onChange={handleChange}
                          className="form-select"
                        >
                          <option value="Play School">Play School (2 to 3 yrs)</option>
                          <option value="Nursery">Nursery (3 to 4 yrs)</option>
                          <option value="LKG">LKG (4 to 5 yrs)</option>
                          <option value="UKG">UKG (5 to 6 yrs)</option>
                          <option value="Class 1">Class 1</option>
                          <option value="Class 2">Class 2</option>
                          <option value="Class 3">Class 3</option>
                          <option value="Class 4">Class 4</option>
                          <option value="Class 5">Class 5</option>
                          <option value="Class 6">Class 6</option>
                          <option value="Class 7">Class 7</option>
                          <option value="Class 8">Class 8</option>
                        </select>
                      </div>
                    </div>

                    <div className="form-grid-2">
                      <div className="form-group">
                        <label className="form-label">Parent Phone Number *</label>
                        <input
                          type="tel"
                          name="phone"
                          value={formData.phone}
                          onChange={handleChange}
                          className="form-input"
                          placeholder="+91 98765 43210"
                        />
                        {errors.phone && <span className="form-error">{errors.phone}</span>}
                      </div>

                      <div className="form-group">
                        <label className="form-label">Parent Email</label>
                        <input
                          type="email"
                          name="email"
                          value={formData.email}
                          onChange={handleChange}
                          className="form-input"
                          placeholder="parent@example.com"
                        />
                        {errors.email && <span className="form-error">{errors.email}</span>}
                      </div>
                    </div>

                    <div className="form-grid-2">
                      <div className="form-group">
                        <label className="form-label">Residential Address</label>
                        <input
                          type="text"
                          name="address"
                          value={formData.address}
                          onChange={handleChange}
                          className="form-input"
                          placeholder="Locality, City"
                        />
                      </div>

                      <div className="form-group">
                        <label className="form-label">Previous School (If any)</label>
                        <input
                          type="text"
                          name="previousSchool"
                          value={formData.previousSchool}
                          onChange={handleChange}
                          className="form-input"
                          placeholder="School name"
                        />
                      </div>
                    </div>

                    <div className="form-group">
                      <label className="form-label">Message / Special Learning Needs</label>
                      <textarea
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        className="form-textarea"
                        rows={3}
                        placeholder="Any specific questions regarding curriculum, school bus transport, or food habits..."
                      />
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 16 }}>
                      <button type="button" className="btn btn-secondary btn-sm" onClick={onOpenVisitModal}>
                        Book a School Visit
                      </button>
                      <button type="submit" className="btn btn-accent btn-lg" style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
                        <Send size={16} /> Submit Enquiry
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </div>

            {/* Right: Age Eligibility & Documents */}
            <div>
              <div style={{ backgroundColor: '#FFFFFF', padding: 32, borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)', marginBottom: 24 }}>
                <h3 style={{ fontSize: '1.25rem', color: 'var(--color-primary-dark)', marginBottom: 14 }}>
                  Age Eligibility Criteria (As of March 31)
                </h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--color-border)', fontSize: '0.875rem' }}>
                    <strong>Play School:</strong> <span>2 Years to 3 Years</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--color-border)', fontSize: '0.875rem' }}>
                    <strong>Nursery:</strong> <span>3 Years+</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--color-border)', fontSize: '0.875rem' }}>
                    <strong>LKG:</strong> <span>4 Years+</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--color-border)', fontSize: '0.875rem' }}>
                    <strong>UKG:</strong> <span>5 Years+</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', fontSize: '0.875rem' }}>
                    <strong>Class 1:</strong> <span>6 Years+ (As per NEP guidelines)</span>
                  </div>
                </div>
              </div>

              <div style={{ backgroundColor: '#FFFFFF', padding: 32, borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
                <h3 style={{ fontSize: '1.25rem', color: 'var(--color-primary-dark)', marginBottom: 14 }}>
                  Documents Required at Admission
                </h3>
                <ul className="checklist">
                  <li className="checklist-item">
                    <CheckCircle size={16} className="checklist-icon" />
                    <span>Self-attested Municipal Birth Certificate</span>
                  </li>
                  <li className="checklist-item">
                    <CheckCircle size={16} className="checklist-icon" />
                    <span>Four recent passport-size photographs of the student</span>
                  </li>
                  <li className="checklist-item">
                    <CheckCircle size={16} className="checklist-icon" />
                    <span>Passport photographs of father and mother / guardian</span>
                  </li>
                  <li className="checklist-item">
                    <CheckCircle size={16} className="checklist-icon" />
                    <span>Residential address proof (Electricity bill / Aadhaar card / Voter ID)</span>
                  </li>
                  <li className="checklist-item">
                    <CheckCircle size={16} className="checklist-icon" />
                    <span>Original Transfer Certificate (TC) & Report Card (For Classes 2 to 8)</span>
                  </li>
                  <li className="checklist-item">
                    <CheckCircle size={16} className="checklist-icon" />
                    <span>Child’s immunization record / blood group report</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
