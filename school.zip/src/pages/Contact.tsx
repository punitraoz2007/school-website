import React from 'react';
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Navigation,
  CheckCircle,
  Building,
  Calendar
} from 'lucide-react';
import { useSchool } from '../context/SchoolContext';
import { ContactForm } from '../components/ContactForm';

interface ContactProps {
  onOpenVisitModal: () => void;
}

export const Contact: React.FC<ContactProps> = ({ onOpenVisitModal }) => {
  const { school } = useSchool();

  return (
    <div>
      {/* Header */}
      <section style={{ backgroundColor: 'var(--color-primary-dark)', color: '#FFFFFF', padding: '60px 0 50px 0', borderBottom: '4px solid var(--color-accent)' }}>
        <div className="container">
          <span style={{ fontSize: '0.8125rem', color: '#FCD34D', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 700, display: 'block', marginBottom: 8 }}>
            Always Connected
          </span>
          <h1 style={{ fontSize: 'clamp(2rem, 3.5vw, 2.75rem)', color: '#FFFFFF', marginBottom: 12 }}>
            Contact & Location Details
          </h1>
          <p style={{ fontSize: '1.0625rem', color: '#CBD5E1', maxWidth: 680, margin: 0, lineHeight: 1.6 }}>
            We look forward to meeting you and your child. Reach out to our administrative team or plan your in-person visit.
          </p>
        </div>
      </section>

      {/* Main Grid: Contact Cards & Form */}
      <section className="section">
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 40, alignItems: 'start' }}>
            {/* Left: Contact Info Card */}
            <div>
              <div className="contact-info-card">
                <div>
                  <h3 style={{ fontSize: '1.5rem', color: '#FFFFFF', marginBottom: 4 }}>
                    {school.name}
                  </h3>
                  <p style={{ fontSize: '0.875rem', color: '#CBD5E1', margin: 0 }}>
                    Play School & Classes 1 to 8 Campus
                  </p>
                </div>

                <div className="contact-info-item">
                  <div className="contact-info-icon">
                    <MapPin size={20} />
                  </div>
                  <div>
                    <div className="contact-info-label">Campus Address</div>
                    <div className="contact-info-value">
                      {school.address}<br />
                      {school.cityState} - {school.pincode}
                    </div>
                  </div>
                </div>

                <div className="contact-info-item">
                  <div className="contact-info-icon">
                    <Phone size={20} />
                  </div>
                  <div>
                    <div className="contact-info-label">Phone Helplines</div>
                    <div className="contact-info-value">
                      <a href={`tel:${school.phone}`}>{school.phone}</a> (Admissions Desk)<br />
                      <a href={`tel:${school.alternatePhone}`}>{school.alternatePhone}</a> (General Enquiries)
                    </div>
                  </div>
                </div>

                <div className="contact-info-item">
                  <div className="contact-info-icon">
                    <Mail size={20} />
                  </div>
                  <div>
                    <div className="contact-info-label">Email Correspondence</div>
                    <div className="contact-info-value">
                      <a href={`mailto:${school.email}`}>{school.email}</a><br />
                      <a href={`mailto:${school.admissionsEmail}`}>{school.admissionsEmail}</a>
                    </div>
                  </div>
                </div>

                <div className="contact-info-item">
                  <div className="contact-info-icon">
                    <Clock size={20} />
                  </div>
                  <div>
                    <div className="contact-info-label">School & Office Timings</div>
                    <div className="contact-info-value">
                      <strong>Office:</strong> {school.officeTiming}<br />
                      <strong>Visiting Hours:</strong> {school.visitingHours}
                    </div>
                  </div>
                </div>

                <div style={{ paddingTop: 16, borderTop: '1px solid rgba(255, 255, 255, 0.15)' }}>
                  <button
                    type="button"
                    className="btn btn-accent"
                    style={{ width: '100%' }}
                    onClick={onOpenVisitModal}
                  >
                    <Calendar size={18} /> Book a Campus Visit
                  </button>
                </div>
              </div>

              {/* Map Container & Landmarks */}
              <div style={{ marginTop: 24 }}>
                <div style={{ backgroundColor: '#FFFFFF', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-lg)', overflow: 'hidden', boxShadow: 'var(--shadow-sm)' }}>
                  <div
                    style={{
                      height: 200,
                      background: 'radial-gradient(circle at 50% 50%, #E2E8F0 0%, #CBD5E1 100%)',
                      position: 'relative',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderBottom: '1px solid var(--color-border)'
                    }}
                  >
                    {/* Simulated Map Grid lines */}
                    <div style={{ position: 'absolute', inset: 0, opacity: 0.25, backgroundImage: 'linear-gradient(#94A3B8 1px, transparent 1px), linear-gradient(90deg, #94A3B8 1px, transparent 1px)', backgroundSize: '24px 24px' }} />

                    {/* School Map Pin */}
                    <div
                      style={{
                        position: 'relative',
                        zIndex: 2,
                        backgroundColor: 'var(--color-primary-dark)',
                        color: '#FFFFFF',
                        padding: '10px 18px',
                        borderRadius: 'var(--radius-full)',
                        boxShadow: '0 8px 20px rgba(0, 0, 0, 0.25)',
                        display: 'flex',
                        alignItems: 'center',
                        gap: 8,
                        border: '2px solid #FFFFFF'
                      }}
                    >
                      <MapPin size={18} color="#FCD34D" />
                      <span style={{ fontSize: '0.875rem', fontWeight: 700 }}>{school.name}</span>
                    </div>
                  </div>

                  <div style={{ padding: 20 }}>
                    <h4 style={{ fontSize: '1rem', color: 'var(--color-primary-dark)', marginBottom: 8, fontWeight: 700 }}>
                      Campus Landmarks & Transit
                    </h4>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, fontSize: '0.8125rem', color: 'var(--color-text-muted)', marginBottom: 16 }}>
                      <div>• <strong>City Park:</strong> 250m walking</div>
                      <div>• <strong>Main Metro:</strong> 1.5 km (5 mins)</div>
                      <div>• <strong>Visitor Parking:</strong> Available inside Gate 1</div>
                      <div>• <strong>Bus Bay:</strong> Separate Gate 2</div>
                    </div>

                    <a
                      href={`https://maps.google.com/?q=${encodeURIComponent(`${school.name} ${school.address} ${school.cityState}`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn btn-primary btn-sm"
                      style={{ width: '100%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}
                    >
                      <Navigation size={14} /> Open in Google Maps Navigation
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Interactive Contact Form */}
            <div>
              <ContactForm />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
