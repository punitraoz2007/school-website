import React, { useState } from 'react';
import {
  Clock,
  Calendar,
  Shirt,
  CreditCard,
  BookOpen,
  Phone,
  CheckCircle,
  AlertCircle,
  FileText
} from 'lucide-react';
import { NoticeBoard } from '../components/NoticeBoard';
import { useSchool } from '../context/SchoolContext';

export const Parents: React.FC = () => {
  const { school } = useSchool();
  const [activeTab, setActiveTab] = useState<'timings' | 'calendar' | 'uniform' | 'fees' | 'rules'>('timings');

  return (
    <div>
      {/* Header */}
      <section style={{ backgroundColor: 'var(--color-primary-dark)', color: '#FFFFFF', padding: '60px 0 50px 0', borderBottom: '4px solid var(--color-accent)' }}>
        <div className="container">
          <span style={{ fontSize: '0.8125rem', color: '#FCD34D', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 700, display: 'block', marginBottom: 8 }}>
            Family & School Partnership
          </span>
          <h1 style={{ fontSize: 'clamp(2rem, 3.5vw, 2.75rem)', color: '#FFFFFF', marginBottom: 12 }}>
            Parents Corner & Information Desk
          </h1>
          <p style={{ fontSize: '1.0625rem', color: '#CBD5E1', maxWidth: 680, margin: 0, lineHeight: 1.6 }}>
            Access school timings, official notices, circulars, uniform guidelines, academic schedules, and rules in one organized place.
          </p>
        </div>
      </section>

      {/* Official Notice Board */}
      <section className="section">
        <div className="container">
          <div className="section-header">
            <span className="section-kicker">Live Updates</span>
            <h2 className="section-title">Official Circulars & Notice Board</h2>
            <p className="section-subtitle">
              All circulars are published here simultaneously with physical diary notes and parent SMS alerts.
            </p>
          </div>

          <div style={{ maxWidth: 960, margin: '0 auto 48px auto' }}>
            <NoticeBoard />
          </div>
        </div>
      </section>

      {/* Tabs for Timings, Uniforms, Fees & School Rules */}
      <section className="section section-alt">
        <div className="container">
          <div className="section-header">
            <span className="section-kicker">Essential Information</span>
            <h2 className="section-title">School Operations & Guidelines</h2>
            <p className="section-subtitle">
              Detailed breakdown of daily schedules, academic terms, dress code, payment guidelines, and campus codes of conduct.
            </p>
          </div>

          <div style={{ display: 'flex', justifyContent: 'center', gap: 10, flexWrap: 'wrap', marginBottom: 36 }}>
            <button
              type="button"
              className={`tab-btn ${activeTab === 'timings' ? 'active' : ''}`}
              onClick={() => setActiveTab('timings')}
            >
              School Timings
            </button>
            <button
              type="button"
              className={`tab-btn ${activeTab === 'calendar' ? 'active' : ''}`}
              onClick={() => setActiveTab('calendar')}
            >
              Academic Calendar 2026-27
            </button>
            <button
              type="button"
              className={`tab-btn ${activeTab === 'uniform' ? 'active' : ''}`}
              onClick={() => setActiveTab('uniform')}
            >
              Uniform & Dress Code
            </button>
            <button
              type="button"
              className={`tab-btn ${activeTab === 'fees' ? 'active' : ''}`}
              onClick={() => setActiveTab('fees')}
            >
              Fee Guidelines
            </button>
            <button
              type="button"
              className={`tab-btn ${activeTab === 'rules' ? 'active' : ''}`}
              onClick={() => setActiveTab('rules')}
            >
              School Rules & Attendance
            </button>
          </div>

          <div style={{ maxWidth: 880, margin: '0 auto' }}>
            {activeTab === 'timings' && (
              <div style={{ backgroundColor: '#FFFFFF', padding: 36, borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
                <h3 style={{ fontSize: '1.375rem', color: 'var(--color-primary-dark)', marginBottom: 18, display: 'flex', alignItems: 'center', gap: 10 }}>
                  <Clock size={22} color="var(--color-primary)" /> Daily Bell Schedules & Working Hours
                </h3>

                <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                  <div style={{ padding: 16, backgroundColor: 'var(--color-bg-subtle)', borderRadius: 'var(--radius-md)' }}>
                    <div style={{ fontWeight: 700, color: 'var(--color-primary-dark)', fontSize: '1rem', marginBottom: 4 }}>
                      Play School & Kindergarten (Nursery, LKG, UKG)
                    </div>
                    <div style={{ fontSize: '0.9375rem', color: 'var(--color-text-muted)' }}>
                      <strong>Hours:</strong> {school.timingPlaySchool}
                    </div>
                    <div style={{ fontSize: '0.8125rem', color: 'var(--color-text-light)', marginTop: 4 }}>
                      * Morning assembly commences at 8:40 AM. Toddlers must arrive 10 minutes prior.
                    </div>
                  </div>

                  <div style={{ padding: 16, backgroundColor: 'var(--color-bg-subtle)', borderRadius: 'var(--radius-md)' }}>
                    <div style={{ fontWeight: 700, color: 'var(--color-primary-dark)', fontSize: '1rem', marginBottom: 4 }}>
                      Primary & Middle Wing (Class 1 to Class 8)
                    </div>
                    <div style={{ fontSize: '0.9375rem', color: 'var(--color-text-muted)' }}>
                      <strong>Hours:</strong> {school.timingClasses1To8}
                    </div>
                    <div style={{ fontSize: '0.8125rem', color: 'var(--color-text-light)', marginTop: 4 }}>
                      * Gates close promptly at 7:45 AM. Late arrivals are recorded in the student handbook.
                    </div>
                  </div>

                  <div style={{ padding: 16, backgroundColor: 'var(--color-bg-subtle)', borderRadius: 'var(--radius-md)' }}>
                    <div style={{ fontWeight: 700, color: 'var(--color-primary-dark)', fontSize: '1rem', marginBottom: 4 }}>
                      Administrative Office & Parent Visiting Hours
                    </div>
                    <div style={{ fontSize: '0.9375rem', color: 'var(--color-text-muted)' }}>
                      <strong>Office Hours:</strong> {school.officeTiming}
                    </div>
                    <div style={{ fontSize: '0.9375rem', color: 'var(--color-text-muted)', marginTop: 2 }}>
                      <strong>Meeting Principal / Teachers:</strong> {school.visitingHours}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'calendar' && (
              <div style={{ backgroundColor: '#FFFFFF', padding: 36, borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
                <h3 style={{ fontSize: '1.375rem', color: 'var(--color-primary-dark)', marginBottom: 18, display: 'flex', alignItems: 'center', gap: 10 }}>
                  <Calendar size={22} color="var(--color-primary)" /> Academic Year Calendar 2026-27
                </h3>

                <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                  <div style={{ border: '1px solid var(--color-border)', borderRadius: 'var(--radius-sm)', overflow: 'hidden' }}>
                    <div style={{ backgroundColor: 'var(--color-primary-soft)', padding: '10px 16px', fontWeight: 700, color: 'var(--color-primary-dark)', fontSize: '0.9375rem' }}>
                      Term 1 (April 2026 - September 2026)
                    </div>
                    <div style={{ padding: '12px 16px', fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
                      • <strong>April 06, 2026:</strong> Academic Session 2026-27 commences for all classes.<br />
                      • <strong>May 20 - June 30, 2026:</strong> Summer Vacation (Summer reading challenge for students).<br />
                      • <strong>July 01, 2026:</strong> School reopens after summer break.<br />
                      • <strong>September 14 - 24, 2026:</strong> Term 1 Periodic Assessments & PTM.
                    </div>
                  </div>

                  <div style={{ border: '1px solid var(--color-border)', borderRadius: 'var(--radius-sm)', overflow: 'hidden' }}>
                    <div style={{ backgroundColor: 'var(--color-accent-soft)', padding: '10px 16px', fontWeight: 700, color: '#78350F', fontSize: '0.9375rem' }}>
                      Term 2 (October 2026 - March 2027)
                    </div>
                    <div style={{ padding: '12px 16px', fontSize: '0.875rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
                      • <strong>October 18, 2026:</strong> Annual Athletic Meet & Sports Day.<br />
                      • <strong>November 10 - 15, 2026:</strong> Diwali & Festive Break.<br />
                      • <strong>December 28 - January 07, 2027:</strong> Winter Break.<br />
                      • <strong>February 20, 2027:</strong> Annual Science & Cultural Exhibition.<br />
                      • <strong>March 08 - 20, 2027:</strong> Final Cumulative Assessments & Report Card Day.
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'uniform' && (
              <div style={{ backgroundColor: '#FFFFFF', padding: 36, borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
                <h3 style={{ fontSize: '1.375rem', color: 'var(--color-primary-dark)', marginBottom: 18, display: 'flex', alignItems: 'center', gap: 10 }}>
                  <Shirt size={22} color="var(--color-primary)" /> School Uniform Guidelines
                </h3>

                <p style={{ fontSize: '0.9375rem', color: 'var(--color-text-muted)', marginBottom: 20 }}>
                  A neat uniform promotes equality, pride, and belonging. All items are available through designated school vendors.
                </p>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 20 }}>
                  <div style={{ border: '1px solid var(--color-border)', padding: 18, borderRadius: 'var(--radius-sm)' }}>
                    <h4 style={{ fontSize: '1.0625rem', color: 'var(--color-primary-dark)', marginBottom: 8 }}>Regular Summer Uniform</h4>
                    <ul style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', paddingLeft: 18, lineHeight: 1.6 }}>
                      <li>Navy blue trousers / pleated skirt</li>
                      <li>Crisp sky-blue collared shirt with school emblem</li>
                      <li>School tie and woven belt</li>
                      <li>Polished black shoes with navy socks</li>
                    </ul>
                  </div>

                  <div style={{ border: '1px solid var(--color-border)', padding: 18, borderRadius: 'var(--radius-sm)' }}>
                    <h4 style={{ fontSize: '1.0625rem', color: 'var(--color-primary-dark)', marginBottom: 8 }}>Wednesday & Saturday House Uniform</h4>
                    <ul style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', paddingLeft: 18, lineHeight: 1.6 }}>
                      <li>Designated House T-shirt (Red/Blue/Green/Yellow)</li>
                      <li>White track pants or sports skirt</li>
                      <li>Clean white sports sneakers and white socks</li>
                    </ul>
                  </div>

                  <div style={{ border: '1px solid var(--color-border)', padding: 18, borderRadius: 'var(--radius-sm)' }}>
                    <h4 style={{ fontSize: '1.0625rem', color: 'var(--color-primary-dark)', marginBottom: 8 }}>Winter Additions</h4>
                    <ul style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', paddingLeft: 18, lineHeight: 1.6 }}>
                      <li>Navy blue V-neck woolen pullover with school crest</li>
                      <li>School navy blazer (Classes 3 to 8 mandatory)</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'fees' && (
              <div style={{ backgroundColor: '#FFFFFF', padding: 36, borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
                <h3 style={{ fontSize: '1.375rem', color: 'var(--color-primary-dark)', marginBottom: 18, display: 'flex', alignItems: 'center', gap: 10 }}>
                  <CreditCard size={22} color="var(--color-primary)" /> Fee Schedule & Payment Modes
                </h3>

                <p style={{ fontSize: '0.9375rem', color: 'var(--color-text-muted)', marginBottom: 20 }}>
                  Fees are payable quarterly on or before the 10th of the starting month (April, July, October, January).
                </p>

                <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
                    <CheckCircle size={18} color="var(--color-success)" style={{ flexShrink: 0, marginTop: 2 }} />
                    <span style={{ fontSize: '0.9375rem', color: 'var(--color-text-main)' }}>
                      <strong>Digital Payments:</strong> UPI, Net Banking, NEFT/RTGS, and Credit/Debit cards accepted via parent portal and reception desk.
                    </span>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
                    <CheckCircle size={18} color="var(--color-success)" style={{ flexShrink: 0, marginTop: 2 }} />
                    <span style={{ fontSize: '0.9375rem', color: 'var(--color-text-main)' }}>
                      <strong>Sibling Concession:</strong> 10% concession on tuition fees for the younger sibling.
                    </span>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
                    <CheckCircle size={18} color="var(--color-success)" style={{ flexShrink: 0, marginTop: 2 }} />
                    <span style={{ fontSize: '0.9375rem', color: 'var(--color-text-main)' }}>
                      <strong>Detailed Fee Cards:</strong> The complete grade-wise breakdown is available in the admission prospectus or from accounts desk: <a href={`mailto:${school.admissionsEmail}`} style={{ color: 'var(--color-primary)', fontWeight: 600 }}>{school.admissionsEmail}</a>.
                    </span>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'rules' && (
              <div style={{ backgroundColor: '#FFFFFF', padding: 36, borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
                <h3 style={{ fontSize: '1.375rem', color: 'var(--color-primary-dark)', marginBottom: 18, display: 'flex', alignItems: 'center', gap: 10 }}>
                  <AlertCircle size={22} color="var(--color-primary)" /> School Code of Conduct & Attendance
                </h3>

                <ul className="checklist">
                  <li className="checklist-item">
                    <CheckCircle size={16} className="checklist-icon" />
                    <span><strong>75% Minimum Attendance:</strong> Required by board rules for promotion to the next academic grade.</span>
                  </li>
                  <li className="checklist-item">
                    <CheckCircle size={16} className="checklist-icon" />
                    <span><strong>Leave Applications:</strong> Prior written approval in the school diary required for any absence exceeding two days.</span>
                  </li>
                  <li className="checklist-item">
                    <CheckCircle size={16} className="checklist-icon" />
                    <span><strong>Mobile Phones:</strong> Electronic gadgets and mobile devices are strictly not allowed for students on campus.</span>
                  </li>
                  <li className="checklist-item">
                    <CheckCircle size={16} className="checklist-icon" />
                    <span><strong>School Diary:</strong> Must be brought daily. It serves as the primary mode of correspondence between teachers and parents.</span>
                  </li>
                </ul>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};
