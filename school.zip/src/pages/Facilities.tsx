import React, { useState } from 'react';
import { facilitiesList } from '../data/schoolData';
import { FacilityCard } from '../components/FacilityCard';
import { useSchool } from '../context/SchoolContext';
import { CheckCircle, ShieldCheck } from 'lucide-react';

export const Facilities: React.FC = () => {
  const { school } = useSchool();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Academics', 'Safety', 'Campus', 'Health', 'Sports', 'Arts & Culture', 'Logistics'];

  const filteredFacilities = selectedCategory === 'All'
    ? facilitiesList
    : facilitiesList.filter(f => f.category === selectedCategory);

  return (
    <div>
      {/* Header */}
      <section style={{ backgroundColor: 'var(--color-primary-dark)', color: '#FFFFFF', padding: '60px 0 50px 0', borderBottom: '4px solid var(--color-accent)' }}>
        <div className="container">
          <span style={{ fontSize: '0.8125rem', color: '#FCD34D', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 700, display: 'block', marginBottom: 8 }}>
            Infrastructure & Care
          </span>
          <h1 style={{ fontSize: 'clamp(2rem, 3.5vw, 2.75rem)', color: '#FFFFFF', marginBottom: 12 }}>
            Campus Facilities & Infrastructure
          </h1>
          <p style={{ fontSize: '1.0625rem', color: '#CBD5E1', maxWidth: 700, margin: 0, lineHeight: 1.6 }}>
            Designed specifically for children from Play School to Class 8: child-safe spaces, modern learning aids, clean hygiene facilities, and open playgrounds.
          </p>
        </div>
      </section>

      {/* Filter Tabs & Facilities Grid */}
      <section className="section">
        <div className="container">
          {/* Category Filter Pills */}
          <div style={{ display: 'flex', justifyContent: 'center', gap: 8, flexWrap: 'wrap', marginBottom: 40 }}>
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                className={`filter-btn ${selectedCategory === cat ? 'active' : ''}`}
                onClick={() => setSelectedCategory(cat)}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Cards Grid */}
          <div className="facilities-grid">
            {filteredFacilities.map((fac) => (
              <FacilityCard
                key={fac.id}
                id={fac.id}
                title={fac.title}
                category={fac.category}
                image={fac.image}
                description={fac.description}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Hygiene & Maintenance Protocol Note */}
      <section className="section section-soft">
        <div className="container">
          <div style={{ backgroundColor: '#FFFFFF', padding: 36, borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
              <ShieldCheck size={28} color="var(--color-primary)" />
              <h2 style={{ fontSize: '1.375rem', color: 'var(--color-primary-dark)', margin: 0 }}>
                Campus Maintenance & Regular Audits
              </h2>
            </div>
            <p style={{ fontSize: '0.9375rem', color: 'var(--color-text-muted)', lineHeight: 1.65, marginBottom: 20 }}>
              To ensure all facilities remain in peak condition, our operations team conducts daily hygiene inspections before classes begin, weekly safety checks on outdoor play equipment, and monthly sanitization audits of water purifiers and washrooms.
            </p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 16 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: '0.875rem', color: 'var(--color-text-main)' }}>
                <CheckCircle size={16} color="var(--color-success)" />
                <span>Certified RO Water Quality Testing</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: '0.875rem', color: 'var(--color-text-main)' }}>
                <CheckCircle size={16} color="var(--color-success)" />
                <span>Child-safe Rounded Furniture Edges</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: '0.875rem', color: 'var(--color-success)' }}>
                <CheckCircle size={16} color="var(--color-success)" />
                <span>Trained Attendants for Early Years</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: '0.875rem', color: 'var(--color-success)' }}>
                <CheckCircle size={16} color="var(--color-success)" />
                <span>Regular Fire Safety Drills</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
