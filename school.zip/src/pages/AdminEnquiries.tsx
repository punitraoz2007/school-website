import React, { useState, useEffect } from 'react';
import {
  Inbox,
  UserCheck,
  Calendar,
  MessageSquare,
  Download,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  Trash2,
  Phone,
  Mail,
  MapPin,
  Sparkles,
  Info,
  Building,
  GraduationCap
} from 'lucide-react';
import {
  getAdmissionEnquiries,
  getCampusVisits,
  getContactMessages,
  updateAdmissionStatus,
  deleteAdmissionEnquiry,
  updateVisitStatus,
  updateMessageStatus,
  exportEnquiriesToCSV,
  AdmissionEnquiryRecord,
  CampusVisitRecord,
  ContactMessageRecord
} from '../services/enquiryStorage';
import { useSchool } from '../context/SchoolContext';

export const AdminEnquiries: React.FC = () => {
  const { school } = useSchool();
  const [activeTab, setActiveTab] = useState<'admissions' | 'visits' | 'messages'>('admissions');
  const [admissions, setAdmissions] = useState<AdmissionEnquiryRecord[]>([]);
  const [visits, setVisits] = useState<CampusVisitRecord[]>([]);
  const [messages, setMessages] = useState<ContactMessageRecord[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [classFilter, setClassFilter] = useState('All');

  const refreshData = () => {
    setAdmissions(getAdmissionEnquiries());
    setVisits(getCampusVisits());
    setMessages(getContactMessages());
  };

  useEffect(() => {
    refreshData();
    const handleUpdate = () => refreshData();
    window.addEventListener('aarambh_enquiry_updated', handleUpdate);
    return () => window.removeEventListener('aarambh_enquiry_updated', handleUpdate);
  }, []);

  const handleStatusChange = (id: string, newStatus: AdmissionEnquiryRecord['status']) => {
    updateAdmissionStatus(id, newStatus);
    refreshData();
  };

  const handleVisitStatusChange = (id: string, newStatus: CampusVisitRecord['status']) => {
    updateVisitStatus(id, newStatus);
    refreshData();
  };

  const handleMessageStatusChange = (id: string, newStatus: ContactMessageRecord['status']) => {
    updateMessageStatus(id, newStatus);
    refreshData();
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this enquiry record?')) {
      deleteAdmissionEnquiry(id);
      refreshData();
    }
  };

  // Filter admissions
  const filteredAdmissions = admissions.filter((item) => {
    const matchesSearch =
      item.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.parentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.phone.includes(searchQuery) ||
      item.id.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesClass = classFilter === 'All' || item.applyingClass === classFilter;
    return matchesSearch && matchesClass;
  });

  const newAdmissionsCount = admissions.filter(a => a.status === 'New').length;

  return (
    <div>
      {/* Header Banner */}
      <section style={{ backgroundColor: 'var(--color-primary-dark)', color: '#FFFFFF', padding: '50px 0 40px 0', borderBottom: '4px solid var(--color-accent)' }}>
        <div className="container">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 16 }}>
            <div>
              <span style={{ fontSize: '0.8125rem', color: '#FCD34D', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 700, display: 'block', marginBottom: 6 }}>
                Administrative Control Desk
              </span>
              <h1 style={{ fontSize: 'clamp(1.875rem, 3vw, 2.5rem)', color: '#FFFFFF', marginBottom: 8 }}>
                Admissions & Leads Inbox
              </h1>
              <p style={{ fontSize: '0.9375rem', color: '#CBD5E1', maxWidth: 640, margin: 0 }}>
                All online admission enquiries, school visit bookings, and contact inquiries submitted by parents are collected and managed here.
              </p>
            </div>

            <div style={{ display: 'flex', gap: 10 }}>
              <button
                type="button"
                className="btn btn-accent btn-sm"
                onClick={exportEnquiriesToCSV}
                style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}
              >
                <Download size={15} /> Export Enquiries to CSV
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Explanatory Info Card: Where does enquiry information go? */}
      <section style={{ backgroundColor: '#F8FAFC', padding: '24px 0', borderBottom: '1px solid var(--color-border)' }}>
        <div className="container">
          <div
            style={{
              backgroundColor: '#EFF6FF',
              border: '1px solid #BFDBFE',
              borderRadius: 'var(--radius-md)',
              padding: '18px 24px',
              display: 'flex',
              alignItems: 'flex-start',
              gap: 16
            }}
          >
            <Info size={24} color="#1E40AF" style={{ flexShrink: 0, marginTop: 2 }} />
            <div>
              <h4 style={{ fontSize: '0.9375rem', fontWeight: 700, color: '#1E3A8A', marginBottom: 4 }}>
                How Enquiry Data Works & Production Routing:
              </h4>
              <p style={{ fontSize: '0.875rem', color: '#1E40AF', margin: 0, lineHeight: 1.6 }}>
                <strong>1. In This Web App:</strong> All submitted entries from the <em>Admission Modal</em>, <em>Admissions Page</em>, <em>Book a Visit Modal</em>, and <em>Contact Page</em> are instantly persisted in real-time in this dashboard.<br />
                <strong>2. In Production Deployment:</strong> This information can be configured to trigger instant <strong>Email notifications</strong> to <code>{school.admissionsEmail}</code>, send <strong>SMS / WhatsApp alerts</strong> to the admissions desk phone (<code>{school.phone}</code>), and sync directly to Google Sheets or your school's ERP database.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Metrics Row */}
      <section style={{ padding: '32px 0 16px 0' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 18 }}>
            <div style={{ backgroundColor: '#FFFFFF', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', padding: 20, boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ fontSize: '0.75rem', textTransform: 'uppercase', color: '#64748B', fontWeight: 700, marginBottom: 4 }}>
                Total Admission Enquiries
              </div>
              <div style={{ fontFamily: 'var(--font-heading)', fontSize: '2rem', fontWeight: 800, color: 'var(--color-primary-dark)' }}>
                {admissions.length}
              </div>
              <div style={{ fontSize: '0.8125rem', color: '#059669', marginTop: 4, display: 'flex', alignItems: 'center', gap: 4 }}>
                <Sparkles size={13} /> {newAdmissionsCount} new pending review
              </div>
            </div>

            <div style={{ backgroundColor: '#FFFFFF', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', padding: 20, boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ fontSize: '0.75rem', textTransform: 'uppercase', color: '#64748B', fontWeight: 700, marginBottom: 4 }}>
                Campus Tour Bookings
              </div>
              <div style={{ fontFamily: 'var(--font-heading)', fontSize: '2rem', fontWeight: 800, color: 'var(--color-accent-dark)' }}>
                {visits.length}
              </div>
              <div style={{ fontSize: '0.8125rem', color: '#64748B', marginTop: 4 }}>
                Parent walkthroughs scheduled
              </div>
            </div>

            <div style={{ backgroundColor: '#FFFFFF', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', padding: 20, boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ fontSize: '0.75rem', textTransform: 'uppercase', color: '#64748B', fontWeight: 700, marginBottom: 4 }}>
                General Messages
              </div>
              <div style={{ fontFamily: 'var(--font-heading)', fontSize: '2rem', fontWeight: 800, color: '#334155' }}>
                {messages.length}
              </div>
              <div style={{ fontSize: '0.8125rem', color: '#64748B', marginTop: 4 }}>
                Questions from contact form
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Tabs & Records */}
      <section className="section" style={{ paddingTop: 20 }}>
        <div className="container">
          {/* Tabs */}
          <div style={{ display: 'flex', gap: 10, borderBottom: '2px solid var(--color-border)', paddingBottom: 12, marginBottom: 24, flexWrap: 'wrap' }}>
            <button
              type="button"
              className={`tab-btn ${activeTab === 'admissions' ? 'active' : ''}`}
              onClick={() => setActiveTab('admissions')}
            >
              <GraduationCap size={16} /> Admission Enquiries ({admissions.length})
            </button>
            <button
              type="button"
              className={`tab-btn ${activeTab === 'visits' ? 'active' : ''}`}
              onClick={() => setActiveTab('visits')}
            >
              <Calendar size={16} /> Campus Tour Bookings ({visits.length})
            </button>
            <button
              type="button"
              className={`tab-btn ${activeTab === 'messages' ? 'active' : ''}`}
              onClick={() => setActiveTab('messages')}
            >
              <MessageSquare size={16} /> Contact Messages ({messages.length})
            </button>
          </div>

          {/* TAB 1: ADMISSION ENQUIRIES */}
          {activeTab === 'admissions' && (
            <div>
              {/* Search & Filter Bar */}
              <div style={{ display: 'flex', gap: 12, marginBottom: 20, flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', gap: 10, flex: 1, minWidth: 280 }}>
                  <div style={{ position: 'relative', flex: 1 }}>
                    <Search size={16} color="#94A3B8" style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }} />
                    <input
                      type="text"
                      className="form-input"
                      style={{ paddingLeft: 36 }}
                      placeholder="Search by student, parent name, or phone..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>

                  <select
                    className="form-select"
                    style={{ width: 180 }}
                    value={classFilter}
                    onChange={(e) => setClassFilter(e.target.value)}
                  >
                    <option value="All">All Grades</option>
                    <option value="Play School">Play School</option>
                    <option value="Nursery">Nursery</option>
                    <option value="LKG">LKG</option>
                    <option value="UKG">UKG</option>
                    <option value="Class 1">Class 1</option>
                    <option value="Class 2">Class 2</option>
                    <option value="Class 3">Class 3</option>
                    <option value="Class 4">Class 4</option>
                    <option value="Class 5">Class 5</option>
                    <option value="Class 6">Class 6</option>
                    <option value="Class 7">Class 7</option>
                    <option value="Class 8">Class 8</option>
                  </select>
                </div>
              </div>

              {/* Records List */}
              {filteredAdmissions.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '48px 20px', backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}>
                  <Inbox size={40} color="#94A3B8" style={{ margin: '0 auto 12px auto' }} />
                  <h4 style={{ fontSize: '1.125rem', color: 'var(--color-primary-dark)', marginBottom: 4 }}>No enquiries match your search</h4>
                  <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', margin: 0 }}>
                    Try clearing the search query or class filter to view all submissions.
                  </p>
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                  {filteredAdmissions.map((item) => (
                    <div
                      key={item.id}
                      style={{
                        backgroundColor: '#FFFFFF',
                        border: '1px solid var(--color-border)',
                        borderRadius: 'var(--radius-md)',
                        padding: 24,
                        boxShadow: 'var(--shadow-sm)',
                        display: 'flex',
                        flexDirection: 'column',
                        gap: 14
                      }}
                    >
                      {/* Top Bar of Record */}
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 12 }}>
                        <div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                            <span style={{ fontFamily: 'monospace', fontWeight: 700, fontSize: '0.875rem', color: 'var(--color-primary)' }}>
                              {item.id}
                            </span>
                            <span style={{ fontSize: '0.75rem', color: '#64748B' }}>• Submitted {item.submittedAt}</span>
                          </div>
                          <h3 style={{ fontSize: '1.25rem', color: 'var(--color-primary-dark)', margin: 0 }}>
                            {item.studentName} <span style={{ fontSize: '0.875rem', color: 'var(--color-accent)', fontWeight: 600 }}>({item.applyingClass})</span>
                          </h3>
                        </div>

                        {/* Status Changer */}
                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                          <span style={{ fontSize: '0.8125rem', fontWeight: 600, color: '#64748B' }}>Status:</span>
                          <select
                            value={item.status}
                            onChange={(e) => handleStatusChange(item.id, e.target.value as any)}
                            style={{
                              padding: '5px 12px',
                              borderRadius: 'var(--radius-sm)',
                              fontSize: '0.8125rem',
                              fontWeight: 700,
                              border: '1.5px solid var(--color-border)',
                              backgroundColor:
                                item.status === 'New' ? '#FEF2F2' :
                                item.status === 'Contacted' ? '#EFF6FF' :
                                item.status === 'Visit Scheduled' ? '#FFFBEB' :
                                item.status === 'Admitted' ? '#ECFDF5' : '#F1F5F9',
                              color:
                                item.status === 'New' ? '#DC2626' :
                                item.status === 'Contacted' ? '#1E40AF' :
                                item.status === 'Visit Scheduled' ? '#B45309' :
                                item.status === 'Admitted' ? '#065F46' : '#475569'
                            }}
                          >
                            <option value="New">🔴 New Lead</option>
                            <option value="Contacted">🔵 Contacted Parent</option>
                            <option value="Visit Scheduled">🟡 Visit Scheduled</option>
                            <option value="Admitted">🟢 Admitted</option>
                            <option value="Archived">⚪ Archived</option>
                          </select>

                          <button
                            type="button"
                            onClick={() => handleDelete(item.id)}
                            style={{ color: '#EF4444', padding: '6px', borderRadius: 4 }}
                            title="Delete enquiry"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>

                      {/* Details Grid */}
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16, backgroundColor: 'var(--color-bg-subtle)', padding: 16, borderRadius: 'var(--radius-sm)' }}>
                        <div>
                          <div style={{ fontSize: '0.75rem', color: '#64748B', fontWeight: 600 }}>Parent / Guardian:</div>
                          <div style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--color-text-main)' }}>{item.parentName}</div>
                        </div>

                        <div>
                          <div style={{ fontSize: '0.75rem', color: '#64748B', fontWeight: 600 }}>Contact Phone:</div>
                          <div style={{ fontSize: '0.875rem', fontWeight: 700 }}>
                            <a href={`tel:${item.phone}`} style={{ color: 'var(--color-primary)', display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                              <Phone size={13} /> {item.phone}
                            </a>
                          </div>
                        </div>

                        <div>
                          <div style={{ fontSize: '0.75rem', color: '#64748B', fontWeight: 600 }}>Email Address:</div>
                          <div style={{ fontSize: '0.875rem' }}>
                            {item.email ? (
                              <a href={`mailto:${item.email}`} style={{ color: 'var(--color-primary)' }}>
                                {item.email}
                              </a>
                            ) : (
                              <span style={{ color: '#94A3B8' }}>Not provided</span>
                            )}
                          </div>
                        </div>

                        <div>
                          <div style={{ fontSize: '0.75rem', color: '#64748B', fontWeight: 600 }}>Student Date of Birth:</div>
                          <div style={{ fontSize: '0.875rem', color: 'var(--color-text-main)' }}>{item.dob}</div>
                        </div>

                        <div>
                          <div style={{ fontSize: '0.75rem', color: '#64748B', fontWeight: 600 }}>Previous School:</div>
                          <div style={{ fontSize: '0.875rem', color: 'var(--color-text-main)' }}>{item.previousSchool || 'None / First Admission'}</div>
                        </div>

                        <div>
                          <div style={{ fontSize: '0.75rem', color: '#64748B', fontWeight: 600 }}>Area / Locality:</div>
                          <div style={{ fontSize: '0.875rem', color: 'var(--color-text-main)' }}>{item.address || 'Not specified'}</div>
                        </div>
                      </div>

                      {/* Parent Note */}
                      {item.message && (
                        <div style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)', borderLeft: '3px solid var(--color-primary-light)', paddingLeft: 12 }}>
                          <strong>Parent Message / Queries:</strong> "{item.message}"
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: CAMPUS VISITS */}
          {activeTab === 'visits' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {visits.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '48px 20px', backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-md)' }}>
                  <Calendar size={40} color="#94A3B8" style={{ margin: '0 auto 12px auto' }} />
                  <p style={{ margin: 0, color: 'var(--color-text-muted)' }}>No campus visits booked yet.</p>
                </div>
              ) : (
                visits.map((v) => (
                  <div key={v.id} style={{ backgroundColor: '#FFFFFF', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', padding: 22, boxShadow: 'var(--shadow-sm)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 10, marginBottom: 12 }}>
                      <div>
                        <span style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--color-primary)' }}>{v.id}</span>
                        <h3 style={{ fontSize: '1.1875rem', color: 'var(--color-primary-dark)', margin: '2px 0 0 0' }}>
                          {v.parentName} • <span style={{ fontSize: '0.875rem', color: 'var(--color-accent)' }}>{v.childClass}</span>
                        </h3>
                      </div>

                      <select
                        value={v.status}
                        onChange={(e) => handleVisitStatusChange(v.id, e.target.value as any)}
                        style={{ padding: '4px 10px', fontSize: '0.8125rem', fontWeight: 700, borderRadius: 4, border: '1px solid var(--color-border)' }}
                      >
                        <option value="Pending">Pending Confirmation</option>
                        <option value="Confirmed">Confirmed</option>
                        <option value="Completed">Completed Tour</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 12, backgroundColor: 'var(--color-bg-subtle)', padding: 14, borderRadius: 6, fontSize: '0.875rem' }}>
                      <div><strong>Preferred Date:</strong> {v.visitDate}</div>
                      <div><strong>Time Slot:</strong> {v.timeSlot}</div>
                      <div><strong>Phone:</strong> <a href={`tel:${v.phone}`}>{v.phone}</a></div>
                      <div><strong>Submitted:</strong> {v.submittedAt}</div>
                    </div>

                    {v.notes && (
                      <div style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)', marginTop: 10 }}>
                        <strong>Notes:</strong> {v.notes}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          )}

          {/* TAB 3: CONTACT MESSAGES */}
          {activeTab === 'messages' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              {messages.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '48px 20px', backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-md)' }}>
                  <MessageSquare size={40} color="#94A3B8" style={{ margin: '0 auto 12px auto' }} />
                  <p style={{ margin: 0, color: 'var(--color-text-muted)' }}>No messages yet.</p>
                </div>
              ) : (
                messages.map((m) => (
                  <div key={m.id} style={{ backgroundColor: '#FFFFFF', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', padding: 22, boxShadow: 'var(--shadow-sm)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 10, marginBottom: 12 }}>
                      <div>
                        <span style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--color-primary)' }}>{m.id}</span>
                        <h3 style={{ fontSize: '1.1875rem', color: 'var(--color-primary-dark)', margin: '2px 0 0 0' }}>
                          {m.name} — <span style={{ fontSize: '0.9375rem', color: 'var(--color-accent)' }}>"{m.subject}"</span>
                        </h3>
                      </div>

                      <select
                        value={m.status}
                        onChange={(e) => handleMessageStatusChange(m.id, e.target.value as any)}
                        style={{ padding: '4px 10px', fontSize: '0.8125rem', fontWeight: 700, borderRadius: 4, border: '1px solid var(--color-border)' }}
                      >
                        <option value="Unread">Unread</option>
                        <option value="Replied">Replied</option>
                      </select>
                    </div>

                    <div style={{ backgroundColor: 'var(--color-bg-subtle)', padding: 14, borderRadius: 6, fontSize: '0.875rem', marginBottom: 10, display: 'flex', gap: 20, flexWrap: 'wrap' }}>
                      <div><strong>Phone:</strong> <a href={`tel:${m.phone}`}>{m.phone}</a></div>
                      <div><strong>Email:</strong> {m.email ? <a href={`mailto:${m.email}`}>{m.email}</a> : 'N/A'}</div>
                      <div><strong>Received:</strong> {m.submittedAt}</div>
                    </div>

                    <p style={{ fontSize: '0.9375rem', color: 'var(--color-text-main)', margin: 0, lineHeight: 1.6 }}>
                      "{m.message}"
                    </p>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
